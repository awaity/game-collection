import * as THREE from 'three';
import { ResourceBatch } from '../render/ResourceBatch.js';
import { seededRandom } from '../utils/math.js';

/** Local lake-space shader + instanced schooling fish. The lake never scales about world zero. */
export class PondView {
  constructor(factory, parent) {
    this.factory = factory; this.root = new THREE.Group(); parent.add(this.root);
    this.root.position.set(12.25, 0, 1.4);
    const f = factory;
    const disk = f.geo('lake-disc-v11', () => new THREE.CircleGeometry(1, 96));
    const bed = new THREE.Mesh(disk, f.material(0x188bb6));
    bed.rotation.x = -Math.PI / 2; bed.scale.set(4.58, 3.95, 1); bed.position.y = .026; this.root.add(bed);
    const material = new THREE.ShaderMaterial({
      uniforms: { uTime: { value: 0 } },
      vertexShader: `varying vec2 vUv; void main(){vUv=uv;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.0);}`,
      fragmentShader: `
        uniform float uTime; varying vec2 vUv;
        void main(){
          vec2 p=(vUv-.5)*2.; float r=length(p);
          float w=sin(p.x*15.+sin(p.y*13.+uTime*.45)*1.6+uTime*.50);
          float w2=sin(p.y*19.-sin(p.x*10.-uTime*.42)*1.7-uTime*.34);
          float caustic=pow(max(0.,1.-abs(w+w2)*.62),12.)*.18;
          float a=atan(p.y,p.x);
          float ribbon=sin(r*26.+a*4.-uTime*.50)*.5+.5;
          vec3 deep=vec3(.010,.23,.51),light=vec3(.022,.61,.68);
          float shore=smoothstep(.23,1.,r);
          vec3 col=mix(deep,light,.28+shore*.52+ribbon*.09);
          col+=vec3(.06,.22,.22)*caustic;
          float edge=smoothstep(.91,.995,r);
          col=mix(col,vec3(.47,.83,.87),edge*.70);
          gl_FragColor=vec4(col,1.);
          #include <tonemapping_fragment>
          #include <encodings_fragment>
        }`,
    });
    f.materials.set('lake-shader', material); this.material = material;
    const water = new THREE.Mesh(disk, material); water.rotation.x = -Math.PI/2;
    water.scale.set(4.55, 3.93, 1); water.position.y = .078; this.root.add(water);
    const rimGeometry = f.geo('lake-ice-rim', () => new THREE.RingGeometry(.96, 1.055, 96));
    const rim = new THREE.Mesh(rimGeometry, f.material(0xe5f5fc));
    rim.rotation.x = -Math.PI/2; rim.scale.set(4.72, 4.05, 1); rim.position.y = .11; rim.receiveShadow = true; this.root.add(rim);
    const shine = new THREE.Mesh(f.geo('lake-shore-line', () => new THREE.RingGeometry(.982, 1, 96)), f.basic(0xa0e1f3));
    shine.rotation.x=-Math.PI/2;shine.scale.set(4.58,3.97,1);shine.position.y=.118;this.root.add(shine);
    this.batch = new ResourceBatch(f, 'fish', 180, this.root);
    const random = seededRandom(222);
    this.fish = Array.from({ length: 180 }, (_, i) => ({
      angle: random()*Math.PI*2, radius: .35+Math.sqrt(random())*3.5,
      speed: .09+random()*.095, phase: random()*6.28, scale: .83+random()*.55,
    }));
    this.dummy = new THREE.Object3D();
    this.ripples = [];
    for (let i=0;i<8;i++) {
      const ripple = new THREE.Mesh(f.geo('lake-ripple',()=>new THREE.RingGeometry(.24,.249,36)),
        f.basic(0xb3eced,{transparent:true,opacity:.46,depthWrite:false}));
      ripple.rotation.x=-Math.PI/2;ripple.position.set((random()-.5)*5,.135,(random()-.5)*4.4);
      this.root.add(ripple);this.ripples.push(ripple);
    }
    // Snow/ice scallops at the shoreline give a modeled silhouette at close range.
    const rocks=[];
    for(let i=0;i<30;i++){
      const a=i/30*Math.PI*2;
      if(Math.cos(a)<-.94)continue;
      const rock=new THREE.Mesh(f.sphere(.20,8),f.material(0xf0f7fc));
      rock.position.set(Math.cos(a)*4.78,-.028,Math.sin(a)*4.09);rock.scale.set(1.4,.47,.8);rocks.push(rock);
    }
    this.root.add(f.batchStatic(rocks));
    this.update(0);
  }
  update(time) {
    this.material.uniforms.uTime.value=time;this.batch.reset();
    for(const a of this.fish) {
      const angle=a.angle+time*a.speed;
      const r=a.radius+Math.sin(time*.8+a.phase)*.13;
      this.dummy.position.set(Math.cos(angle)*r,.115+Math.sin(time*1.8+a.phase)*.014,Math.sin(angle)*r*.81);
      // Resource model points along +X, not +Z. Tangential headings use that convention.
      const dx=-Math.sin(angle),dz=Math.cos(angle)*.81;
      this.dummy.rotation.set(0,Math.atan2(-dz,dx)+Math.sin(time*5+a.phase)*.08,0);
      this.dummy.scale.set(a.scale,.65,a.scale);this.dummy.updateMatrix();this.batch.append(this.dummy.matrix);
    }
    this.batch.flush();
    this.ripples.forEach((m,i)=>m.scale.setScalar(.55+((time*.23+i*.14)%1)*2.1));
  }
  dispose() { this.batch.dispose();this.root.removeFromParent(); }
}
