import * as THREE from 'three';
import { AI_CAMPS, STATIONS } from '../simulation/Balance.js';

/** 商队雪橇的可视化：读 Caravans 纯逻辑状态，在柜台与邻营门口之间往返。渲染层只做显示。 */
export class CaravanView {
  constructor({ scene, factory, state }) {
    Object.assign(this, { scene, factory, state });
    this.root = new THREE.Group(); scene.add(this.root);
    this.sleds = new Map(); // routeId → { group, cargoMesh }
    this.home = new THREE.Vector3(STATIONS.market.x, 0, STATIONS.market.z);
  }
  buildSled() {
    const f = this.factory, g = new THREE.Group();
    // 雪橇：平板 + 两条滑橇 + 货物箱（沿用现有程序化语言）
    f.part(g, f.box(.62, .07, 1.05, .02), 0xdba354, 0, .16, 0);
    for (const x of [-.26, .26]) f.part(g, f.box(.06, .09, 1.18, .02), 0x8a5f36, x, .075, 0);
    const cargo = f.part(g, f.box(.44, .34, .5, .03), 0xcb9b64, 0, .38, -.1);
    f.part(g, f.cylinder(.02, .7, 6), 0x745340, 0, .30, .62, Math.PI / 2 - .3);
    const shadow = f.blob(.95, 1.35); g.add(shadow);
    g.userData.cargo = cargo;
    return g;
  }
  /** 路线进度 → 世界坐标：outbound 0..1 去程，selling 停在门口，returning 返程。 */
  positionOf(route) {
    const cv = route.caravan, camp = AI_CAMPS[route.factionId];
    if (!cv || !camp) return null;
    const target = new THREE.Vector3(camp.gate.x, 0, camp.gate.z);
    let t;
    if (cv.phase === 'outbound') t = cv.progress;
    else if (cv.phase === 'selling') t = 1;
    else t = 1 - cv.progress;
    const pos = this.home.clone().lerp(target, t);
    pos.x += Math.sin(t * Math.PI) * .6; // 轻微弧线避免完全压线
    return { pos, forward: cv.phase === 'returning' ? -1 : 1, target };
  }
  update() {
    const seen = new Set();
    for (const route of this.state.caravans.routes) {
      const spot = this.positionOf(route);
      if (!spot) continue;
      seen.add(route.id);
      let sled = this.sleds.get(route.id);
      if (!sled) { sled = this.buildSled(); this.sleds.set(route.id, sled); this.root.add(sled); }
      sled.position.copy(spot.pos);
      const dir = spot.target.clone().sub(this.home).multiplyScalar(spot.forward);
      sled.rotation.y = Math.atan2(dir.x, dir.z);
      sled.userData.cargo.visible = route.caravan.phase !== 'returning';
    }
    for (const [id, sled] of this.sleds) if (!seen.has(id)) { sled.removeFromParent(); this.sleds.delete(id); }
  }
  dispose() { this.sleds.clear(); this.root.removeFromParent(); }
}
