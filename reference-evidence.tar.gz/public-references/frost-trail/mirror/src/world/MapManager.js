import * as THREE from 'three';
import { BALANCE, STATIONS, PURCHASES, AI_CAMPS, LAMP_SLOTS, LAMP_COST, RELIC_SPOTS, STONE_WALL_SEGMENTS,
  ERA_GATED_PURCHASES, BERRY_BUSHES, FISHTRAP_RULES, DEEP_FISHING_RULES } from '../simulation/Balance.js';
import { seededRandom, easeInOutCubic, easeOutCubic } from '../utils/math.js';
import { campTexture, recipeTexture } from '../assets/ArtTextures.js';
import { PondView } from './PondView.js';

/** A readable arena first: floor, log fence, grill, crowd counter, four upgrade pads. */
export class MapManager {
  constructor({scene,factory,collision,state}) {
    Object.assign(this,{scene,factory,collision,state}); this.random=seededRandom(27);
    this.root=new THREE.Group();scene.add(this.root);this.labels=[];
    this.expansion=state.unlockedPond?1:0;this.opening=false;
    this.buildGround();this.buildFence();this.buildStations();this.buildSurroundings();this.buildPond();this.buildOutposts();
    this.buildLamps();this.buildRelics();this.buildDefenses();this.buildCorral();this.buildGreenhouse();this.buildBerryBushes();this.buildFishtraps();this.buildDeepHoles();
    this.unsubscribe=state.events.on('pond',()=>this.revealPond());
    this.annexUnsubscribe=state.events.on('faction-annexed',({id})=>this.convertOutpost(id));
    this.relicUnsubscribe=state.events.on('relic',({id})=>this.collectRelicView(id));
    this.purchaseUnsubscribe=state.events.on('purchase',key=>{if(key==='stoneWall')this.raiseWall();if(key==='watchPost')this.raiseWatchPost();});
    if(state.unlockedPond)this.finishExpansion();
    for(const f of state.factions.list())if(state.factions.getStance(f.id)==='merged')this.convertOutpost(f.id);
    for(const id of state.endgame.relics)this.collectRelicView(id);
    if(state.camp.purchases.stoneWall)this.raiseWall();
    if(state.camp.purchases.watchPost)this.raiseWatchPost();
  }
  place(mesh,x,z,y=0,parent=this.root){mesh.position.set(x,y,z);parent.add(mesh);return mesh;}
  buildGround(){
    const f=this.factory;
    const snow=new THREE.Mesh(f.geo('snow-world',()=>new THREE.PlaneGeometry(180,180)),f.material(0xe8edf4));
    snow.rotation.x=-Math.PI/2;snow.receiveShadow=true;this.root.add(snow);
    const material=new THREE.MeshStandardMaterial({map:campTexture(f),color:new THREE.Color(0xe0caca).convertSRGBToLinear(),roughness:1,transparent:true,depthWrite:true,alphaTest:.015});
    f.materials.set('camp-floor',material);
    const floor=new THREE.Mesh(f.geo('camp-floor',()=>new THREE.PlaneGeometry(14.1,12.0)),material);
    floor.renderOrder=1;floor.rotation.x=-Math.PI/2;floor.position.y=.026;floor.receiveShadow=true;this.root.add(floor);
  }
  buildFence(){
    const f=this.factory,posts=[];this.gatePosts=new THREE.Group();this.root.add(this.gatePosts);
    const put=(x,z,parent=null)=>{const p=f.createFencePost(.82);p.position.set(x,0,z);if(parent)parent.add(p);else posts.push(p);};
    for(let x=-6.65;x<=6.7;x+=.38){if(Math.abs(x)>2.65)put(x,-5.65);if(Math.abs(x)>1.5)put(x,5.65);}
    for(let z=-5.4;z<=5.5;z+=.38){
      if(Math.abs(z)>1.5)put(-6.75,z);
      if(z>.05&&z<2.8)put(6.75,z,this.gatePosts);else put(6.75,z);
    }
    this.root.add(f.batchStatic(posts));
    const west=this.place(f.createGate(2.7),-6.75,0);west.rotation.y=Math.PI/2;
    this.place(f.createGate(2.7),0,5.65);
    const c=this.collision;
    c.add('f-nw',-4.74,-5.65,4.2,.38);c.add('f-ne',4.74,-5.65,4.2,.38);
    c.add('market',0,-5.60,5.30,.86);
    c.add('f-wn',-6.75,-3.55,.38,4.1);c.add('f-ws',-6.75,3.55,.38,4.1);
    c.add('f-en',6.75,-2.86,.38,5.42);c.add('f-es',6.75,4.25,.38,2.78);
    c.add('f-sw',-4.15,5.65,5.35,.38);c.add('f-se',4.15,5.65,5.35,.38);
    c.add('gate',6.75,1.43,.42,2.95);c.add('locked-land',12.4,0,10.2,40);
    c.add('crowd',0,-10.15,7.9,7.95);c.add('fire',-.05,-.15,1.2,1.25);
  }
  buildStations(){
    const f=this.factory;
    this.fire=this.place(f.createCampfire(),-.05,-.05);
    const glow=new THREE.PointLight(0xff9d21,.55,4.2,1.7);glow.position.set(0,.55,.15);this.fire.add(glow);this.fireLight=glow;
    this.woodPad=this.place(f.createInputPad('wood'),-1.95,.15);
    this.rawPad=this.place(f.createInputPad('raw'),1.73,.65);
    this.outputPad=this.place(f.createInputPad('cooked'),-.05,-1.58);this.outputPad.scale.setScalar(.89);
    this.grillRaw=f.createResource('raw');this.grillRaw.position.set(0,1.15,-.4);this.fire.add(this.grillRaw);
    this.grillCooked=f.createResource('cooked');this.grillCooked.position.copy(this.grillRaw.position);this.fire.add(this.grillCooked);
    const recipeMat=new THREE.SpriteMaterial({map:recipeTexture(f),depthWrite:false});f.materials.set('recipe',recipeMat);
    this.recipe=new THREE.Sprite(recipeMat);this.recipe.scale.set(1.83,.92,1);this.recipe.position.set(0,2.10,-.40);this.fire.add(this.recipe);
    this.place(f.createMarket(),0,-5.63);
    this.buyPad=this.place(f.createPurchaseTile(BALANCE.pondCost,'expand'),5.57,1.4);
    this.lampPad=this.place(f.createPurchaseTile(LAMP_COST,'expand'),STATIONS.lampPad.x,STATIONS.lampPad.z);
    this.purchasePads={};
    for(const [key,definition] of Object.entries(PURCHASES)){
      const pad=this.place(f.createPurchaseTile(definition.cost,key.endsWith('Belt')?'belt':'worker'),definition.target.x,definition.target.z);
      this.purchasePads[key]=pad;
    }
    this.labels=[
      {id:'forest',title:'松林',detail:'自动伐木',position:new THREE.Vector3(-8,1,1.8),target:STATIONS.forest,type:'small'},
      {id:'hunt',title:'雪原',detail:'获取食材',position:new THREE.Vector3(0,1,7),target:STATIONS.hunt,type:'small'},
      {id:'fire',title:'营火',detail:'1 木材可烤 3 份',position:new THREE.Vector3(0,2.4,0),target:STATIONS.fire,type:'small'},
      {id:'rawStock',title:'食材料仓',detail:'带生肉时存入，空手重返取用',position:new THREE.Vector3(1.65,.8,3.9),target:STATIONS.rawStock,type:'small'},
      {id:'market',title:'供货柜台',detail:'出售 · 收取现金',position:new THREE.Vector3(0,1.4,-5.8),target:STATIONS.market,type:'market'},
      {id:'buy',title:'冰湖',detail:'$200',position:new THREE.Vector3(5.57,.3,1.4),target:STATIONS.buy,type:'buy',show:()=>!this.state.unlockedPond},
      {id:'fish',title:'冰湖钓场',detail:'站在栈桥钓鱼',position:new THREE.Vector3(8.05,1.1,1.4),target:STATIONS.fish,type:'small',show:()=>this.state.unlockedPond},
    ];
  }
  buildSurroundings(){
    const f=this.factory,decor=[];
    const rows=[[-14.5,-11.5],[-12,-11.8],[-9.4,-12],[-14.3,-8.6],[-11.8,-8.8],[-9.3,-9],
      [-15.5,-5.3],[-15.7,-2.6],[-15.4,.4],[-15,3.8],[-14,6.5],[-11.4,6.6],[-9.3,7.1],
      [-7.6,10.5],[-7.8,13.3],[-4.7,15.2],[5.9,14.8],[8.4,11.9],[9.3,8.6],
      [6.9,-10.7],[9.6,-10.2],[12.2,-9.2],[15.5,-7.2],[15.9,8.9],[-5.7,-14.6],[5.7,-14.6]];
    for(const [x,z]of rows){
      const tree=f.createTree(.65+this.random()*.26,true);tree.position.set(x,0,z);decor.push(tree);
      const shadow=f.blob(2.15,1.75);shadow.position.x=x;shadow.position.z=z;decor.push(shadow);
    }
    for(let i=0;i<15;i++){
      const x=(this.random()-.5)*35,z=(this.random()-.5)*30;
      if(Math.abs(x)<8&&Math.abs(z)<7||x>7&&x<17&&z>-4&&z<7)continue;
      const rock=new THREE.Mesh(f.geo('snow-rock',()=>new THREE.IcosahedronGeometry(.36,1)),f.material(0xd4dfed));
      rock.position.set(x,-.07,z);rock.scale.set(1,.45,1.2);rock.receiveShadow=true;decor.push(rock);
    }
    this.root.add(f.batchStatic(decor));
    this.lockedForest=new THREE.Group();this.root.add(this.lockedForest);const locked=[];
    for(const [x,z]of [[9,-.5],[11.1,0],[10,2.9],[12.8,3],[13,-2.5],[15.2,.4]]){
      const t=f.createTree(.84+this.random()*.15,true);t.position.set(x,0,z);locked.push(t);
    }
    this.lockedForest.add(f.batchStatic(locked));
  }
  /** 五座邻营的可视实体（帐篷/货箱/小营火/势力旗帜），碰撞注册为营地体，门口留路供玩家走近。 */
  buildOutposts(){
    const f=this.factory;this.outposts={};
    const names=Object.fromEntries(this.state.factions.list().map(x=>[x.id,x.name]));
    for(const [id,camp]of Object.entries(AI_CAMPS)){
      const g=new THREE.Group();g.position.set(camp.x,0,camp.z);this.root.add(g);
      // 主帐篷：雪地锥形 + 营地色檐带
      f.part(g,f.snowCone(1.45,1.55),0xd9cbb8,0,0,0);
      f.part(g,f.cylinder(1.10,.16,14,1.28),camp.color,0,.42,0);
      f.part(g,f.sphere(.16,8),0xf4e8d0,0,1.62,0);
      // 小帐篷与货箱
      f.part(g,f.snowCone(.85,.95),0xcfc2b0,-1.55,0,.85);
      const crate=f.createCrate();crate.position.set(1.35,0,.95);crate.scale.setScalar(.8);g.add(crate);
      // 小营火（石圈+火球，夜晚呼应灯光）
      const stone=f.geo('grill-stone',()=>new THREE.IcosahedronGeometry(.19,1));
      for(let i=0;i<8;i++){const a=i/8*Math.PI*2;const rock=f.part(g,stone,0x8c8d9b,Math.cos(a)*.32-.6,.10,Math.sin(a)*.32-.75);rock.scale.set(.7,.5,.8);}
      const ember=f.part(g,f.sphere(.14,8),f.basic(0xffa11b),-.6,.16,-.75);ember.scale.set(1,1.5,1);
      // 旗帜（吞并后换色为玩家绿）
      f.part(g,f.cylinder(.035,2.2,8),0x6b4f38,1.7,1.1,.2);
      const cloth=f.part(g,f.box(.72,.42,.035,.01),camp.color,2.08,1.85,.2);
      this.collision.add(`camp-${id}`,camp.x,camp.z,3.6,3.2);
      this.outposts[id]={root:g,cloth};
      this.labels.push({id:`outpost-${id}`,title:names[id]??id,detail:'邻营 · 点击前往门口',
        position:new THREE.Vector3(camp.x,2.6,camp.z),target:{...camp.gate},type:'outpost'});
    }
  }
  /** 吞并后：营旗换成玩家绿，转为前哨。 */
  convertOutpost(id){
    const out=this.outposts?.[id];if(!out)return;
    out.cloth.material=this.factory.material(0x6fcf5a);
  }
  /** 灯网实体：灯位预立空杆（灯位引导），购得的灯柱点亮灯头；亮度由昼夜 lampGlow 驱动。 */
  buildLamps(){
    const f=this.factory;this.lampHeads=[];
    this.lampGlowMat=new THREE.MeshBasicMaterial({color:0x2a2118}); // 夜晚由 lampGlow 点亮
    for(const slot of LAMP_SLOTS){
      const g=new THREE.Group();g.position.set(slot.x,0,slot.z);this.root.add(g);
      f.part(g,f.cylinder(.05,1.5,8),0x6b4f38,0,.75,0);
      f.part(g,f.box(.16,.06,.16,.02),0x54381f,0,.04,0);
      const head=new THREE.Mesh(f.sphere(.13,10),this.lampGlowMat);head.position.set(0,1.56,0);g.add(head);
      const cage=f.part(g,f.cylinder(.16,.08,8,.10),0x54381f,0,1.72,0);
      this.lampHeads.push({head,cage});
    }
  }
  /** 五件先民遗物：石碑 + 悬浮发光晶体；收集后晶体熄灭。 */
  buildRelics(){
    const f=this.factory;this.relicViews={};
    this.relicGlowMat=new THREE.MeshBasicMaterial({color:0xffd98a});
    for(const [id,spot] of Object.entries(RELIC_SPOTS)){
      const g=new THREE.Group();g.position.set(spot.x,0,spot.z);this.root.add(g);
      f.part(g,f.box(.52,1.15,.32,.03),0x91a8ba,0,.575,0);
      f.part(g,f.box(.62,.14,.42,.03),0x7d93a6,0,.07,0);
      const crystal=new THREE.Mesh(f.geo(`relic-crystal`,()=>new THREE.OctahedronGeometry(.21,0)),this.relicGlowMat);
      crystal.position.set(0,1.55,0);g.add(crystal);
      const shadow=f.blob(1,.9);g.add(shadow);
      this.collision.add(`relic-${id}`,spot.x,spot.z,.75,.75);
      this.relicViews[id]={root:g,crystal};
      this.labels.push({id:`relic-${id}`,title:`遗物 · ${spot.name}`,detail:'走近驻留收集',
        position:new THREE.Vector3(spot.x,2.2,spot.z),target:{x:spot.x+1.0,z:spot.z+1.0},type:'relic',
        show:()=>!this.state.endgame.relics.has(id)});
    }
  }
  /** 石墙（北门夹道，真实碰撞）与警戒哨塔实体，购得后升起。 */
  buildDefenses(){
    const f=this.factory;
    this.wallGroup=new THREE.Group();this.wallGroup.visible=false;this.root.add(this.wallGroup);
    for(const seg of STONE_WALL_SEGMENTS){
      for(let i=0;i<3;i++)this.wallGroup.add((()=>{const b=new THREE.Mesh(f.box(seg.w,.34,seg.d,.05),f.material(i%2?0x8f9fb0:0x9fb0c1));b.position.set(seg.x,.17+i*.33,seg.z);b.castShadow=b.receiveShadow=true;return b;})());
    }
    const t=new THREE.Group();t.position.set(5.9,0,4.6);t.visible=false;this.root.add(t);this.watchTower=t;
    for(const [x,z]of [[-.3,-.3],[.3,-.3],[-.3,.3],[.3,.3]])f.part(t,f.cylinder(.06,1.9,8),0x8a5f36,x,.95,z);
    f.part(t,f.box(.95,.09,.95,.03),0xa9744a,0,1.92,0);
    f.part(t,f.box(1.05,.34,1.05,.03),0x7c5738,0,2.15,0);
    f.part(t,f.snowCone(.78,.6),0xdbe7f3,0,2.32,0);
  }
  raiseWall(){
    if(this.wallGroup.visible)return;this.wallGroup.visible=true;
    STONE_WALL_SEGMENTS.forEach((seg,i)=>this.collision.add(`stone-wall-${i}`,seg.x,seg.z,seg.w,seg.d));
  }
  raiseWatchPost(){
    if(this.watchTower.visible)return;this.watchTower.visible=true;
    this.collision.add('watch-post',5.9,4.6,.95,.95);
  }
  collectRelicView(id){const v=this.relicViews?.[id];if(v)v.crystal.visible=false;}
  /** 驯鹿围栏：栏栅 + 鹿群容器（鹿数量每帧与权威状态同步）。 */
  buildCorral(){
    const f=this.factory,g=new THREE.Group();g.position.set(STATIONS.corral.x,0,STATIONS.corral.z);g.visible=false;this.root.add(g);
    // 三面栏栅（南侧留门）
    const rails=[];
    for(let x=-1.5;x<=1.5;x+=.38){rails.push(f.createFencePost(.6));rails.at(-1).position.set(x,0,-1.3);}
    for(const sx of [-1.6,1.6])for(let z=-1.1;z<=1.1;z+=.38){rails.push(f.createFencePost(.6));rails.at(-1).position.set(sx,0,z);}
    g.add(f.batchStatic(rails));
    this.deerLayer=new THREE.Group();g.add(this.deerLayer);
    this.deerMeshes=[];
    this.corralGroup=g; // 栏体碰撞在建成后 sync 时注册
  }
  makeDeer(){
    const f=this.factory,d=new THREE.Group();
    f.part(d,f.capsule(.16,.3),0xb99a76,0,.42,0,Math.PI/2);           // 躯干
    f.part(d,f.sphere(.12,8),0xc9ad8a,0,.55,.26);                      // 头
    for(const s of [-1,1])f.part(d,f.cylinder(.015,.22,5),0x8a7355,s*.06,.68,.30,0,0,s*.5); // 角
    for(const s of [-1,1])f.part(d,f.cylinder(.035,.3,6),0x9a7f60,s*.10,.15,.12);
    for(const s of [-1,1])f.part(d,f.cylinder(.035,.3,6),0x9a7f60,s*.10,.15,-.12);
    return d;
  }
  /** 温室种植箱：木框 + 透光顶棚（购得后才有碰撞）。 */
  buildGreenhouse(){
    const f=this.factory,g=new THREE.Group();g.position.set(STATIONS.greenhouse.x,0,STATIONS.greenhouse.z);g.visible=false;this.root.add(g);
    f.part(g,f.box(1.7,.5,.9,.04),0xa9744a,0,.25,0);
    const glass=new THREE.Mesh(f.box(1.6,.5,.8,.03),f.material(0xcfeef5,{transparent:true,opacity:.45,roughness:.15}));
    glass.position.set(0,.75,0);glass.castShadow=true;g.add(glass);
    f.part(g,f.box(1.5,.16,.6,.03),0x6f9a55,0,.56,0); // 苗床
    this.greenhouseGroup=g;
  }
  /** 雪莓丛：灌木球 + 莓果簇（枯萎期莓果隐藏）。 */
  buildBerryBushes(){
    const f=this.factory;this.berryViews={};
    for(const b of BERRY_BUSHES){
      const g=new THREE.Group();g.position.set(b.x,0,b.z);this.root.add(g);
      f.part(g,f.sphere(.42,10),0x4e6d54,0,.30,0);
      f.part(g,f.sphere(.30,8),0x5b7f61,.28,.38,.1);
      const berries=new THREE.Group();
      for(const [x,y,z]of [[-.2,.42,.15],[.25,.5,-.05],[0,.55,.25],[-.05,.35,-.25]]){
        const berry=new THREE.Mesh(f.sphere(.05,6),f.basic(0x9a6fd0));berry.position.set(x,y,z);berries.add(berry);
      }
      g.add(berries);this.berryViews[b.id]={root:g,berries};
    }
  }
  /** 深水冰洞：深色冰窟 + 浮标灯（灯网 Lv2 未达或储量耗尽则熄灯）。 */
  buildDeepHoles(){
    const f=this.factory;this.deepHoleViews=[];
    DEEP_FISHING_RULES.holes.forEach((h,i)=>{
      const g=new THREE.Group();g.position.set(h.x,0,h.z);this.root.add(g);
      const hole=new THREE.Mesh(f.geo('deep-hole',()=>new THREE.CircleGeometry(.55,18)),f.material(0x2e4a5e));
      hole.rotation.x=-Math.PI/2;hole.position.y=.03;g.add(hole);
      f.part(g,f.cylinder(.05,.5,6),0x745340,.5,.25,.3,0,0,.2);
      const lamp=new THREE.Mesh(f.sphere(.09,8),f.basic(0xffd98a));lamp.position.set(.56,.52,.34);g.add(lamp);
      this.deepHoleViews.push({root:g,lamp});
      this.labels.push({id:`deep-${i}`,title:'深水冰洞',detail:'灯网 Lv.2 解锁 · 快速渔获 · 储量有限',
        position:new THREE.Vector3(h.x,1.4,h.z),target:{x:h.x,z:h.z},type:'deepfish'});
    });
  }
  /** 鱼陷阱：冰湖上的木框浮标，按数量显示。 */
  buildFishtraps(){
    const f=this.factory;this.trapViews=[];
    this.trapPad=this.place(f.createPurchaseTile(FISHTRAP_RULES.cost,'expand'),STATIONS.trapPad.x,STATIONS.trapPad.z);
    for(const [x,z]of [[9.5,2.6],[10.2,1.0]]){
      const g=new THREE.Group();g.position.set(x,0,z);g.visible=false;this.root.add(g);
      f.part(g,f.box(.55,.08,.40,.02),0x8a6a44,0,.06,0);
      f.part(g,f.cylinder(.05,.5,6),0xd8eef0,.15,.3,0,0,0,.3);
      this.trapViews.push(g);
    }
  }
  buildPond(){
    this.pond=new THREE.Group();this.root.add(this.pond);this.pond.visible=this.state.unlockedPond;
    this.pondView=new PondView(this.factory,this.pond);this.lake=this.pondView.root;this.fish=this.pondView.fish;
    const f=this.factory,boards=[];
    for(let i=0;i<13;i++){
      const b=new THREE.Mesh(f.box(.20,.14,1.35,.022),f.material(i%2?0xd6ac72:0xe8c488));
      b.position.set(7.05+i*.2,.12,1.4);b.castShadow=true;b.receiveShadow=true;boards.push(b);
    }
    for(const x of [7.35,9.05])for(const z of [.82,1.98]){const p=f.createFencePost(.50);p.position.set(x,-.13,z);boards.push(p);}
    this.dock=f.batchStatic(boards);this.pond.add(this.dock);
    this.float=this.place(new THREE.Group(),9.9,1.70,.16,this.pond);
    f.part(this.float,f.sphere(.07,10),0xed7953,0,0,0);f.part(this.float,f.sphere(.037,8),0xfff2b5,0,.055,0);
  }
  revealPond(){this.opening=true;this.expansion=0;this.pond.visible=true;this.lake.scale.setScalar(.001);}
  finishExpansion(){
    this.opening=false;this.expansion=1;this.gatePosts.visible=false;this.lockedForest.visible=false;this.buyPad.visible=false;
    this.pond.visible=true;this.lake.scale.setScalar(1);this.dock.position.y=0;
    this.collision.remove('gate');this.collision.remove('locked-land');
    this.collision.add('pond-water',13.2,1.4,7.70,7.85);
  }
  update(dt,time){
    const s=this.state,c=s.camp;
    const burning=!!s.cooking||c.fuel>0;
    this.fire.userData.flames.forEach((flame,i)=>{
      const flicker=.9+Math.sin(time*10+i*1.7)*.16;
      flame.scale.set(flicker,(burning?1.13:.75)+Math.sin(time*12+i)*.15,flicker);
      flame.rotation.y=Math.sin(time*3+i)*.13;
    });
    this.fireLight.intensity=(burning?.55:.23)+Math.sin(time*13)*.05;
    this.grillRaw.visible=!!s.cooking&&s.cooking.remaining>.5;
    this.grillCooked.visible=!!s.cooking&&s.cooking.remaining<=.5;
    this.recipe.visible=s.stats.cooked<1||(!s.canFuel(true)&&s.count('raw')>0);
    this.woodPad.userData.active.visible=c.feed.wood>0||c.fuel>0;
    this.rawPad.userData.active.visible=c.feed.raw>0||!!s.cooking;
    this.outputPad.userData.active.visible=c.stock.cooked>0;
    for(const [key,pad]of Object.entries(this.purchasePads)){
      const gated=ERA_GATED_PURCHASES[key]&&s.ages.getEra()<ERA_GATED_PURCHASES[key]; // 时代门槛未到不显示垫子
      pad.visible=!c.purchases[key]&&!gated;
      pad.userData.outline.visible=s.cash>=PURCHASES[key].cost;
    }
    this.buyPad.userData.outline.visible=s.cash>=BALANCE.pondCost;
    this.lampPad.userData.outline.visible=s.cash>=LAMP_COST&&s.lampNetwork.lamps.length<LAMP_SLOTS.length;
    if(this.opening){
      this.expansion=Math.min(1,this.expansion+dt/1.5);const t=easeInOutCubic(this.expansion);
      this.gatePosts.position.y=-t*1.5;this.lockedForest.visible=t<.26;
      this.lake.scale.setScalar(Math.max(.001,easeOutCubic(Math.max(0,(t-.16)/.84))));this.dock.position.y=-.35*(1-t);
      if(this.expansion>=1)this.finishExpansion();
    }
    if(this.pond.visible){this.pondView.update(time);this.float.position.y=.16+Math.sin(time*3.3)*.025;}
    // 灯网：已购灯柱点亮灯头，夜晚 lampGlow 推亮度（发光材质，无额外点光源开销）
    const lit=this.state.lampNetwork.lamps.length,glow=this.state.dayNight.getLighting().lampGlow;
    this.lampGlowMat.color.setRGB(.30+.70*glow,.20+.48*glow,.09+.22*glow);
    this.lampHeads.forEach((l,i)=>{l.head.visible=i<lit;});
    // 畜牧/温室/莓丛/鱼陷阱视觉与权威状态同步
    this.corralGroup.visible=c.purchases.corral;
    if(c.purchases.corral&&!this.corralCollided){this.corralCollided=true;this.collision.add('corral-pen',STATIONS.corral.x,STATIONS.corral.z-.2,3.4,1.6);}
    while(this.deerMeshes.length<s.corralDeer.length){const d=this.makeDeer();this.deerMeshes.push(d);this.deerLayer.add(d);}
    while(this.deerMeshes.length>s.corralDeer.length)this.deerMeshes.pop().removeFromParent();
    this.deerMeshes.forEach((d,i)=>{d.position.set(-.9+i*.62,0,.15+(i%2)*.5);d.rotation.y=Math.sin(time*.7+i)*.4;});
    this.greenhouseGroup.visible=c.purchases.greenhouse;
    if(c.purchases.greenhouse&&!this.greenhouseCollided){this.greenhouseCollided=true;this.collision.add('greenhouse',STATIONS.greenhouse.x,STATIONS.greenhouse.z,1.8,1.0);}
    for(const b of BERRY_BUSHES)this.berryViews[b.id].berries.visible=s.berryBushes[b.id].ready;
    this.trapViews.forEach((t,i)=>t.visible=i<s.camp.fishtraps);
    this.trapPad.visible=s.unlockedPond&&c.fishtraps<FISHTRAP_RULES.max;
    this.trapPad.userData.outline.visible=s.cash>=FISHTRAP_RULES.cost&&s.canAffordLoad(1);
    // 深渔区浮标灯：灯网 Lv2 且洞内有鱼才亮
    this.deepHoleViews.forEach((v,i)=>{v.lamp.visible=s.lampNetwork.getNetworkLevel()>=DEEP_FISHING_RULES.lampLevel&&s.deepFishing[`hole-${i}`].stock>0;});
    // 遗物晶体悬浮缓动
    for(const v of Object.values(this.relicViews))if(v.crystal.visible){v.crystal.position.y=1.55+Math.sin(time*2.1)*.08;v.crystal.rotation.y=time*.8;}
  }
  dispose(){this.unsubscribe();this.annexUnsubscribe();this.relicUnsubscribe();this.purchaseUnsubscribe();this.pondView.dispose();this.root.removeFromParent();}
}
