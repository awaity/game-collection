/** Axis-aligned player/zone overlap. Vertical stack height is deliberately ignored. */
export class TriggerZone {
  constructor({ x, z, width, depth, onEnter, onExit, onStay }) {
    Object.assign(this, { x, z, width, depth, onEnter, onExit, onStay }); this.inside = false;
  }
  contains(position, radius = 0.32) {
    return Math.abs(position.x - this.x) <= this.width / 2 + radius &&
      Math.abs(position.z - this.z) <= this.depth / 2 + radius;
  }
  update(position, dt, radius = 0.32) {
    const next = this.contains(position, radius);
    if (next && !this.inside) this.onEnter?.();
    if (!next && this.inside) this.onExit?.();
    this.inside = next; if (next) this.onStay?.(dt);
  }
  reset() { this.inside = false; }
}
