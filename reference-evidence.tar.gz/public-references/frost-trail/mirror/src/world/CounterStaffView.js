import * as THREE from 'three';
import { STAFF_ROLES, STAFF_RULES } from '../simulation/CounterStaff.js';
import { ResourceBatch } from '../render/ResourceBatch.js';
import { canvasTexture } from '../assets/ArtTextures.js';
import { damp } from '../utils/math.js';

/** Presentation only: goods and money are committed by the simulation first. */
export class CounterStaffView {
  constructor({ scene, factory, state, effects, player }) {
    Object.assign(this, { factory, state, effects, player });
    this.root = new THREE.Group();
    scene.add(this.root);
    this.actors = new Map();
    this.dummy = new THREE.Object3D();
    this.up = new THREE.Vector3(0, 1, 0);
    this.rotation = new THREE.Quaternion();
    this.cashTarget = new THREE.Vector3();
    this.unsubscribers = [
      state.events.on('staff-hired', () => this.sync()),
      state.events.on('sold', event => {
        if (event.source !== 'staff') return;
        const seller = state.camp.staff.seller, lane = (state.stats.sold % 9 - 4) * .55;
        effects.fly(event.item.type, new THREE.Vector3(seller.x, 1.3, seller.z), new THREE.Vector3(lane, 1.5, -6.25), { arc: 1, duration: .4 });
        effects.fly('cash', new THREE.Vector3(lane, 1.4, -6.25), new THREE.Vector3(1.7, 1.1, -5.6), { arc: .8, duration: .45 });
      }),
      state.events.on('staff-collected', () => {
        const actor = this.actors.get('cashier');
        if (actor) actor.action = .5;
        effects.fly('cash', new THREE.Vector3(1.7, 1.1, -5.6), () => player.getCashPickupPosition(this.cashTarget), { arc: 1.3, duration: .55 });
      }),
    ];
    this.sync();
    this.update(0);
  }

  sync() {
    for (const [role, config] of Object.entries(STAFF_ROLES)) {
      const data = this.state.camp.staff[role];
      if (!data.hired || this.actors.has(role)) continue;
      const { root, visual } = this.factory.createWorker(role);
      this.root.add(root);
      root.position.set(data.x, 0, data.z);
      root.rotation.y = Math.PI;
      root.add(this.factory.blob(.95, .8));
      this.factory.part(visual, this.factory.box(.4, .4, .045, .02), 0xf9efd7, 0, .77, .29);
      const cargo = new THREE.Group();
      cargo.position.set(0, 1, -.46);
      root.add(cargo);
      const batches = Object.fromEntries(STAFF_RULES.goods.map(type => [type, new ResourceBatch(this.factory, type, STAFF_RULES.capacity, cargo)]));
      const texture = canvasTexture(this.factory, `counter-staff-${role}`, 192, 76, ctx => {
        ctx.fillStyle = role === 'seller' ? '#ad572b' : '#287a60';
        ctx.beginPath(); ctx.roundRect(2, 2, 188, 64, 20); ctx.fill();
        ctx.fillStyle = '#fffaf0'; ctx.font = 'bold 30px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText(config.name, 96, 35);
      });
      const material = new THREE.SpriteMaterial({ map: texture, depthWrite: false, depthTest: false });
      this.factory.materials.set(`counter-staff-label-${role}`, material);
      const label = new THREE.Sprite(material);
      label.position.set(0, 2.7, 0); label.scale.set(1.55, .62, 1); label.renderOrder = 10;
      root.add(label);
      this.actors.set(role, { root, visual, batches, stride: 0, action: 0 });
    }
  }

  update(dt) {
    for (const [role, actor] of this.actors) {
      const data = this.state.camp.staff[role];
      const dx = data.x - actor.root.position.x, dz = data.z - actor.root.position.z;
      const moving = Math.hypot(dx, dz) > .001;
      this.rotation.setFromAxisAngle(this.up, moving ? Math.atan2(dx, dz) : Math.PI);
      actor.root.quaternion.slerp(this.rotation, dt ? damp(12, dt) : 1);
      actor.root.position.set(data.x, 0, data.z);
      actor.stride += moving ? dt * 11 : 0;
      actor.action = Math.max(0, actor.action - dt);
      const rig = actor.visual.userData.rig, walk = moving ? Math.sin(actor.stride) * .6 : 0;
      rig.legs[0].rotation.x = walk; rig.legs[1].rotation.x = -walk;
      rig.arms[0].rotation.x = data.cargo ? -.55 : -walk * .6;
      rig.arms[1].rotation.x = actor.action ? -Math.sin(actor.action * Math.PI * 2) : walk * .6;
      actor.visual.position.y = moving ? Math.abs(Math.sin(actor.stride)) * .035 : 0;
      for (const [type, batch] of Object.entries(actor.batches)) {
        batch.reset();
        if (data.cargo?.type === type) for (let i = 0; i < data.cargo.count; i++) {
          this.dummy.position.set(0, i * .18, 0);
          this.dummy.updateMatrix(); batch.append(this.dummy.matrix);
        }
        batch.flush();
      }
    }
  }

  dispose() {
    this.unsubscribers.forEach(unsubscribe => unsubscribe());
    for (const actor of this.actors.values()) for (const batch of Object.values(actor.batches)) batch.dispose();
    this.actors.clear(); this.root.removeFromParent();
  }
}
