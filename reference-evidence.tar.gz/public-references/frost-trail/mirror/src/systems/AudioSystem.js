/** Self-contained Web Audio effects; no copyrighted recordings or external requests. */
export class AudioSystem {
  constructor(){this.context=null;this.enabled=true;this.paused=false;this.active=0;this.last={};}
  unlock(){
    try{
      if(!this.context){const Context=window.AudioContext||window.webkitAudioContext;if(!Context)return;
        this.context=new Context();this.master=this.context.createGain();this.master.gain.value=this.enabled&&!this.paused?0.16:0;this.master.connect(this.context.destination);
        const buffer=this.context.createBuffer(1,this.context.sampleRate*3,this.context.sampleRate),data=buffer.getChannelData(0);let last=0;
        for(let i=0;i<data.length;i++){last=(last+(Math.random()*2-1)*0.02)/1.025;data[i]=last;}
        this.wind=this.context.createBufferSource();this.wind.buffer=buffer;this.wind.loop=true;
        const filter=this.context.createBiquadFilter();filter.type='lowpass';filter.frequency.value=460;
        const gain=this.context.createGain();gain.gain.value=0.12;this.wind.connect(filter);filter.connect(gain);gain.connect(this.master);this.wind.start();
      }
      this.context.resume().catch(()=>{});this.applyGain();
    }catch{this.enabled=false;}
  }
  setEnabled(value){this.enabled=!!value;if(value)this.unlock();this.applyGain();}
  setPaused(value){this.paused=value;this.applyGain();}
  applyGain(){if(this.context&&this.master)this.master.gain.setTargetAtTime(this.enabled&&!this.paused?0.16:0,this.context.currentTime,0.06);}
  play(kind){
    if(!this.context||!this.enabled||this.paused||this.active>20)return;
    const ctx=this.context,t=ctx.currentTime;if(t-(this.last[kind]??-100)<0.045)return;this.last[kind]=t;
    const settings={pickup:[720,1040,0.065,'sine'],chop:[170,90,0.11,'triangle'],hit:[200,80,0.1,'triangle'],cook:[320,220,0.15,'sine'],ready:[540,810,0.19,'sine'],sell:[1050,1600,0.08,'sine'],quest:[660,990,0.35,'sine'],unlock:[390,1170,0.60,'triangle']}[kind]??[500,600,0.1,'sine'];
    const [start,end,length,type]=settings,osc=ctx.createOscillator(),gain=ctx.createGain();osc.type=type;osc.frequency.setValueAtTime(start,t);osc.frequency.exponentialRampToValueAtTime(end,t+length);
    gain.gain.setValueAtTime(0.001,t);gain.gain.linearRampToValueAtTime(0.28,t+0.008);gain.gain.exponentialRampToValueAtTime(0.001,t+length);
    osc.connect(gain);gain.connect(this.master);this.active++;osc.onended=()=>{osc.disconnect();gain.disconnect();this.active--;};osc.start(t);osc.stop(t+length+0.01);
  }
  dispose(){try{this.wind?.stop();this.context?.close().catch(()=>{});}catch{}}
}
