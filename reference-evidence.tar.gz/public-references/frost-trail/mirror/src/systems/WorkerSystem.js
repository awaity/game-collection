import * as THREE from 'three';
import { BALANCE, STATIONS } from '../simulation/Balance.js';
import { ResourceBatch } from '../render/ResourceBatch.js';
import { damp } from '../utils/math.js';

/** Workers visit the SAME finite trees/bears as the player, carry real cargo, and
 * deposit it into finite stores. Cargo and positions are in the saved GameState. */
export class WorkerSystem {
  constructor({ scene, factory, state, collision, resources, effects, audio }) {
    Object.assign(this, { scene, factory, state, collision, resources, effects, audio });
    this.root = new THREE.Group(); scene.add(this.root); this.workers = new Map();
    this.dummy = new THREE.Object3D(); this.time = 0;
    this.sync(); this.unsubscribe = state.events.on('purchase', () => this.sync());
  }
  sync() {
    for (const data of this.state.camp.workers) {
      if (this.workers.has(data.id)) continue;
      const { root, visual } = this.factory.createWorker(data.role); this.root.add(root);
      const cargo = new THREE.Group(); cargo.position.set(0, .92, -.4); root.add(cargo);
      const batch = new ResourceBatch(this.factory, data.role, BALANCE.workerCapacity, cargo);
      const shadow = this.factory.blob(1, .88); root.add(shadow);
      const safe = this.collision.nearestFree(data) ?? this.collision.nearestFree(STATIONS[data.role==='wood'?'woodcutters':'hunters']) ?? this.collision.nearestFree({x:-2.2,z:2.1});
      if (safe) { data.x = safe.x; data.z = safe.z; }
      root.position.set(data.x, 0, data.z);
      this.workers.set(data.id, { data, root, visual, batch, path: [], target: null,
        mode: data.cargo > 0 ? 'return' : 'seek', timer: 0, retry: 0, stride: 0, action: 0,
        rotation: new THREE.Quaternion(), up: new THREE.Vector3(0, 1, 0), lastCargo: -1 });
      if(data.cargo>0)this.returnToCamp(this.workers.get(data.id));
    }
  }
  route(worker, target) {
    worker.path = this.collision.findPath(worker.data, target);
    return worker.path.length > 0;
  }
  seek(worker) {
    const role = worker.data.role;
    const list = role === 'wood' ? this.resources.trees : this.resources.bears;
    const taken = new Set([...this.workers.values()].filter(w => w !== worker && w.target).map(w => w.target));
    const candidates = list.filter(e => e.data.active && !taken.has(e))
      .sort((a,b) => Math.hypot(a.data.x-worker.data.x,a.data.z-worker.data.z) - Math.hypot(b.data.x-worker.data.x,b.data.z-worker.data.z));
    for (const entry of candidates) {
      let dx = worker.data.x-entry.data.x, dz = worker.data.z-entry.data.z;
      const length = Math.hypot(dx,dz) || 1; dx/=length; dz/=length;
      const target = { x: entry.data.x+dx*1.25, z: entry.data.z+dz*1.25 };
      if (this.route(worker,target)) { worker.target=entry;worker.mode='harvest';return true; }
    }
    worker.retry=.8;return false;
  }
  move(worker, dt) {
    let moved = false;
    while (worker.path.length) {
      const p=worker.path[0], d=worker.data, dx=p.x-d.x,dz=p.z-d.z, length=Math.hypot(dx,dz);
      if(length<.11){worker.path.shift();continue;}
      const step=Math.min(length,BALANCE.workerSpeed*dt),oldX=d.x,oldZ=d.z;
      this.collision.move(d,dx/length*step,dz/length*step);
      moved=Math.hypot(d.x-oldX,d.z-oldZ)>.001;
      worker.rotation.setFromAxisAngle(worker.up,Math.atan2(dx,dz));
      worker.root.quaternion.slerp(worker.rotation,damp(14,dt));
      if(!moved){worker.retry+=dt;if(worker.retry>.65){worker.path=[];worker.mode='seek';worker.target=null;worker.retry=.5;}}
      else worker.retry=0;
      break;
    }
    return moved;
  }
  returnToCamp(worker) {
    const point=worker.data.role==='wood'?STATIONS.woodStock:STATIONS.rawStock;
    // Small lateral offsets stop two workers occupying the same delivery point.
    const index=Number(worker.data.id.slice(-1));
    this.route(worker,{x:point.x+(index? .53:-.53),z:point.z+.62});
    worker.target=null;worker.mode='return';
  }
  update(dt) {
    this.time+=dt;
    for(const worker of this.workers.values()) {
      const d=worker.data;worker.timer=Math.max(0,worker.timer-dt);worker.action=Math.max(0,worker.action-dt*4);
      const moved=this.move(worker,dt);
      if(!worker.path.length) {
        if(worker.mode==='return') {
          const destination=d.role==='wood'?STATIONS.woodStock:STATIONS.rawStock;
          if(Math.hypot(d.x-destination.x,d.z-destination.z)>1.3){
            worker.retry-=dt;if(worker.retry<=0){this.returnToCamp(worker);worker.retry=.6;}
            continue;
          }
          const stock=this.state.camp.stock;
          if(d.cargo>0&&stock[d.role]<BALANCE.maxStock&&worker.timer<=0){
            stock[d.role]++;d.cargo--;worker.timer=.11;
            const point=d.role==='wood'?STATIONS.woodStock:STATIONS.rawStock;
            this.effects.fly(d.role,new THREE.Vector3(d.x,1.3,d.z),new THREE.Vector3(point.x,.6,point.z),{arc:.7,duration:.35,scale:.9});
            this.state.changed('worker-delivery',{role:d.role});
          }
          if(!d.cargo){worker.mode='seek';worker.retry=.25;}
        } else if(worker.mode==='seek') {
          if(d.cargo>0){this.returnToCamp(worker);}
          else {worker.retry-=dt;if(worker.retry<=0)this.seek(worker);}
        } else if(worker.mode==='harvest') {
          const target=worker.target;
          if(!target?.data.active){worker.target=null;worker.mode='seek';continue;}
          const dx=target.data.x-d.x,dz=target.data.z-d.z;
          if(Math.hypot(dx,dz)>1.95){worker.target=null;worker.mode='seek';continue;}
          worker.rotation.setFromAxisAngle(worker.up,Math.atan2(dx,dz));worker.root.quaternion.slerp(worker.rotation,damp(12,dt));
          if(worker.timer<=0){
            worker.timer=(d.role==='wood'?.58:.63)/this.state.getGatherMultiplier(d.role)/this.state.getGatherBuffFactor();worker.action=1;
            const loot=this.resources.strike(target,d.role==='wood'?'tree':'bear',{position:d,worker:true});
            if(loot){
              const amount=Math.min(BALANCE.workerCapacity-d.cargo,loot.count);d.cargo+=amount;
              this.state.stats[d.role==='wood'?'workerWood':'workerRaw']+=amount;
              if(loot.count>amount)this.resources.drop(d.role,d.x,d.z,loot.count-amount);
              this.state.changed('worker-harvest',{role:d.role,amount});
              this.returnToCamp(worker);
            }
          }
        }
      }
      worker.root.position.set(d.x,0,d.z);
      worker.stride+=moved?dt*11:0;
      const rig=worker.visual.userData.rig;
      const walk=moved?Math.sin(worker.stride)*.65:0;
      rig.legs[0].rotation.x=walk;rig.legs[1].rotation.x=-walk;
      rig.arms[0].rotation.x=-walk*.6;
      rig.arms[1].rotation.x=worker.action?-Math.sin(worker.action*Math.PI)*2.1:walk*.6;
      rig.tool.visible=worker.action>0;
      worker.visual.position.y=moved?Math.abs(Math.sin(worker.stride))*.04:0;
      worker.batch.reset();
      for(let i=0;i<d.cargo;i++){
        this.dummy.position.set(Math.sin(this.time*7-i*.3)*i*.005,.11+i*.21,0);
        this.dummy.rotation.set(0,0,0);this.dummy.scale.setScalar(1);this.dummy.updateMatrix();worker.batch.append(this.dummy.matrix);
      }
      worker.batch.flush();
    }
  }
  dispose(){this.unsubscribe();for(const w of this.workers.values())w.batch.dispose();this.workers.clear();this.root.removeFromParent();}
}
