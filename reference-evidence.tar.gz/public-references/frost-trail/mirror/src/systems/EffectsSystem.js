import * as THREE from 'three';
import { seededRandom } from '../utils/math.js';
import { ResourceBatch } from '../render/ResourceBatch.js';

/** Bounded pools: particles and trails cannot grow the scene indefinitely. */
export class EffectsSystem {
  constructor({scene,factory}) {
    Object.assign(this,{scene,factory});this.random=seededRandom(191);this.items=[];this.flightBatches=new Map();this.time=0;
    this.dummy=new THREE.Object3D();this.color=new THREE.Color();this.cursor=0;this.particles=Array.from({length:220},()=>({life:0}));
    const geo=factory.geo('particle',()=>new THREE.IcosahedronGeometry(0.09,0));
    const mat=factory.basic(0xffffff);this.mesh=new THREE.InstancedMesh(geo,mat,this.particles.length);this.mesh.frustumCulled=false;scene.add(this.mesh);
    this.dummy.scale.setScalar(0);this.dummy.updateMatrix();for(let i=0;i<this.particles.length;i++){this.mesh.setMatrixAt(i,this.dummy.matrix);this.mesh.setColorAt(i,new THREE.Color(0xffffff));}
    this.footprints=Array.from({length:140},()=>({life:0}));this.footCursor=0;
    const footprintGeo=factory.geo('footprint',()=>new THREE.PlaneGeometry(0.11,0.22));
    this.footMesh=new THREE.InstancedMesh(footprintGeo,factory.basic(0x99b4c6,{transparent:true,opacity:0.28,depthWrite:false}),140);this.footMesh.frustumCulled=false;scene.add(this.footMesh);
    for(let i=0;i<140;i++)this.footMesh.setMatrixAt(i,this.dummy.matrix);
    const arcGeo=factory.geo('swing-ribbon',()=>{
      const positions=[],uvs=[],segments=32;
      for(let i=0;i<segments;i++)for(const [step,outer]of [[0,0],[0,1],[1,1],[0,0],[1,1],[1,0]]){
        const t=(i+step)/segments,a=(t-.5)*Math.PI*1.40;
        const radius=1.37-(outer?0:.20*Math.sin(t*Math.PI));
        positions.push(Math.cos(a)*radius,Math.sin(a)*radius,0);uvs.push(t,outer);
      }
      const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.Float32BufferAttribute(positions,3));g.setAttribute('uv',new THREE.Float32BufferAttribute(uvs,2));return g;
    });
    this.arcs=Array.from({length:8},(_,i)=>{
      const mat=new THREE.MeshBasicMaterial({color:0xffffff,transparent:true,opacity:.86,depthWrite:false,side:THREE.DoubleSide});
      factory.materials.set(`swing-ribbon-${i}`,mat);
      const mesh=new THREE.Mesh(arcGeo,mat);mesh.visible=false;scene.add(mesh);return {mesh,life:0,scale:1};
    });this.arcCursor=0;
    this.marker=new THREE.Group();
    const ring=new THREE.Mesh(factory.geo('destination-ring',()=>new THREE.RingGeometry(0.30,0.35,32)),factory.basic(0x399ab7,{transparent:true,opacity:0.9,depthWrite:false}));ring.rotation.x=-Math.PI/2;this.marker.add(ring);this.marker.visible=false;scene.add(this.marker);
    this.makeSnow();
  }
  makeSnow(){
    this.snowCount=180;this.snowData=new Float32Array(this.snowCount*3);
    for(let i=0;i<this.snowCount;i++){this.snowData[i*3]=(this.random()-0.5)*38;this.snowData[i*3+1]=this.random()*12;this.snowData[i*3+2]=(this.random()-0.5)*30;}
    const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(this.snowData,3));this.factory.geometries.set('weather',g);
    const m=new THREE.PointsMaterial({color:0xffffff,size:0.057,transparent:true,opacity:0.7,depthWrite:false,sizeAttenuation:true});this.factory.materials.set('weather',m);
    this.snow=new THREE.Points(g,m);this.snow.frustumCulled=false;this.scene.add(this.snow);
  }
  burst(position,color=0xffffff,count=10,force=2.5) {
    for(let i=0;i<count;i++) {
      const index=this.cursor++%this.particles.length;
      const p=this.particles[index];Object.assign(p,{x:position.x,y:position.y??0.5,z:position.z,
        vx:(this.random()-0.5)*force,vy:1+this.random()*force,vz:(this.random()-0.5)*force,life:0.6+this.random()*0.4,max:1,scale:0.5+this.random()*0.8});
      this.color.set(color).convertSRGBToLinear();this.mesh.setColorAt(index,this.color);
    }this.mesh.instanceColor.needsUpdate=true;
  }
  fly(type,from,to,{duration=0.45,arc=1.5,scale=1}={}) {
    if(this.items.length>=55)return;
    if(!this.flightBatches.has(type))this.flightBatches.set(type,new ResourceBatch(this.factory,type,55,this.scene));
    const mesh=new THREE.Object3D();mesh.position.copy(from);mesh.scale.setScalar(scale);
    this.items.push({type,mesh,from:from.clone(),to:typeof to==='function'?to:()=>to,life:0,duration,arc,scale});
  }
  swing(position,angle=0,scale=1){
    const arc=this.arcs[this.arcCursor++%this.arcs.length];arc.life=.24;arc.scale=scale;
    arc.mesh.position.set(position.x,.62,position.z);arc.mesh.rotation.set(-Math.PI/2+.16,0,-angle);arc.mesh.visible=true;
  }
  footprint(position,angle,side=1) {
    const p=this.footprints[this.footCursor++%140];p.x=position.x+Math.cos(angle)*side*0.11;p.z=position.z-Math.sin(angle)*side*0.11;p.angle=angle;p.life=1;
  }
  destination(point){this.marker.visible=!!point;if(point)this.marker.position.set(point.x,0.07,point.z);}
  update(dt) {
    this.time+=dt;
    for(let i=0;i<this.particles.length;i++){
      const p=this.particles[i];if(p.life>0){p.life-=dt;p.vy-=dt*6;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;
        if(p.y<0.05){p.y=0.05;p.vy*=-0.3;p.vx*=0.85;p.vz*=0.85;}
        this.dummy.position.set(p.x,p.y,p.z);this.dummy.rotation.set(this.time*3,i,this.time);this.dummy.scale.setScalar(Math.max(0,p.life)*p.scale);
      }else this.dummy.scale.setScalar(0);
      this.dummy.updateMatrix();this.mesh.setMatrixAt(i,this.dummy.matrix);
    }this.mesh.instanceMatrix.needsUpdate=true;
    for(const batch of this.flightBatches.values())batch.reset();
    for(let i=this.items.length-1;i>=0;i--){
      const e=this.items[i];e.life+=dt;const t=Math.min(1,e.life/e.duration),target=e.to();
      if(target){e.mesh.position.lerpVectors(e.from,target,t);e.mesh.position.y+=Math.sin(t*Math.PI)*e.arc;}
      e.mesh.rotation.y+=dt*5;e.mesh.scale.setScalar(e.scale*(t>0.85?(1-t)/0.15:1));
      if(t>=1){this.items.splice(i,1);}else{e.mesh.updateMatrix();this.flightBatches.get(e.type).append(e.mesh.matrix);}
    }
    for(const batch of this.flightBatches.values())batch.flush();
    for(let i=0;i<140;i++){
      const p=this.footprints[i];p.life=Math.max(0,p.life-dt/14);
      this.dummy.position.set(p.x??0,0.044,p.z??0);this.dummy.rotation.set(-Math.PI/2,0,-(p.angle??0));this.dummy.scale.setScalar(p.life);
      this.dummy.updateMatrix();this.footMesh.setMatrixAt(i,this.dummy.matrix);
    }this.footMesh.instanceMatrix.needsUpdate=true;
    for(const arc of this.arcs){
      arc.life=Math.max(0,arc.life-dt);arc.mesh.visible=arc.life>0;
      if(arc.life){arc.mesh.rotation.z+=dt*10;arc.mesh.material.opacity=arc.life/.24*.90;arc.mesh.scale.setScalar(arc.scale*(1+(1-arc.life/.24)*.08));}
    }
    this.marker.scale.setScalar(1+Math.sin(this.time*5)*0.10);
    for(let i=0;i<this.snowCount;i++){this.snowData[i*3]=((this.snowData[i*3]+19+dt*.13)%38+38)%38-19;this.snowData[i*3+1]-=dt*(0.40+i%3*0.12);if(this.snowData[i*3+1]<0)this.snowData[i*3+1]=12;}
    this.snow.geometry.attributes.position.needsUpdate=true;
  }
  dispose(){for(const batch of this.flightBatches.values())batch.dispose();for(const a of this.arcs)a.mesh.removeFromParent();for(const o of [this.mesh,this.footMesh,this.marker,this.snow])o.removeFromParent();this.mesh.dispose?.();this.footMesh.dispose?.();this.flightBatches.clear();this.items.length=0;}
}
