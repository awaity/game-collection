export const SAVE_KEY = 'frost-trail-save-v1';

/** Keeps v1/v2 saves compatible. Rendering effects are deliberately never saved. */
export class SaveSystem {
  static load(storage = globalThis.localStorage) {
    try { const value = storage.getItem(SAVE_KEY); return value ? JSON.parse(value) : {}; }
    catch { return {}; }
  }
  constructor(state, notify = () => {}, storage = globalThis.localStorage) {
    Object.assign(this, { state, notify, storage });
    this.timer = 0; this.dirty = false; this.failed = false; this.cleared = false;
    this.retryRemaining = 0; this.retryDelay = 2; this.disposed = false;
    this.unsubscribe = state.events.on('change', () => { if (!this.cleared) this.dirty = true; });
  }
  save() {
    if (this.cleared || this.disposed) return false;
    try {
      this.storage.setItem(SAVE_KEY, JSON.stringify(this.state.snapshot()));
      this.dirty = false; this.timer = 0; this.failed = false;
      this.retryRemaining = 0; this.retryDelay = 2;
      return true;
    } catch {
      this.dirty = true;
      // A failing storage write must not throw again on every 60 Hz simulation step.
      this.retryRemaining = this.retryDelay;
      this.retryDelay = Math.min(30, this.retryDelay * 2);
      if (!this.failed) {
        this.failed = true;
        this.notify('浏览器暂时无法保存进度；游戏可继续，将稍后重试');
      }
      return false;
    }
  }
  update(dt) {
    if (this.cleared || this.disposed || !Number.isFinite(dt) || dt <= 0) return;
    this.timer += dt; this.retryRemaining = Math.max(0, this.retryRemaining - dt);
    if (this.timer > 3) this.dirty = true; // Includes movement / in-flight timer changes.
    if (this.dirty && this.timer > 1.4 && this.retryRemaining <= 0) this.save();
  }
  clear() {
    try {
      this.storage.removeItem(SAVE_KEY); this.cleared = true; this.dirty = false;
      this.retryRemaining = 0; return true;
    } catch { return false; }
  }
  dispose() {
    if (this.disposed) return;
    this.save(); this.unsubscribe(); this.disposed = true;
  }
}
