/** Treat local storage as untrusted input; valid JSON can still be null or an array. */
export function readSettings(storage) {
  let data;
  try { data = JSON.parse(storage.getItem('frost-trail-settings') || '{}'); } catch { data = null; }
  if (!data || typeof data !== 'object' || Array.isArray(data)) data = {};
  return {
    quality: data.quality === 'low' ? 'low' : 'high',
    cameraMode: data.cameraMode === 'classic' ? 'classic' : 'reference',
    sound: data.sound !== false,
  };
}
