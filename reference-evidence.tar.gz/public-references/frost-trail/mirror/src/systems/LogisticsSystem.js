import * as THREE from 'three';
import { ResourceBatch } from '../render/ResourceBatch.js';
import { STATIONS } from '../simulation/Balance.js';
import { easeOutCubic } from '../utils/math.js';

/** Visual-only stockpiles, feed trays and moving conveyor cargo. */
export class LogisticsSystem {
  constructor({scene,factory,state}) {
    Object.assign(this,{scene,factory,state});this.root=new THREE.Group();scene.add(this.root);
    this.time=0;this.dummy=new THREE.Object3D();this.piles={};this.belts={};
    for(const [id,type,point,max]of [
      ['woodStock','wood',STATIONS.woodStock,90],['rawStock','raw',STATIONS.rawStock,90],
      ['woodFeed','wood',STATIONS.woodInput,18],['rawFeed','raw',STATIONS.fire,18],
      ['output','cooked',STATIONS.output,90],
    ]){
      const root=new THREE.Group();root.position.set(point.x,.15,point.z);this.root.add(root);
      const batch=new ResourceBatch(factory,type,max,root);
      if(id.endsWith('Stock')){
        factory.part(root,factory.box(1.65,.10,1.27,.075),0xe6b763,0,-.055,0);
        factory.part(root,factory.box(1.52,.035,1.15,.055),0xf0c681,0,.012,0);
      }
      this.piles[id]={root,batch,type,max,count:-1};
    }
    for(const [type,length,x,z,angle]of [['wood',2.43,-3.175,.15,Math.PI/2],['raw',3.25,1.69,2.27,0]]){
      const root=factory.createConveyor(length);root.position.set(x,0,z);root.rotation.y=angle;this.root.add(root);
      this.belts[type]={root,progress:state.camp.purchases[type==='wood'?'woodBelt':'rawBelt']?1:0};
    }
    this.transit={wood:new ResourceBatch(factory,'wood',18,this.root),raw:new ResourceBatch(factory,'raw',18,this.root)};
    this.counterRoot=new THREE.Group();this.counterRoot.position.set(-.4,1.09,-5.6);this.root.add(this.counterRoot);
    this.counterBatch=new ResourceBatch(factory,'cash',72,this.counterRoot);
    this.unsubscribe=state.events.on('purchase',key=>{const type=key==='woodBelt'?'wood':key==='rawBelt'?'raw':null;if(type)this.belts[type].progress=0;});
  }
  fillPile(pile,count){
    const visible=Math.min(count,pile.max);
    if(pile.count===visible)return;
    pile.count=visible;pile.batch.reset();
    for(let i=0;i<visible;i++){
      const column=i%3,level=Math.floor(i/3),wood=pile.type==='wood';
      this.dummy.position.set((column-1)*(wood?.25:.51),.12+level*(wood?.23:.19),0);
      this.dummy.rotation.set(0,wood?Math.PI/2:0,0);this.dummy.scale.setScalar(wood?1:.86);
      this.dummy.updateMatrix();pile.batch.append(this.dummy.matrix);
    }
    pile.batch.flush();
  }
  update(dt){
    this.time+=dt;const c=this.state.camp;
    this.piles.woodStock.root.visible=c.purchases.woodcutters||c.purchases.woodBelt||c.stock.wood>0;
    this.piles.rawStock.root.visible=c.purchases.hunters||c.purchases.rawBelt||c.stock.raw>0;
    for(const [key,count]of Object.entries({woodStock:c.stock.wood,rawStock:c.stock.raw,woodFeed:c.feed.wood,rawFeed:c.feed.raw,output:c.stock.cooked}))this.fillPile(this.piles[key],count);
    for(const [type,belt]of Object.entries(this.belts)){
      belt.root.visible=c.purchases[type==='wood'?'woodBelt':'rawBelt'];
      if(!belt.root.visible)continue;
      belt.progress=Math.min(1,belt.progress+dt*2.5);belt.root.scale.y=Math.max(.001,easeOutCubic(belt.progress));
      const length=belt.root.userData.length;
      belt.root.userData.cleats.forEach((mesh,i)=>{
        const offset=(this.time*.58+i*length/8)%length;
        mesh.position.z=type==='wood'?offset-length/2:length/2-offset;
      });
    }
    this.transit.wood.reset();this.transit.raw.reset();
    for(const item of c.transit){
      const from=item.type==='wood'?STATIONS.woodStock:STATIONS.rawStock;
      const to=item.type==='wood'?STATIONS.woodInput:STATIONS.fire;
      const t=Math.min(1,item.progress);
      this.dummy.position.set(THREE.MathUtils.lerp(from.x,to.x,t),.40,THREE.MathUtils.lerp(from.z,to.z,t));
      this.dummy.rotation.set(0,item.type==='wood'?Math.PI/2:0,0);this.dummy.scale.setScalar(.86);this.dummy.updateMatrix();
      this.transit[item.type].append(this.dummy.matrix);
    }
    this.transit.wood.flush();this.transit.raw.flush();
    this.counterBatch.reset();
    const count=Math.min(72,Math.ceil(this.state.counterCash/6));
    for(let i=0;i<count;i++){
      this.dummy.position.set((i%6-2.5)*.53,.08+Math.floor(i/12)*.115,Math.floor(i/6)%2*.29-.14);
      this.dummy.rotation.set(0,Math.sin(i*45)*.19,0);this.dummy.scale.setScalar(.78);this.dummy.updateMatrix();this.counterBatch.append(this.dummy.matrix);
    }
    this.counterBatch.flush();
  }
  dispose(){
    this.unsubscribe();for(const p of Object.values(this.piles))p.batch.dispose();
    this.transit.wood.dispose();this.transit.raw.dispose();this.counterBatch.dispose();this.root.removeFromParent();
  }
}
