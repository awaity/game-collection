import * as THREE from 'three';
import { BALANCE, RESOURCE, DEPLETION_RULES } from '../simulation/Balance.js';
import { distance, seededRandom, damp } from '../utils/math.js';

/** Renewable forests, non-graphic bear encounters and transactional ground pickup. */
export class ResourceSystem {
  constructor({scene,factory,state,player,inventory,collision,effects,audio}) {
    Object.assign(this,{scene,factory,state,player,inventory,collision,effects,audio});
    this.root=new THREE.Group();scene.add(this.root);this.trees=[];this.bears=[];this.drops=[];
    this.scaleTarget=new THREE.Vector3();this.random=seededRandom(616);this.time=0;this.cooldown=0;this.nextDropId=1;this.prompt='';
    this.buildForest();this.buildBears();this.buildDenseForest();this.buildRabbits();this.restoreWorld();
  }
  restoreWorld() {
    const saved=new Map(this.state.world.nodes.map(n=>[n.id,n]));
    for(const entry of [...this.trees,...this.bears]){
      const d=entry.data,n=saved.get(d.id);if(!n)continue;
      d.hp=n.active?Math.max(1,n.hp):0;d.active=n.active;d.cooldown=n.cooldown;
      if(typeof d.id==='number'){
        d.x=Math.max(d.homeX-.5,Math.min(d.homeX+.5,n.x));
        d.z=Math.max(d.homeZ-.5,Math.min(d.homeZ+.5,n.z));
      }
      entry.mesh.position.set(d.x,0,d.z);
      if(!d.active){entry.mesh.visible=false;entry.mesh.scale.setScalar(.001);
        if(entry.stump){entry.stump.visible=true;this.collision.remove(d.id);}else entry.shadow.visible=false;}
    }
    this.state.world.nodes=[...this.trees,...this.bears].map(e=>e.data);
    for(const data of this.state.world.drops){
      const mesh=this.factory.createResource(data.type);mesh.position.set(data.x,data.y,data.z);
      mesh.rotation.y=data.id*2.4;this.root.add(mesh);this.drops.push({data,mesh});
      this.nextDropId=Math.max(this.nextDropId,data.id+1);
    }
  }
  buildForest() {
    const positions=[];
    for(let row=0;row<6;row++)for(let col=0;col<4;col++)
      positions.push([-8.85-col*1.83+(row%2)*.13,-6.1+row*2.18]);
    // The first accessible tree is deliberately next to the west entrance.
    positions.splice(12,1);positions.unshift([-8.85,0]);
    positions.forEach(([x,z],i)=>{
      const scale=0.84+this.random()*0.16,mesh=this.factory.createTree(scale);mesh.position.set(x,0,z);this.root.add(mesh);
      const stump=this.factory.createStump();stump.position.set(x,0,z);stump.visible=false;this.root.add(stump);
      const shadow=this.factory.blob(2.1,1.6);shadow.position.x=x;shadow.position.z=z;this.root.add(shadow);
      const data={id:`tree-${i}`,x,z,hp:3,active:true,cooldown:0,hit:0,scale,maxHp:3};
      this.trees.push({data,mesh,stump,shadow});this.collision.add(data.id,x,z,0.6,0.6);
    });
  }
  buildBears() {
    const positions=[[-3.4,8.5],[0,8.9],[3.5,8.4],[-5.2,11.0],[-2.6,11.5],[0.1,11.9],[3.2,11.5],[5.3,10.7],[-4.9,13.5],[-1.7,14.0],[1.3,14.1],[4.3,13.4]];
    positions.forEach(([x,z],i)=>{
      const mesh=this.factory.createBear();mesh.position.set(x,0,z);mesh.rotation.y=this.random()*6;this.root.add(mesh);
      const shadow=this.factory.blob(1.55,2.75);shadow.position.x=x;shadow.position.z=z;this.root.add(shadow);
      const flash = new THREE.Group();
      const pink=this.factory.basic(0xf6959e,{transparent:true,opacity:.34,depthWrite:false});
      mesh.userData.body.traverse(part=>{
        if(!part.isMesh)return;
        const copy=new THREE.Mesh(part.geometry,pink);copy.position.copy(part.position);copy.rotation.copy(part.rotation);copy.scale.copy(part.scale).multiplyScalar(1.008);flash.add(copy);
      });
      mesh.add(flash);flash.visible=false;
      this.bears.push({data:{id:i,x,z,homeX:x,homeZ:z,hp:3,active:true,cooldown:0,hit:0,phase:this.random()*10,angle:this.random()*6,maxHp:3},mesh,shadow,flash});
    });
  }
  /** 密林带（枯竭梯度）：外圈西侧 16 棵，HP6、倒地 16 份、节拍 ×0.8、砍完不重生（树桩永久保留）。 */
  buildDenseForest() {
    const R = DEPLETION_RULES, positions = [];
    for (let row = 0; row < 8; row++) for (const col of [0, 1])
      positions.push([-15.6 - col * 1.9 + (row % 2) * .2, -6.0 + row * 1.45]);
    positions.forEach(([x, z], i) => {
      const scale = 1.02 + this.random() * 0.14, mesh = this.factory.createTree(scale, true); mesh.position.set(x, 0, z); this.root.add(mesh);
      const stump = this.factory.createStump(); stump.position.set(x, 0, z); stump.visible = false; this.root.add(stump);
      const shadow = this.factory.blob(2.3, 1.8); shadow.position.x = x; shadow.position.z = z; this.root.add(shadow);
      const data = { id: `dtree-${i}`, x, z, hp: R.denseHp, active: true, cooldown: 0, hit: 0, scale,
        maxHp: R.denseHp, yield: R.denseYield, chopFactor: R.denseChopFactor, noRespawn: true };
      this.trees.push({ data, mesh, stump, shadow }); this.collision.add(data.id, x, z, 0.6, 0.6);
    });
  }
  /** 外圈猎场：8 头雪兔（邻营附近），HP2 掉 3 份生肉，60s 慢重生；共用熊的节点协议与互斥。 */
  buildRabbits() {
    const R = DEPLETION_RULES;
    const positions = [[-15.2, 10.6], [-18.6, 6.6], [0.6, 17.4], [4.4, 18.2], [-3.2, 19.4], [-12.6, -13.2], [-16.8, -16.6], [18.2, 10.6]];
    positions.forEach(([x, z], i) => {
      const f = this.factory, mesh = new THREE.Group();
      f.part(mesh, f.sphere(.19, 10), 0xf2f0ea, 0, .20, 0);                       // 身
      f.part(mesh, f.sphere(.12, 8), 0xf7f5ee, 0, .30, .17);                      // 头
      for (const s of [-1, 1]) f.part(mesh, f.capsule(.028, .16), 0xe8e4da, s * .05, .46, .15, -.25); // 耳
      mesh.position.set(x, 0, z); mesh.rotation.y = this.random() * 6; mesh.userData.legs = []; this.root.add(mesh);
      const shadow = this.factory.blob(.8, .7); shadow.position.x = x; shadow.position.z = z; this.root.add(shadow);
      const flash = new THREE.Group();
      const pink = this.factory.basic(0xf6959e, { transparent: true, opacity: .34, depthWrite: false });
      mesh.traverse(part => { if (part.isMesh) { const copy = new THREE.Mesh(part.geometry, pink); copy.position.copy(part.position); copy.rotation.copy(part.rotation); copy.scale.copy(part.scale).multiplyScalar(1.01); flash.add(copy); } });
      mesh.add(flash); flash.visible = false;
      this.bears.push({ data: { id: `rabbit-${i}`, x, z, homeX: x, homeZ: z, hp: R.rabbitHp, active: true, cooldown: 0, hit: 0,
        phase: this.random() * 10, angle: this.random() * 6, kind: 'rabbit', maxHp: R.rabbitHp, yield: R.rabbitYield, respawnTime: R.rabbitRespawn },
        mesh, shadow, flash });
    });
  }
  drop(type,x,z,count=1) {
    if (!Object.hasOwn(RESOURCE,type) || type==='cash' || !Number.isFinite(x) || !Number.isFinite(z) ||
        !Number.isSafeInteger(count) || count<1 || count>BALANCE.maxDrops-this.drops.length) return 0;
    for(let i=0;i<count;i++){
      const a=i*2.4+this.random(),r=0.24+this.random()*0.70;
      const data={id:this.nextDropId++,type,x:x+Math.cos(a)*r,z:z+Math.sin(a)*r,y:0.35,vy:1.2+this.random(),age:0};
      const mesh=this.factory.createResource(type);mesh.position.set(data.x,data.y,data.z);mesh.rotation.y=this.random()*Math.PI;this.root.add(mesh);this.drops.push({data,mesh});this.state.world.drops.push(data);
    }
    return count;
  }
  canRespawn(data, radius) {
    return distance(data,this.player.position)>radius &&
      !this.state.camp.workers.some(worker=>distance(data,worker)<radius);
  }
  collectDrops(dt) {
    for(let i=this.drops.length-1;i>=0;i--){
      const {data:d,mesh}=this.drops[i];d.age=Math.min(3600,d.age+dt);d.vy-=dt*7;d.y=Math.max(0.15,d.y+d.vy*dt);if(d.y<=.15)d.vy=0;
      mesh.position.y=d.y+Math.sin(this.time*3+d.id)*0.035;
      if(d.age>0.15&&distance(d,this.player.position)<BALANCE.pickupRadius&&this.state.freeSlots>0) {
        // Commit logical pickup first, remove ground view only on success. No duplicates.
        const item=this.inventory.add(d.type,{collected:true});if(!item)continue;
        mesh.removeFromParent();this.drops.splice(i,1);this.state.world.drops.splice(i,1);
        this.effects.burst({x:d.x,y:0.45,z:d.z},d.type==='wood'?0xf2d2a4:0xffd7c0,3,0.7);
        this.audio.play('pickup');
      }
    }
  }
  update(dt) {
    this.time+=dt;this.cooldown=Math.max(0,this.cooldown-dt);this.prompt='';
    const p=this.player.position;
    for(const entry of this.trees){
      const {data:d,mesh,stump}=entry;d.hit=Math.max(0,d.hit-dt*5);
      mesh.rotation.z=Math.sin(d.hit*Math.PI*3)*d.hit*0.10;
      if(!d.active){d.cooldown-=dt;const shrink=Math.max(0.001,mesh.scale.x-dt*4);mesh.scale.setScalar(shrink);mesh.visible=shrink>0.002;
        if(!d.noRespawn&&d.cooldown<=0&&this.canRespawn(d,1.5)){d.active=true;d.hp=d.maxHp??3;mesh.visible=true;stump.visible=false;this.collision.add(d.id,d.x,d.z,0.6,0.6);}
      }else mesh.scale.lerp(this.scaleTarget.set(d.scale,d.scale,d.scale),damp(4,dt));
    }
    for(const entry of this.bears){
      const {data:d,mesh,shadow,flash}=entry;d.hit=Math.max(0,d.hit-dt*4);flash.visible=d.hit>0;
      if(!d.active){d.cooldown-=dt;mesh.scale.setScalar(Math.max(0.001,mesh.scale.x-dt*4));mesh.visible=mesh.scale.x>0.002;shadow.visible=mesh.visible;
        if(d.cooldown<=0&&this.canRespawn(d,2)){d.active=true;d.hp=d.maxHp??3;mesh.visible=true;shadow.visible=true;mesh.scale.setScalar(1);}
      }else {
        const near=distance(d,p)<2;
        if(!near){d.phase+=dt*0.28;d.x=d.homeX+Math.sin(d.phase)*0.40;d.z=d.homeZ+Math.cos(d.phase*0.8)*0.35;
          const angle=Math.atan2(Math.cos(d.phase),-Math.sin(d.phase*0.8)*0.8);mesh.rotation.y+=Math.atan2(Math.sin(angle-mesh.rotation.y),Math.cos(angle-mesh.rotation.y))*damp(2,dt);}
        mesh.position.set(d.x,0,d.z);shadow.position.x=d.x;shadow.position.z=d.z;
        mesh.userData.legs.forEach((leg,i)=>leg.rotation.x=near?0:Math.sin(this.time*3+i*Math.PI)*0.14);
      }
    }
    this.collectDrops(dt);
    if(this.state.freeSlots<1){if(distance(p,{x:0,z:0})>6)this.prompt='背包装满了 · 回集市出售';return;}
    if(this.player.moving&&this.player.velocity.length()>0.75)return;
    let target=this.trees.filter(e=>e.data.active&&distance(e.data,p)<1.75).sort((a,b)=>distance(a.data,p)-distance(b.data,p))[0];
    let kind='tree';
    if(!target){target=this.bears.filter(e=>e.data.active&&distance(e.data,p)<1.9).sort((a,b)=>distance(a.data,p)-distance(b.data,p))[0];kind=target?.data.kind==='rabbit'?'rabbit':'bear';}
    if(!target){ // 枯竭提示：站在砍光的密林树桩旁
      const dead=this.trees.filter(e=>e.data.noRespawn&&!e.data.active&&distance(e.data,p)<2.2)[0];
      if(dead)this.prompt='密林已枯竭 · 树桩留在雪原';
      return;
    }
    this.prompt=kind==='tree'?'正在伐木':kind==='rabbit'?'正在捕猎雪兔':'正在获取食材';
    if(this.cooldown>0)return;
    this.cooldown=(kind==='tree'?BALANCE.chopInterval*(target.data.chopFactor??1):BALANCE.huntInterval)/(this.state.getGatherMultiplier(kind==='tree'?'wood':'raw')*this.state.getLampGatherFactor(p.x,p.z)*this.state.getGatherBuffFactor());
    this.player.swing();this.player.aim?.(target.data.x,target.data.z);
    const loot=this.strike(target,kind,{position:p,worker:false});
    if(loot){
      this.drop(loot.type,(target.data.x+p.x)/2,(target.data.z+p.z)/2,loot.count);
      if(kind==='rabbit'){ // 偷猎代价：敌营 8m 内关系 -2/次（不走翻脸硬规则）
        const poached=this.state.checkPoaching(target.data.homeX,target.data.homeZ);
        if(poached)this.prompt=`偷猎警告 · ${poached} 关系 -2`;
      }
    }
  }
  strike(target,kind,{position:p,worker=false}) {
    const d=target?.data;if(!d?.active||!p||distance(d,p)>2.05)return null;
    const isTree=kind==='tree',yieldCount=d.yield??(isTree?8:5);
    if(!worker && d.hp<=1 && (this.drops?.length??0)+yieldCount>BALANCE.maxDrops){
      this.prompt='地面资源较多 · 先拾取，再继续采集';return null;
    }
    d.hp--;d.hit=1;
    const angle=Math.atan2(d.x-p.x,d.z-p.z);this.effects.swing(p,angle,worker?.72:1);
    this.effects.burst({x:d.x,y:isTree?1.0:.7,z:d.z},isTree?0xc28b52:0xe7f7ff,worker?5:10,2.4);
    if(!worker)this.audio.play(isTree?'chop':'hit');
    if(d.hp>0)return null;
    d.active=false;d.cooldown=d.respawnTime??(isTree?BALANCE.treeRespawn:BALANCE.bearRespawn);
    if(isTree){target.stump.visible=true;this.collision.remove(d.id);}
    this.effects.burst({x:d.x,y:.8,z:d.z},isTree?0xf2faff:0xffd0cb,worker?10:18,3.2);
    return {type:isTree?'wood':'raw',count:yieldCount};
  }
  dispose(){this.root.removeFromParent();this.drops.length=0;}
}
