import * as THREE from 'three';
import { seededRandom, damp } from '../utils/math.js';
import { canvasTexture, paintIcon } from '../assets/ArtTextures.js';

/** Dense instanced queues: customers advance, receive food, exit and rejoin at the back. */
export class CrowdSystem {
  constructor({scene,factory,state}) {
    Object.assign(this,{scene,factory,state});this.root=new THREE.Group();scene.add(this.root);
    this.actors=[];this.queues=Array.from({length:11},()=>[]);this.batches=[];this.bubbles=[];
    this.time=0;this.served=0;this.dummy=new THREE.Object3D();this.matrix=new THREE.Matrix4();
    const random=seededRandom(18),templates=[0,1,2,3].map(v=>factory.createCitizen(v));
    const buckets=new Map();templates.forEach(t=>t.updateMatrixWorld(true));
    for(let row=0;row<12;row++)for(let col=0;col<11;col++){
      const x=(col-5)*.55,z=-6.5-row*.59;
      const actor={x,z,targetX:x,targetZ:z,col,row,phase:random()*6,scale:.75+random()*.055,
        matrix:new THREE.Matrix4(),cheer:0,exit:0,exitStartX:0,exitStartZ:0};
      this.actors.push(actor);this.queues[col].push(actor);
      templates[(row+col)%4].traverse(part=>{
        if(!part.isMesh)return;const key=part.geometry.uuid+part.material.uuid;
        if(!buckets.has(key))buckets.set(key,{geometry:part.geometry,material:part.material,entries:[]});
        buckets.get(key).entries.push({actor,local:part.matrixWorld.clone()});
      });
    }
    for(const bucket of buckets.values()){
      const mesh=new THREE.InstancedMesh(bucket.geometry,bucket.material,bucket.entries.length);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage);mesh.castShadow=true;mesh.receiveShadow=true;mesh.frustumCulled=false;
      this.root.add(mesh);this.batches.push({mesh,entries:bucket.entries});
    }
    const blob=factory.blob(.7,.62);
    this.shadows=new THREE.InstancedMesh(blob.geometry,blob.material,this.actors.length);this.shadows.frustumCulled=false;this.root.add(this.shadows);
    this.makeBubbles();this.update(0);
    this.unsubscribe=state.events.on('sold',()=>this.serveCustomer());
  }
  serveCustomer(){
    const col=this.served++%this.queues.length,queue=this.queues[col],actor=queue.shift();
    if(!actor)return;
    actor.cheer=1;actor.exit=1;actor.exitStartX=actor.x;actor.exitStartZ=actor.z;queue.push(actor);
    queue.forEach((a,row)=>{a.row=row;a.targetZ=-6.5-row*.59;});
  }
  makeBubbles(){
    const texture=canvasTexture(this.factory,'crowd-order-v11',128,144,ctx=>{
      ctx.fillStyle='#fffaf2';ctx.strokeStyle='#978c85';ctx.lineWidth=3;
      ctx.beginPath();ctx.roundRect(7,6,114,111,33);ctx.fill();ctx.stroke();
      ctx.beginPath();ctx.moveTo(46,113);ctx.lineTo(65,139);ctx.lineTo(79,113);ctx.fill();
      paintIcon(ctx,'cooked',64,62,112);
    });
    const material=new THREE.SpriteMaterial({map:texture,transparent:true,depthWrite:false});this.factory.materials.set('crowd-bubble-v11',material);
    for(const index of [0,3,6,10,24,43,72]){
      const sprite=new THREE.Sprite(material);sprite.scale.set(.72,.81,1);this.root.add(sprite);
      this.bubbles.push({sprite,actor:this.actors[index]});
    }
  }
  update(dt){
    this.time+=dt;const response=dt?damp(4.2,dt):1;
    for(const a of this.actors){
      a.cheer=Math.max(0,a.cheer-dt*1.55);
      if(a.exit>0){
        a.exit=Math.max(0,a.exit-dt*.57);
        if(a.cheer<=.1){const t=1-a.exit;const edge=a.col<5?-3.65:3.65;
          a.x=THREE.MathUtils.lerp(a.exitStartX,edge,t);a.z=a.exitStartZ+.25*t;
        }
        if(a.exit===0){a.x=a.targetX;a.z=-14.1;}
      }else{a.x=THREE.MathUtils.lerp(a.x,a.targetX,response);a.z=THREE.MathUtils.lerp(a.z,a.targetZ,response);}
    }
    for(const a of this.actors){
      this.dummy.position.set(a.x+Math.sin(this.time*1.3+a.phase)*.012,Math.sin(this.time*2+a.phase)*.012+Math.sin(a.cheer*Math.PI)*.30,a.z);
      this.dummy.rotation.set(0,a.exit>0&&a.cheer<.1?(a.col<5?-1.5:1.5):Math.sin(this.time*.6+a.phase)*.06,Math.sin(a.cheer*Math.PI)*.11);
      this.dummy.scale.setScalar(a.scale);this.dummy.updateMatrix();a.matrix.copy(this.dummy.matrix);
    }
    for(const batch of this.batches){
      batch.entries.forEach(({actor:a,local},i)=>{this.matrix.multiplyMatrices(a.matrix,local);batch.mesh.setMatrixAt(i,this.matrix);});
      batch.mesh.instanceMatrix.needsUpdate=true;
    }
    this.actors.forEach((a,i)=>{
      this.dummy.position.set(a.x,.024,a.z);this.dummy.rotation.set(-Math.PI/2,0,0);this.dummy.scale.set(.69,.62,1);this.dummy.updateMatrix();this.shadows.setMatrixAt(i,this.dummy.matrix);
    });this.shadows.instanceMatrix.needsUpdate=true;
    this.bubbles.forEach(({sprite,actor:a},i)=>{
      sprite.position.set(a.x,1.51+Math.sin(this.time*1.7+i)*.025,a.z);sprite.visible=!a.exit&&a.cheer<.05;
    });
  }
  dispose(){this.unsubscribe();for(const b of this.batches)b.mesh.dispose?.();this.shadows.dispose?.();this.root.removeFromParent();}
}
