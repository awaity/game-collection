import * as THREE from 'three';

/** Tiny hand-painted-in-code decals. No downloaded models, photos or font files. */
export function canvasTexture(factory, key, width, height, paint) {
  if (!factory.decalCache) factory.decalCache = new Map();
  if (factory.decalCache.has(key)) return factory.decalCache.get(key);
  const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
  const context = canvas.getContext('2d');
  if (!context) throw new Error('Canvas 2D is required for the procedural decals');
  paint(context, width, height);
  const texture = new THREE.CanvasTexture(canvas);
  texture.encoding = THREE.sRGBEncoding; texture.anisotropy = 4;
  factory.textures.add(texture); factory.decalCache.set(key, texture);
  return texture;
}

export function paintIcon(ctx, type, x, y, size) {
  ctx.save(); ctx.translate(x, y); ctx.scale(size / 100, size / 100);
  ctx.lineJoin = 'round'; ctx.lineCap = 'round';
  if (type === 'wood') {
    ctx.rotate(-0.40); ctx.fillStyle = '#b9753e'; ctx.strokeStyle = '#71452e'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.roundRect(-39, -16, 77, 32, 10); ctx.fill(); ctx.stroke();
    ctx.fillStyle = '#ffe0a3'; ctx.beginPath(); ctx.ellipse(32, 0, 9, 15, 0, 0, Math.PI * 2); ctx.fill();
    ctx.strokeStyle = '#d69d5c'; ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(-29, -5); ctx.lineTo(17, -5); ctx.stroke();
  } else if (type === 'raw' || type === 'cooked') {
    ctx.rotate(-0.25); ctx.fillStyle = type === 'raw' ? '#ed6064' : '#ad4b29';
    ctx.strokeStyle = type === 'raw' ? '#ffedcb' : '#eeae68'; ctx.lineWidth = 7;
    ctx.beginPath(); ctx.moveTo(-29, -14); ctx.bezierCurveTo(-42, 8, -25, 30, 0, 22);
    ctx.bezierCurveTo(15, 18, 30, 9, 34, -12); ctx.bezierCurveTo(34, -30, 5, -26, -4, -18);
    ctx.bezierCurveTo(-14, -26, -23, -24, -29, -14); ctx.closePath(); ctx.fill(); ctx.stroke();
    if (type === 'raw') {
      ctx.fillStyle = '#ffebce'; ctx.beginPath(); ctx.ellipse(14, -5, 6, 9, .2, 0, Math.PI * 2); ctx.fill();
      ctx.strokeStyle = '#ffb2a0'; ctx.lineWidth = 2;
      ctx.beginPath(); ctx.moveTo(-20, -4); ctx.quadraticCurveTo(-3, -14, 2, 9); ctx.stroke();
    } else {
      ctx.strokeStyle = '#743a2b'; ctx.lineWidth = 4;
      for (const a of [-15, 0, 15]) { ctx.beginPath(); ctx.moveTo(a - 4, -12); ctx.lineTo(a + 3, 12); ctx.stroke(); }
    }
  } else if (type === 'worker') {
    for (const a of [-18, 18]) {
      ctx.fillStyle = '#f4f7f6'; ctx.beginPath(); ctx.arc(a, -21, 15, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#eeceaa'; ctx.beginPath(); ctx.arc(a, -18, 8, 0, Math.PI * 2); ctx.fill();
      ctx.fillStyle = '#56b9c7'; ctx.beginPath(); ctx.roundRect(a - 16, -3, 32, 35, 9); ctx.fill();
      ctx.strokeStyle = '#f4f7f6'; ctx.lineWidth = 6; ctx.beginPath(); ctx.moveTo(a - 11, 35); ctx.lineTo(a - 11, 44); ctx.moveTo(a + 11, 35); ctx.lineTo(a + 11, 44); ctx.stroke();
    }
  } else if (type === 'belt') {
    ctx.rotate(-0.3); ctx.fillStyle = '#e6ac4a'; ctx.beginPath(); ctx.roundRect(-42, -22, 84, 44, 8); ctx.fill();
    ctx.fillStyle = '#45464b'; ctx.fillRect(-34, -15, 68, 30);
    ctx.strokeStyle = '#e6d6ba'; ctx.lineWidth = 5;
    for (const a of [-20, 0, 20]) { ctx.beginPath(); ctx.moveTo(a - 4, -8); ctx.lineTo(a + 4, 0); ctx.lineTo(a - 4, 8); ctx.stroke(); }
  } else if (type === 'expand') {
    ctx.strokeStyle = '#f8f6ee'; ctx.lineWidth = 8;
    for (let i = 0; i < 4; i++) { ctx.save(); ctx.rotate(i * Math.PI / 2 + .7); ctx.beginPath(); ctx.moveTo(3, 0); ctx.lineTo(29, 0); ctx.moveTo(19, -10); ctx.lineTo(29, 0); ctx.lineTo(19, 10); ctx.stroke(); ctx.restore(); }
  } else {
    ctx.fillStyle = '#5eec25'; ctx.beginPath(); ctx.roundRect(-38, -20, 76, 40, 5); ctx.fill();
    ctx.strokeStyle = '#24992e'; ctx.lineWidth = 3; ctx.strokeRect(-31, -14, 62, 28);
    ctx.fillStyle = '#217b28'; ctx.font = 'bold 32px sans-serif'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle'; ctx.fillText('$', 0, 2);
  }
  ctx.restore();
}

export function purchaseTexture(factory, cost, type) {
  return canvasTexture(factory, `purchase-${type}-${cost}`, 256, 256, ctx => {
    ctx.fillStyle = '#483636'; ctx.beginPath(); ctx.roundRect(6, 6, 244, 244, 37); ctx.fill();
    ctx.strokeStyle = '#fff9ec'; ctx.lineWidth = 10; ctx.setLineDash([48, 15]);
    ctx.beginPath(); ctx.roundRect(15, 15, 226, 226, 31); ctx.stroke(); ctx.setLineDash([]);
    paintIcon(ctx, type, 128, 88, 148);
    paintIcon(ctx, 'cash', 63, 191, 69);
    ctx.fillStyle = '#fffbee'; ctx.font = '900 55px Arial, sans-serif'; ctx.textAlign = 'left'; ctx.textBaseline = 'middle';
    ctx.fillText(String(cost), 103, 194);
  });
}

export function inputTexture(factory, type, active = false) {
  return canvasTexture(factory, `input-${type}-${active}`, 256, 224, ctx => {
    ctx.fillStyle = '#362b31'; ctx.beginPath(); ctx.roundRect(5, 5, 246, 214, 23); ctx.fill();
    ctx.lineWidth = 8; ctx.strokeStyle = active ? '#acff6b' : type === 'wood' ? '#eeae4b' : '#ed7880';
    ctx.beginPath(); ctx.roundRect(13, 13, 230, 198, 18); ctx.stroke();
    paintIcon(ctx, type, 128, 112, 186);
  });
}

export function campTexture(factory) {
  return canvasTexture(factory, 'camp-floor', 1024, 1024, (ctx, w, h) => {
    // Sub-pixel-alpha feathering creates a soft snow/melt boundary, rather than a raised slab.
    for (let n = 12; n >= 0; n--) {
      const pad = 28 - n * 1.25;
      ctx.globalAlpha = n === 0 ? 1 : .035;
      ctx.fillStyle = '#c08f7b'; ctx.beginPath(); ctx.roundRect(pad, pad, w - pad * 2, h - pad * 2, 46 + n); ctx.fill();
    }
    ctx.globalAlpha = 1;
    const wash = ctx.createLinearGradient(0, 0, 1024, 1024);
    wash.addColorStop(0, 'rgba(233,170,133,.055)'); wash.addColorStop(1, 'rgba(121,77,73,.04)');
    ctx.fillStyle = wash; ctx.beginPath(); ctx.roundRect(28, 28, w - 56, h - 56, 46); ctx.fill();
  });
}

export function recipeTexture(factory) {
  return canvasTexture(factory, 'grill-recipe', 320, 160, ctx => {
    ctx.fillStyle = '#fffaf0'; ctx.strokeStyle = '#796a69'; ctx.lineWidth = 5;
    ctx.beginPath(); ctx.roundRect(6, 6, 308, 135, 19); ctx.fill(); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(138, 140); ctx.lineTo(155, 158); ctx.lineTo(177, 140); ctx.fill();
    paintIcon(ctx, 'wood', 80, 64, 121); paintIcon(ctx, 'raw', 233, 64, 124);
    ctx.fillStyle = '#7dbd76'; ctx.font = '900 42px sans-serif'; ctx.fillText('+', 143, 83);
    ctx.fillStyle = '#90837d'; ctx.font = '20px sans-serif'; ctx.textAlign = 'center'; ctx.fillText('1 : 3', 157, 121);
  });
}
