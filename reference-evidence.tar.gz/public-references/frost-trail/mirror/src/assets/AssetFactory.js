import * as THREE from 'three';
import { makeResource } from './ResourceMeshes.js';
import { canvasTexture, purchaseTexture, inputTexture } from './ArtTextures.js';

const C = Object.freeze({ snow:0xf0f3fa, ice:0xb1d9ee, blueSnow:0x86b3d5,
  pine:0x356f79, blue:0x17a4c7, navy:0x284663, teal:0x4eb6bd,
  wood:0xaa6938, end:0xe3b883, darkWood:0x825332, skin:0xf4c7a1,
  white:0xfff9e9, coal:0x344051, stone:0x91a8ba });

/** All artwork is generated here; geometries and materials have one clear owner. */
export class AssetFactory {
  constructor() { this.geometries=new Map();this.materials=new Map();this.textures=new Set();this.compiled=new Map();this.staticBatches=new Set(); }
  material(color, options={}) {
    const key=`${color}:${JSON.stringify(options)}`;
    if(!this.materials.has(key)) this.materials.set(key,new THREE.MeshStandardMaterial({
      color:new THREE.Color(color).convertSRGBToLinear(),roughness:0.77,metalness:0,...options,
    }));
    return this.materials.get(key);
  }
  basic(color, options={}) {
    const key=`basic:${color}:${JSON.stringify(options)}`;
    if(!this.materials.has(key))this.materials.set(key,new THREE.MeshBasicMaterial({
      color:new THREE.Color(color).convertSRGBToLinear(),...options,
    }));return this.materials.get(key);
  }
  geo(key, make) {if(!this.geometries.has(key))this.geometries.set(key,make());return this.geometries.get(key);}
  box(w,h,d,r=0.035) {
    return this.geo(`box:${w},${h},${d},${r}`,()=>{
      r=Math.min(r,w/2,h/2,d/2);const geo=new THREE.BoxGeometry(w,h,d,3,3,3);
      const p=geo.attributes.position,n=geo.attributes.normal;const v=new THREE.Vector3(),q=new THREE.Vector3(),normal=new THREE.Vector3();
      for(let i=0;i<p.count;i++) {
        v.fromBufferAttribute(p,i);q.set(
          THREE.MathUtils.clamp(v.x,-w/2+r,w/2-r),THREE.MathUtils.clamp(v.y,-h/2+r,h/2-r),THREE.MathUtils.clamp(v.z,-d/2+r,d/2-r));
        normal.subVectors(v,q).normalize();v.copy(q).addScaledVector(normal,r);
        p.setXYZ(i,v.x,v.y,v.z);n.setXYZ(i,normal.x,normal.y,normal.z);
      }return geo;
    });
  }
  cylinder(r,h,segments=10,top=r) {return this.geo(`cyl:${r},${h},${segments},${top}`,()=>new THREE.CylinderGeometry(top,r,h,segments));}
  sphere(r=1,detail=12) {return this.geo(`sphere:${r},${detail}`,()=>new THREE.SphereGeometry(r,detail,8));}
  capsule(r,length) {return this.geo(`cap:${r},${length}`,()=>new THREE.CapsuleGeometry(r,length,4,10));}
  part(parent,geometry,material,x=0,y=0,z=0,rx=0,ry=0,rz=0) {
    const mesh=new THREE.Mesh(geometry,typeof material==='number'?this.material(material):material);
    mesh.position.set(x,y,z);mesh.rotation.set(rx,ry,rz);mesh.castShadow=true;mesh.receiveShadow=true;parent.add(mesh);return mesh;
  }
  /** Combine static parts per material, retaining reusable GPU geometry across instances. */
  compileStatic(root,key) {
    let parts=this.compiled.get(key);
    if(!parts){
      root.updateMatrixWorld(true);const inverse=root.matrixWorld.clone().invert(),groups=new Map();
      root.traverse(mesh=>{if(!mesh.isMesh)return;
        const k=mesh.material.uuid;let group=groups.get(k);
        if(!group){group={material:mesh.material,position:[],normal:[],uv:[]};groups.set(k,group);}
        const geo=mesh.geometry.index?mesh.geometry.toNonIndexed():mesh.geometry.clone();
        geo.applyMatrix4(new THREE.Matrix4().multiplyMatrices(inverse,mesh.matrixWorld));
        for(const name of ['position','normal','uv']){
          const data=geo.attributes[name];if(data)for(const value of data.array)group[name].push(value);
        }
        geo.dispose();
      });
      parts=[...groups.values()].map((group,i)=>{
        const geometry=new THREE.BufferGeometry();
        for(const name of ['position','normal','uv'])if(group[name].length)geometry.setAttribute(name,new THREE.Float32BufferAttribute(group[name],name==='uv'?2:3));
        geometry.computeBoundingSphere();this.geometries.set(`compiled:${key}:${i}`,geometry);
        return {geometry,material:group.material};
      });this.compiled.set(key,parts);
    }
    root.clear();for(const part of parts){const mesh=new THREE.Mesh(part.geometry,part.material);mesh.castShadow=true;mesh.receiveShadow=true;root.add(mesh);}
    return root;
  }
  createPlayer() {
    const root=new THREE.Group(),visual=new THREE.Group();root.add(visual);
    this.part(visual,this.capsule(0.265,0.36),C.blue,0,0.84,0);
    this.part(visual,this.box(0.43,0.13,0.44,0.06),C.navy,0,0.52,0);
    // A fur-lined hood and a face make the primitive capsule readable at phone scale.
    this.part(visual,this.sphere(0.255),C.white,0,1.28,0.015);
    this.part(visual,this.sphere(0.225),C.blue,0,1.37,-0.05);
    const face=this.part(visual,this.sphere(0.18),C.skin,0,1.29,0.195);face.scale.set(0.9,0.92,0.45);
    for(const x of [-0.061,0.061])this.part(visual,this.sphere(0.018,8),C.coal,x,1.32,0.277);
    this.part(visual,this.sphere(0.034,8),0xeaae86,0,1.255,0.277);
    this.part(visual,this.sphere(0.083,8),C.white,0,1.61,-0.035);
    this.part(visual,this.box(0.53,0.10,0.37,0.04),0xf8f1de,0,1.075,0.035);
    this.part(visual,this.box(0.10,0.25,0.055,0.015),0xf8f1de,-0.16,0.94,0.26);
    this.part(visual,this.box(0.46,0.50,0.29,0.07),0xb6895c,0,0.87,-0.32);
    this.part(visual,this.box(0.34,0.18,0.045,0.025),0xeac58b,0,0.78,-0.49);
    this.part(visual,this.box(0.30,0.025,0.025,0.008),C.end,0,0.86,-0.52);
    const legs=[],arms=[];
    for(const sign of [-1,1]) {
      const leg=new THREE.Group();leg.position.set(sign*0.145,0.46,0);visual.add(leg);legs.push(leg);
      this.part(leg,this.capsule(0.09,0.20),C.navy,0,-0.12,0);
      this.part(leg,this.box(0.20,0.14,0.30,0.055),0x31465a,0,-0.33,0.055);
      this.part(leg,this.box(0.20,0.04,0.31,0.012),C.white,0,-0.40,0.055);
      const arm=new THREE.Group();arm.position.set(sign*0.32,1.035,0);visual.add(arm);arms.push(arm);
      this.part(arm,this.capsule(0.088,0.23),C.blue,0,-0.14,0);
      this.part(arm,this.sphere(0.103,8),C.white,0,-0.355,0.04);
    }
    const tool=new THREE.Group();tool.position.set(0,-0.38,0.12);arms[1].add(tool);
    this.part(tool,this.cylinder(0.03,0.62,8),C.darkWood,0,0,0.23,Math.PI/2);
    this.part(tool,this.box(0.37,0.24,0.075,0.025),0xc6e5f1,0.09,0.055,0.5,0,0,-0.15);
    tool.visible=false;
    const rod=new THREE.Group();rod.position.set(0,-.33,.1);arms[1].add(rod);
    const pole=this.part(rod,this.cylinder(.017,1.55,8,.008),0x745340,0,.02,.68,Math.PI/2-.25);
    const line=this.part(rod,this.cylinder(.005,.52,4),0xd8eef0,0,-.26,1.43);
    rod.visible=false;visual.userData.rig={legs,arms,tool,rod};
    return {root,visual};
  }
  createCitizen(variant=0) {
    const root=new THREE.Group();const coat=[0x329fad,0x45b2bb,0x257e94,0x4099a9][variant%4];
    this.part(root,this.capsule(0.215,0.31),coat,0,0.62,0);
    this.part(root,this.sphere(0.211),C.white,0,1.035,0);
    this.part(root,this.sphere(0.175),C.coal,0,1.105,-0.035);
    const face=this.part(root,this.sphere(0.143),C.skin,0,1.055,0.165);face.scale.set(0.86,0.85,0.3);
    this.part(root,this.box(0.30,0.075,0.31,0.03),C.white,0,0.835,0.03);
    for(const sign of [-1,1]) {
      this.part(root,this.cylinder(0.065,0.26,6),C.navy,sign*0.105,0.16,0);
      this.part(root,this.box(0.14,0.10,0.22,0.025),C.coal,sign*0.105,0.055,0.03);
      this.part(root,this.capsule(0.07,0.22),coat,sign*0.275,0.61,0,0,0,-sign*0.15);
      this.part(root,this.sphere(0.073,6),C.white,sign*0.30,0.43,0.015);
    }
    return this.compileStatic(root,`citizen-${variant%4}`);
  }
  snowCone(radius, height) {
    return this.geo(`soft-snow:${radius},${height}`, () => {
      const profile = [[0,0],[.82,0],[.97,.022],[1,.07],[.96,.15],[.86,.32],[.66,.56],[.39,.79],[.12,.97],[0,1.03]];
      return new THREE.LatheGeometry(profile.map(([r,y]) => new THREE.Vector2(r*radius,y*height)), 16);
    });
  }
  snowDrape(radius,height){
    return this.geo(`snow-drape:${radius},${height}`,()=>{
      const geometry=this.snowCone(radius,height).clone(),a=geometry.attributes.position;
      for(let i=0;i<a.count;i++){
        const x=a.getX(i),z=a.getZ(i),y=a.getY(i),theta=Math.atan2(z,x);
        const edge=Math.max(0,1-y/(height*.36));
        a.setY(i,y+(Math.cos(theta*7)*.080+.035)*edge);
      }
      geometry.computeVertexNormals();return geometry;
    });
  }
  createTree(scale = 1, snowy = false) {
    const root = new THREE.Group(); root.scale.setScalar(scale);
    this.part(root, this.cylinder(.19, .95, 12), 0xa77754, 0, .475, 0);
    for (const [r,h,y] of [[.95,1.45,.52],[.73,1.30,1.37],[.50,1.20,2.10]]) {
      this.part(root, this.snowCone(r*1.016,h*.94), snowy ? 0x7998b8 : 0x537d9b, 0, y-.075, 0);
      this.part(root, snowy?this.snowDrape(r,h):this.snowCone(r,h), snowy ? 0xdbe7f3 : 0x7bb9d0, 0, y, 0);
    }
    return this.compileStatic(root, `v11-tree-${snowy}`);
  }

  createStump() {
    const root=new THREE.Group();this.part(root,this.cylinder(0.26,0.35),C.wood,0,0.175,0);
    this.part(root,this.cylinder(0.22,0.02),C.end,0,0.355,0);return root;
  }
  createBear() {
    const root = new THREE.Group(), body = new THREE.Group(); root.add(body);
    const fur = this.material(0xefefeb, { roughness: .80 });
    const torso = this.part(body,this.capsule(.36,.98),fur,0,.70,-.05,Math.PI/2); torso.scale.set(1.03,1,.90);
    const shoulder = this.part(body,this.sphere(.385,16),fur,0,.74,.48); shoulder.scale.set(1,1.12,1.12);
    const neck = this.part(body,this.capsule(.23,.42),fur,0,.68,.85,Math.PI/2); neck.scale.set(1,.90,1);
    const head = this.part(body,this.sphere(.26,14),fur,0,.64,1.10); head.scale.set(.92,.86,1.35);
    const muzzle = this.part(body,this.sphere(.16,12),0xf8f5e9,0,.56,1.35); muzzle.scale.set(.82,.78,1.5);
    this.part(body,this.box(.14,.10,.085,.045),0x273746,0,.60,1.55);
    for (const sign of [-1,1]) {
      this.part(body,this.sphere(.096,10),fur,sign*.20,.86,.98);
      const ear=this.part(body,this.sphere(.043,8),0xc9c0b6,sign*.20,.86,1.06); ear.scale.z=.4;
      this.part(body,this.sphere(.021,8),0x2b3740,sign*.194,.723,1.25);
    }
    this.part(body,this.sphere(.12,10),fur,0,.65,-.97);
    this.compileStatic(body,'v11-bear-body');
    const legs=[];
    for(const x of [-.24,.24]) for(const z of [-.60,.48]) {
      const leg=new THREE.Group();leg.position.set(x,.47,z);root.add(leg);legs.push(leg);
      this.part(leg,this.capsule(.09,.25),fur,0,-.12,0);
      this.part(leg,this.box(.21,.13,.28,.065),fur,0,-.37,.07);
    }
    root.userData.legs=legs;root.userData.body=body;return root;
  }

  createResource(type) { return makeResource(this, type); }
  createFencePost(height=.78) {
    const root=new THREE.Group();
    this.part(root,this.cylinder(.184,height,14,.174),0xb97b43,0,height/2,0);
    this.part(root,this.cylinder(.172,.026,14),0xf4d69a,0,height+.010,0);
    this.part(root,this.cylinder(.136,.028,14),0xe5bc81,0,height+.012,0);
    this.part(root,this.cylinder(.116,.031,14),0xf2d3a0,0,height+.013,0);
    return this.compileStatic(root,`v11-fence-${height.toFixed(2)}`);
  }

  createGate(width=2.7) {
    const root=new THREE.Group();
    for(const x of [-width/2,width/2]) {
      this.part(root,this.box(0.17,0.85,0.18),0xdba354,x,0.42,0);
      this.part(root,this.box(0.23,0.075,0.23),C.white,x,0.89,0);
    }
    for(const x of [-1,1]) {
      const panel=new THREE.Group();panel.position.x=x*width/2;panel.rotation.y=-x*1.23;root.add(panel);
      this.part(panel,this.box(width/2,0.10,0.11),0xe1aa54,-x*width/4,0.72,0);
      this.part(panel,this.box(width/2,0.10,0.11),0xe1aa54,-x*width/4,0.18,0);
      this.part(panel,this.box(width/2,0.10,0.08),0x5ba8d7,-x*width/4,0.45,0,0,0,x*0.35);
    }return root;
  }
  createCampfire() {
    const root = new THREE.Group();
    const stone=this.geo('grill-stone',()=>new THREE.IcosahedronGeometry(.19,1));
    for(let i=0;i<12;i++){
      const a=i/12*Math.PI*2;
      const rock=this.part(root,stone,0x8c8d9b,Math.cos(a)*.56,.16,Math.sin(a)*.56);
      rock.scale.set(1,.73,1.12);rock.rotation.y=a;
    }
    for(let i=0;i<3;i++)this.part(root,this.cylinder(.085,.94,10),0x804a31,0,.17,0,Math.PI/2,i*Math.PI/3,0);
    const flames=[];
    for(let i=0;i<6;i++){
      const a=i*2.4,flame=new THREE.Group();flame.position.set(Math.cos(a)*.20,.23,Math.sin(a)*.20);
      const outer=this.part(flame,this.sphere(.215,12),this.basic(i%2?0xffa11b:0xff8319),0,.26,0);outer.scale.set(.80,1.8,.85);
      const tip=this.part(flame,this.snowCone(.13,.55),this.basic(0xffb623),.025,.42,0);tip.rotation.z=-.24;
      const inner=this.part(flame,this.sphere(.12,10),this.basic(0xffe445),0,.22,.065);inner.scale.set(.83,2,.7);
      root.add(flame);flames.push(flame);
    }
    const grill=new THREE.Group();grill.position.set(0,0,-.40);root.add(grill);
    for(const x of [-.50,.50])for(const z of [-.41,.39]) this.part(grill,this.cylinder(.045,.82,8),0x6c6873,x,.54,z);
    this.part(grill,this.box(1.24,.11,1.00,.025),0x777882,0,.99,0);
    this.part(grill,this.box(1.16,.025,.91,.015),0x34343c,0,1.06,0);
    root.userData.flames=flames;root.userData.grill=grill;return root;
  }

  createMarket() {
    const root=new THREE.Group();
    this.part(root,this.box(5.15,.18,1.03,.055),0xe9b663,0,.81,0);
    this.part(root,this.box(4.82,.10,.84,.025),0xf4cd83,0,.94,0);
    for(const x of [-2.28,2.28]) this.part(root,this.box(.18,.82,.21,.028),0xa77442,x,.40,.20);
    const register=new THREE.Group();register.position.set(1.85,1.035,.05);root.add(register);
    this.part(register,this.box(.47,.095,.44,.025),0x6c8494,0,0,0);
    this.part(register,this.box(.38,.025,.33,.013),0xaad8e3,0,.060,0);
    this.part(register,this.box(.31,.025,.12,.008),0x249aaa,0,.079,-.085);
    for(let i=0;i<3;i++)for(let j=0;j<3;j++)this.part(register,this.box(.065,.015,.058,.008),0x3e5669,(i-1)*.09,.082,.01+j*.08);
    return this.compileStatic(root,'v11-market');
  }
  decal(texture, width, depth, y=.045) {
    const key=`decal-material-${texture.uuid}`;
    if(!this.materials.has(key)) this.materials.set(key,new THREE.MeshBasicMaterial({map:texture,transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-2}));
    const mesh=new THREE.Mesh(this.geo('decal-plane',()=>new THREE.PlaneGeometry(1,1)),this.materials.get(key));
    mesh.rotation.x=-Math.PI/2;mesh.scale.set(width,depth,1);mesh.position.y=y;mesh.renderOrder=2;return mesh;
  }
  createPurchaseTile(cost, type='expand') {
    const root=new THREE.Group();
    root.add(this.decal(purchaseTexture(this,cost,type),1.15,1.15,.053));
    const outline=new THREE.Mesh(this.geo('buy-outline',()=>new THREE.RingGeometry(.52,.575,4)),this.basic(0xa7ff59,{transparent:true,opacity:.95,depthWrite:false}));
    outline.rotation.set(-Math.PI/2,0,Math.PI/4);outline.position.y=.059;outline.visible=false;root.add(outline);
    root.userData.outline=outline;return root;
  }
  createInputPad(type) {
    const root=new THREE.Group();root.add(this.decal(inputTexture(this,type),1.52,1.19,.057));
    const active=this.decal(inputTexture(this,type,true),1.52,1.19,.060);active.visible=false;root.add(active);root.userData.active=active;
    return root;
  }
  createWorker(role='wood') {
    const {root,visual}=this.createPlayer();
    root.scale.setScalar(.86);
    const coat={wood:0xe0c08b,raw:0xe6d0a9,seller:0xd88742,cashier:0x42977b}[role]??0xe6d0a9;
    visual.traverse(m=>{if(!m.isMesh)return;if(m.material===this.material(C.blue))m.material=this.material(coat);});
    return {root,visual};
  }
  createConveyor(length=2.4) {
    const root=new THREE.Group();
    this.part(root,this.box(.90,.14,length,.045),0xe5ae54,0,.115,0);
    this.part(root,this.box(.69,.05,length-.08,.025),0x3f3b40,0,.205,0);
    for(const x of [-.46,.46])this.part(root,this.box(.07,.12,length,.012),0xf3c878,x,.20,0);
    const cleats=[];
    for(let i=0;i<8;i++){const m=this.part(root,this.box(.68,.018,.043,.007),0x777074,0,.242,-length/2+i*length/8);cleats.push(m);}
    root.userData.cleats=cleats;root.userData.length=length;return root;
  }

  createPad(w,d,color=0x65b76a) {
    const root=new THREE.Group();
    this.part(root,this.box(w,0.075,d,0.07),color,0,0.055,0);
    this.part(root,this.box(w-0.12,0.02,d-0.12,0.07),0x554b4a,0,0.108,0);
    this.part(root,this.box(w-0.23,0.005,d-0.23,0.05),0x786962,0,0.122,0);
    return root;
  }
  createCrate() {
    const root=new THREE.Group();this.part(root,this.box(0.95,0.65,0.8),0xcb9b64,0,0.33,0);
    for(const y of [0.12,0.56])this.part(root,this.box(1.02,0.085,0.83),0xe8b975,0,y,0);
    for(const x of [-0.39,0.39])this.part(root,this.box(0.075,0.63,0.85),0xe8b975,x,0.33,0);
    this.part(root,this.box(0.78,0.09,0.08),0xa86f45,0,0.35,0.44,0,0,0.55);return root;
  }
  createCabin() {
    const root=new THREE.Group();
    this.part(root,this.box(2.6,1.9,2.1,0.04),0x986e52,0,0.95,0);
    for(const y of [0.4,0.8,1.2,1.6])this.part(root,this.box(2.66,0.09,2.16,0.025),0xbd9270,0,y,0);
    for(const sign of [-1,1])this.part(root,this.box(1.82,0.15,2.55,0.045),C.snow,sign*0.64,2.21,0,0,0,-sign*0.5);
    this.part(root,this.box(0.61,1.22,0.055),0x425465,0,0.61,1.085);
    for(const x of [-0.82,0.82]){
      this.part(root,this.box(0.46,0.55,0.05),C.end,x,1.17,1.09);
      this.part(root,this.box(0.36,0.43,0.07),this.basic(0xffdc83),x,1.17,1.12);
      this.part(root,this.box(0.04,0.45,0.08),0x8e6345,x,1.17,1.16);
    }return root;
  }
  /** Flatten static objects into a handful of instanced draw calls, sharing assets. */
  batchStatic(roots) {
    const buckets=new Map();
    for(const root of roots){root.updateMatrixWorld(true);root.traverse(mesh=>{
      if(!mesh.isMesh)return;const key=mesh.geometry.uuid+mesh.material.uuid+mesh.castShadow;
      if(!buckets.has(key))buckets.set(key,{geometry:mesh.geometry,material:mesh.material,castShadow:mesh.castShadow,matrices:[]});
      buckets.get(key).matrices.push(mesh.matrixWorld.clone());
    });}
    const result=new THREE.Group();
    for(const item of buckets.values()) {
      const batch=new THREE.InstancedMesh(item.geometry,item.material,item.matrices.length);
      item.matrices.forEach((m,i)=>batch.setMatrixAt(i,m));batch.castShadow=item.castShadow;batch.receiveShadow=true;
      batch.frustumCulled=false;result.add(batch);this.staticBatches.add(batch);
    }return result;
  }
  shadowTexture() {
    const key='blob-shadow';if(this.shadowMap)return this.shadowMap;
    const canvas=document.createElement('canvas');canvas.width=canvas.height=64;
    const ctx=canvas.getContext('2d'),g=ctx.createRadialGradient(32,32,3,32,32,31);
    g.addColorStop(0,'rgba(63,77,102,0.27)');g.addColorStop(0.5,'rgba(63,77,102,0.12)');g.addColorStop(1,'rgba(46,70,102,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,64,64);this.shadowMap=new THREE.CanvasTexture(canvas);this.textures.add(this.shadowMap);return this.shadowMap;
  }
  blob(width=1,depth=width) {
    const matKey='blob';if(!this.materials.has(matKey))this.materials.set(matKey,new THREE.MeshBasicMaterial({map:this.shadowTexture(),transparent:true,depthWrite:false,polygonOffset:true,polygonOffsetFactor:-1}));
    const mesh=new THREE.Mesh(this.geo('blob-plane',()=>new THREE.PlaneGeometry(1,1)),this.materials.get(matKey));
    mesh.rotation.x=-Math.PI/2;mesh.scale.set(width,depth,1);mesh.position.y=0.027;return mesh;
  }
  dispose() {
    for(const batch of this.staticBatches)batch.dispose?.();this.staticBatches.clear();
    for(const geo of this.geometries.values())geo.dispose();for(const mat of this.materials.values())mat.dispose();for(const tex of this.textures)tex.dispose();
    this.geometries.clear();this.materials.clear();this.textures.clear();this.compiled.clear();this.decalCache?.clear();this.shadowMap=null;
  }
}
