import * as THREE from 'three';

function steakShape() {
  const s = new THREE.Shape();
  s.moveTo(-.27, -.10);
  s.bezierCurveTo(-.34, .02, -.28, .22, -.09, .18);
  s.bezierCurveTo(.05, .19, .24, .12, .30, -.05);
  s.bezierCurveTo(.36, -.23, .12, -.25, .01, -.16);
  s.bezierCurveTo(-.10, -.23, -.21, -.22, -.27, -.10);
  return s;
}
function steakGeometry(factory, key, scale = 1, depth = .13) {
  return factory.geo(key, () => {
    const geometry = new THREE.ExtrudeGeometry(steakShape(), {
      depth, bevelEnabled: true, bevelSize: .018, bevelThickness: .014,
      bevelSegments: 2, curveSegments: 9, steps: 1,
    });
    geometry.rotateX(-Math.PI / 2); geometry.translate(0, -depth / 2, 0); geometry.scale(scale, 1, scale);
    return geometry;
  });
}
export function makeResource(factory, type) {
  const f = factory, root = new THREE.Group(); root.name = `resource-${type}`;
  if (type === 'wood') {
    f.part(root, f.cylinder(.112, .78, 12), 0xb67642, 0, 0, 0, 0, 0, Math.PI / 2);
    for (const x of [-.394, .394]) {
      f.part(root, f.cylinder(.095, .012, 12), 0xf2c78d, x, 0, 0, 0, 0, Math.PI / 2);
      f.part(root, f.cylinder(.058, .015, 12), 0xdfae71, x * 1.012, 0, 0, 0, 0, Math.PI / 2);
      f.part(root, f.cylinder(.041, .016, 12), 0xf2c78d, x * 1.016, 0, 0, 0, 0, Math.PI / 2);
    }
  } else if (type === 'raw' || type === 'cooked') {
    const raw = type === 'raw';
    f.part(root, steakGeometry(f, 'steak-outline'), raw ? 0xffdbba : 0xe3a260);
    f.part(root, steakGeometry(f, 'steak-inner', .85, .148), raw ? 0xe85461 : 0xa44727, 0, .008, 0);
    if (raw) {
      const bone = f.part(root, f.cylinder(.055, .008, 14), 0xffebce, .12, .097, -.035); bone.scale.z = 1.40;
      const marbling = new THREE.QuadraticBezierCurve3(new THREE.Vector3(-.19, .097, .035), new THREE.Vector3(-.08, .108, -.04), new THREE.Vector3(.01, .097, .09));
      const geometry = f.geo('marbling', () => new THREE.TubeGeometry(marbling, 10, .007, 4, false));
      f.part(root, geometry, 0xffb4a2);
    } else {
      for (const x of [-.16, -.035, .09]) f.part(root, f.box(.022, .009, .23, .004), 0x643521, x, .102, -.005, 0, .28, 0);
    }
  } else if (type === 'cash') {
    f.part(root, f.box(.69, .12, .37, .016), f.material(0x53e51d, { roughness: .65 }), 0, 0, 0);
    f.part(root, f.box(.60, .005, .28, .012), 0x7dff38, 0, .064, 0);
    f.part(root, f.box(.30, .007, .20, .01), 0x48c921, 0, .070, 0);
    const dollar = f.part(root, f.cylinder(.070, .009, 12), 0xccff7c, 0, .077, 0); dollar.scale.z = .8;
    f.part(root, f.box(.015, .007, .13, .003), 0x41852d, 0, .084, 0);
  } else if (type === 'fish' || type === 'cookedFish') {
    const cooked = type === 'cookedFish';
    const body = f.part(root, f.sphere(.25, 12), cooked ? 0xc28a43 : 0x2494c9); body.scale.set(1.5, .31, .50);
    const belly = f.part(root, f.sphere(.18, 10), cooked ? 0xe3b771 : 0x8bdad8, .03, -.018, .026); belly.scale.set(1.65, .32, .59);
    const tail = f.part(root, f.cylinder(.135, .19, 3, .015), cooked ? 0x8d6236 : 0x285e9b, -.37, .012, 0, 0, 0, Math.PI / 2); tail.scale.x = .35;
    f.part(root, f.sphere(.024, 8), 0x253d54, .24, .057, .065);
    if (cooked) for (const x of [-.12, 0, .12]) f.part(root, f.box(.020, .008, .18, .004), 0x705139, x, .082, 0, 0, .2, 0);
  } else if (type === 'berry') {
    // 雪莓：三颗小浆果 + 一片小叶
    for (const [x, z, r] of [[-.09, .02, .085], [.08, .06, .075], [0, -.08, .07]])
      f.part(root, f.sphere(r, 8), 0x8a5fc0, x, r * .8, z);
    f.part(root, f.box(.10, .012, .05, .004), 0x4e7d5b, .02, .13, 0, 0, .4, 0);
  } else throw new Error(`Unknown resource type: ${type}`);
  return f.compileStatic(root, `v11-resource-${type}`);
}
