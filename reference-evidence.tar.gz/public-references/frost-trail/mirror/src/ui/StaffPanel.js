import { RESOURCE } from '../simulation/Balance.js';
import { STAFF_ROLES, STAFF_STATUS } from '../simulation/CounterStaff.js';

export class StaffPanel {
  constructor({ state, onPause, audio, signal }) {
    this.state = state;
    this.rows = new Map();
    this.entry = document.getElementById('staff-button');
    this.panel = document.getElementById('staff-panel');
    this.summary = document.getElementById('staff-summary');
    this.reserve = document.getElementById('staff-reserve');
    this.feedback = document.getElementById('staff-feedback');
    const opts = { signal };
    document.getElementById('staff-done').addEventListener('click', () => onPause(false), opts);
    this.entry.addEventListener('click', () => {
      onPause(true);
      this.panel.scrollIntoView({ block: 'start' });
      this.panel.focus({ preventScroll: true });
    }, opts);
    for (const [role, config] of Object.entries(STAFF_ROLES)) {
      const row = document.createElement('div'); row.className = `staff-row staff-${role}`;
      const copy = document.createElement('div'), name = document.createElement('strong'), status = document.createElement('span');
      name.textContent = config.name; status.className = 'staff-status';
      copy.append(name, status);
      const button = document.createElement('button'); button.dataset.staff = role;
      button.addEventListener('click', () => {
        const worker = state.camp.staff[role];
        if (!worker.hired) {
          if (state.hireStaff(role)) {
            audio.play('unlock');
            this.feedback.textContent = `${config.name}已到岗，继续经营后开始工作。`;
          }
        } else {
          state.setStaffEnabled(role, !worker.enabled);
          this.feedback.textContent = `${config.name}${worker.enabled ? '已恢复工作' : role === 'seller' ? '已停工，随身货物保留' : '已停工，现金留在柜台'}。`;
        }
        this.update();
      }, opts);
      row.append(copy, button); document.getElementById('staff-list').append(row);
      this.rows.set(role, { row, status, button });
    }
    this.reserve.addEventListener('change', () => {
      state.setStaffReserve(Number(this.reserve.value));
      this.update();
    }, opts);
    this.update();
  }

  update() {
    const { staff } = this.state.camp;
    const count = Object.keys(STAFF_ROLES).filter(role => staff[role].hired).length;
    this.entry.textContent = `员工 ${count}/2`;
    this.entry.setAttribute('aria-label', `柜台员工，已雇佣 ${count} 人，共 2 个岗位`);
    this.summary.textContent = `${count} / 2 人到岗`;
    for (const [role, { status, button }] of this.rows) {
      const worker = staff[role], config = STAFF_ROLES[role];
      const description = worker.hired
        ? `${STAFF_STATUS[worker.status] ?? '已到岗'}${worker.cargo ? ` · 携带${RESOURCE[worker.cargo.type].name} ${worker.cargo.count} 份` : ''}`
        : role === 'seller' ? '搬运仓储烤肉、鲜鱼并出售' : '柜台现金自动存入钱包';
      status.textContent = description + (!worker.hired && this.state.cash < config.cost ? ` · 还差 $${config.cost - this.state.cash}` : '');
      button.disabled = !worker.hired && this.state.cash < config.cost;
      button.textContent = worker.hired ? worker.enabled ? '暂停工作' : '恢复工作' : `雇佣 $${config.cost}`;
      button.setAttribute('aria-label', `${config.name} · ${button.textContent}`);
      button.title = button.disabled ? `还差 $${config.cost - this.state.cash}` : '';
      if (worker.hired) button.setAttribute('aria-pressed', String(worker.enabled));
      else button.removeAttribute('aria-pressed');
    }
    if (![...this.reserve.options].some(option => Number(option.value) === staff.reserve)) {
      this.reserve.add(new Option(`${staff.reserve} 份`, staff.reserve));
    }
    this.reserve.value = String(staff.reserve);
  }

  dispose() { for (const { row } of this.rows.values()) row.remove(); }
}
