import { RESOURCE, BALANCE, STATIONS, PURCHASES, ERA_GATED_PURCHASES, LOAD_RULES, AI_CAMPS } from '../simulation/Balance.js';
import { QUESTS, chapterSize, chapterOf } from '../systems/QuestSystem.js';
import { ERA_NAMES } from '../simulation/Ages.js';
import { SUPPLY_CARDS, ANNEX_CARDS, POWERS } from '../simulation/Prestige.js';
import { StaffPanel } from './StaffPanel.js';

// —— 扩展 UI 文案表（可调）——
const ERA_NUMERALS = ['Ⅰ', 'Ⅱ', 'Ⅲ', 'Ⅳ'];
const STANCE_LABELS = { hostile: '敌对', neutral: '中立', allied: '结盟', dependent: '依附', merged: '已吞并' };
const BUILDING_LABELS = { warehouse: '仓库（雇齐猎手与伐木工）', belt: '传送带', tradePost: '贸易站', lampline: '灯网', stoneWall: '石墙', watchPost: '哨塔' };
const MODIFIER_LABELS = { forestry: '伐木速度 +20%', hunting: '狩猎速度 +20%', wolfDeterrence: '狼群强度 -20%',
  tradeRoutes: '商路收益 +25%', nightDefense: '夜防 +25%', cooking: '加工速度 +30%', morale: '夜防 +20%', prestige: '声望收益 +25%' };
const UNLOCK_LABELS = { fastAxe: '快斧', wolfWard: '驱狼图腾', sledgeConvoy: '雪橇商队', alarmBell: '警报钟', fastGrill: '高效炉火', hegemonBanner: '霸主旗' };
const GIFT_COST = 50; // 与 GameState.giftFaction 的扣款一致（可调）
const PATH_LABELS = { hegemony: '霸权', wonder: '奇观', relics: '圣物', conquest: '征服', siege: '围困绞杀', buyout: '经济收购', assault: '武力远征' };
const GUARD_COST = 30; // 与 Caravans.guardCost 一致（可调）
const REACTION_LABELS = { aid: '派工赶工', 'price-hike': '坐地起价', attack: '集结进攻' };
const CARAVAN_PHASE_LABELS = { outbound: '去程', selling: '售卖中', returning: '返程', idle: '空闲' };
const MILESTONE_LABELS = { era2Day: '升代 Ⅱ 木屋营', era3Day: '升代 Ⅲ 集镇营', era4Day: '升代 Ⅳ 冰城营', firstAnnexDay: '首次吞并', victoryDay: '登顶雪原霸主' };
const SIEGE_COST = 40; // 与 GameState 围困日供一致（可调）

export class HUD {
  constructor({state,sceneSetup,map,quest,player,audio,interaction,onPause,onReset,onSettings}) {
    Object.assign(this,{state,sceneSetup,map,quest,player,audio,interaction,onPause,onReset,onSettings});
    const ids=['cash','cash-receipt','discard-button','capacity','inventory','toast','action-status','cook-progress','quest-step','quest-count','quest-title','quest-detail','quest-fill','controls-hint','modal','upgrade-button','quality-label','sound-button','camera-label','counter-note','counter-cash','production-status','auto-stock',
      'day-count','daynight-icon','daynight-fill','era-name','era-status','era-upgrade-button','era-missing','faction-list','landmark-modal','landmark-options',
      'endgame-banner','endgame-title','endgame-fill','endgame-count','endgame-reactions','hegemony-progress','wonder-status','wonder-button','relic-status','conquest-status',
      'victory-overlay','victory-title','victory-detail','victory-milestones','raid-report','raid-report-text','threat-pill',
      'prestige-points','supply-status','supply-grid','power-row','event-list','caravan-speed-button',
      'corral-actions','slaughter-button','feed-button','chapter-banner','version-line',
      'quest','quest-next','quest-prerequisites','quest-action','quest-beacon','quest-beacon-arrow','quest-beacon-title','quest-beacon-detail',
      'quest-route','quest-route-bounds','quest-route-outline','quest-route-line','quest-menu-guide','quest-menu-title','quest-menu-detail','quest-menu-action'];
    this.elements=Object.fromEntries(ids.map(id=>[id,document.getElementById(id)]));
    this.abort=new AbortController();this.cashReceiptAmount=0;this.cashReceiptTime=0;this.toastTime=0;this.time=0;this.lastInventory='';this.labelEntries=[];this.lastDay=0;this.lastEventKey='';this.bannerTime=0;
    this.navigationGuide=null;this.guidedMenu=false;this.guideMenuId=null;this.guideHighlight=null;
    this.questResize=new ResizeObserver(()=>document.getElementById('game').style.setProperty('--quest-height',`${this.elements.quest.offsetHeight}px`));
    this.questResize.observe(this.elements.quest);
    const opts={signal:this.abort.signal};
    this.staffPanel=new StaffPanel({state,onPause,audio,signal:this.abort.signal});
    const on=(id,fn)=>document.getElementById(id).addEventListener('click',fn,opts);
    on('pause-button',()=>onPause());on('resume-button',()=>onPause(false));on('help-button',()=>onPause(true));
    on('sound-button',()=>{audio.setEnabled(!audio.enabled);this.updateSound();onSettings?.();});
    on('quality-button',()=>{sceneSetup.setQuality(sceneSetup.quality==='high'?'low':'high');this.updateSettings();onSettings?.();});
    on('camera-button',()=>{sceneSetup.setCameraMode(sceneSetup.cameraMode==='reference'?'classic':'reference');this.updateSettings();onSettings?.();});
    on('upgrade-button',()=>{
      if(state.upgradeBackpack()){this.notify('背包已扩容 · 可以携带 60 份资源');audio.play('unlock');}
      else if(!state.backpackUpgraded)this.notify(`背包扩容还需要 $${Math.max(0,BALANCE.backpackCost-state.cash)}`);
      this.updateData();
    });
    on('discard-button',()=>{
      if(state.freeSlots>0||!state.count('raw'))return;
      if(!window.confirm('仅丢弃 1 份生肉，腾出一个背包位置？不会返还现金，其他资源和钱包不变。'))return;
      if(state.discardRaw())this.notify('已腾出 1 个位置 · 其他资源和现金不变');
    });
    on('reset-button',()=>{if(window.confirm('清空本机进度，重新经营雪原小营？'))onReset();});
    on('quest',()=>this.activateQuestGuide());
    on('quest-beacon',()=>this.activateQuestGuide());
    on('quest-menu-action',()=>this.activateQuestGuide());
    for(const button of document.querySelectorAll('[data-route]'))button.addEventListener('click',()=>{
      let key=button.dataset.route;if(key==='buy'&&state.unlockedPond)key='fish';onPause(false);player.moveTo(STATIONS[key]);
    },opts);
    this.upgradeButtons={};
    for(const [key,definition]of Object.entries(PURCHASES)){
      const button=document.createElement('button'),name=document.createElement('span'),value=document.createElement('strong');
      name.textContent=definition.name;value.textContent=`$${definition.cost}`;button.append(name,value);
      button.addEventListener('click',()=>{onPause(false);player.moveTo(definition.target);},opts);
      document.getElementById('upgrade-grid').appendChild(button);this.upgradeButtons[key]={button,value};
    }
    on('era-upgrade-button',()=>{
      if(state.startEraUpgrade()){this.notify('升代施工开始 · 期间加工停产，当夜夜袭加强');audio.play('unlock');}
      else this.notify('升代门槛未满足 · 缺口见上方清单');
      this.updateData();
    });
    on('wonder-button',()=>{
      if(state.startWonder()){this.notify('永恒篝火开工 · 建造期袭击翻倍，备好防务');audio.play('unlock');}
      else this.notify('奇观开工资源不足 · 需 $8000 + 仓储木材 150 + 仓储烤肉 40');
      this.updateData();
    });
    on('victory-close',()=>this.closeBlockingModal());
    // 势力面板：行 + 可展开吞并区块（三路径 + 商路），结构一次建好，updateExtensions 刷新文案与按钮态
    this.factionRows=state.factions.list().map(f=>{
      const item=document.createElement('div');item.className='faction-item';
      const row=document.createElement('div');row.className='faction-row';
      const main=document.createElement('button');main.className='faction-main';main.setAttribute('aria-expanded','false');
      const name=document.createElement('strong');name.textContent=f.name;
      const tag=document.createElement('span');tag.className='faction-tag';main.append(name,tag);
      const rel=document.createElement('span');rel.className='faction-rel';
      const gift=document.createElement('button');gift.textContent=`送礼 $${GIFT_COST}`;
      gift.setAttribute('aria-label',`向${f.name}送礼，$${GIFT_COST}`);
      gift.addEventListener('click',()=>{
        if(state.giftFaction(f.id)){this.notify(`已向${f.name}送礼 · 关系升温`);audio.play('unlock');}
        else this.notify(state.cash<GIFT_COST?`送礼还差 $${Math.max(0,GIFT_COST-state.cash)}`:'对方已并入营地，无需送礼');
        this.updateData();
      },opts);
      row.append(main,rel,gift);
      const detail=document.createElement('div');detail.className='faction-detail';detail.hidden=true;
      detail.innerHTML=`<div class="fd-row"><button data-k="visit">前往营门</button><button data-k="declareWar">宣战 · 关系转敌对</button></div>`
        +`<div class="fd-section"><div class="fd-row"><span>雪橇商路</span><span class="fd-route-status"></span></div>`
        +`<div class="fd-row"><button data-k="openRoute">开通商路</button><button data-k="guards">护卫 ×0</button><button data-k="dispatch">派出商队 · 木×20</button></div></div>`
        +`<div class="fd-section"><div class="fd-row"><span>互市</span><span class="fd-barter-text"></span></div>`
        +`<div class="fd-row"><button data-k="sellDemand">卖给需求</button><button data-k="buyOffer">买对方报价</button></div></div>`
        +`<div class="fd-section"><div class="fd-row"><span>围困绞杀</span><span class="fd-siege-text"></span></div>`
        +`<div class="fd-bar" title="围困压力"><i class="fd-pressure"></i></div><div class="fd-bar dim" title="对方战备值"><i class="fd-readiness"></i></div>`
        +`<div class="fd-row"><button data-k="siege"></button><button data-k="tribute">签朝贡契约</button></div></div>`
        +`<div class="fd-section"><div class="fd-row"><span>经济收购</span><span class="fd-buyout-text"></span></div>`
        +`<div class="fd-bar"><i class="fd-acquisition"></i></div><div class="fd-row"><button data-k="buyout"></button></div></div>`
        +`<div class="fd-section"><div class="fd-row"><span>武力吞并</span><span class="fd-assault-text"></span></div>`
        +`<div class="fd-bar"><i class="fd-defense"></i></div>`
        +`<div class="fd-row"><button data-k="raid">突袭 · 需到门口</button><button data-k="assault">总攻</button></div></div>`;
      main.addEventListener('click',()=>{detail.hidden=!detail.hidden;main.setAttribute('aria-expanded',String(!detail.hidden));},opts);
      const btns={};
      for(const b of detail.querySelectorAll('button')){btns[b.dataset.k]=b;b.addEventListener('click',()=>this.factionAction(f.id,b.dataset.k),opts);}
      item.append(row,detail);this.elements['faction-list'].appendChild(item);
      return {id:f.id,main,row,item,tag,rel,gift,detail,btns,
        routeStatus:detail.querySelector('.fd-route-status'),siegeText:detail.querySelector('.fd-siege-text'),
        barterText:detail.querySelector('.fd-barter-text'),
        buyoutText:detail.querySelector('.fd-buyout-text'),assaultText:detail.querySelector('.fd-assault-text'),
        bars:{pressure:detail.querySelector('.fd-pressure'),readiness:detail.querySelector('.fd-readiness'),
          acquisition:detail.querySelector('.fd-acquisition'),defense:detail.querySelector('.fd-defense')}};
    });
    // 护卫选择（每势力记忆，0–4 循环）与补给/大招/提速/待办
    this.guardChoice={};
    this.supplyButtons={};
    for(const c of state.prestige.cardList()){
      const button=document.createElement('button');button.className='supply-card';
      button.title=c.desc;
      button.addEventListener('click',()=>{
        const name=state.callSupplyCard(c.id);
        if(name){this.notify(`补给「${name}」已送达 · 雪橇已入仓`);audio.play('unlock');}
        else this.notify(c.annex&&!state.prestige.unlocked.has(c.id)?'需先吞并对应势力解锁':'声望不足下一档');
        this.updateData();
      },opts);
      this.elements['supply-grid'].appendChild(button);this.supplyButtons[c.id]={button,card:c};
    }
    this.powerButtons={};
    for(const [id,p] of Object.entries(POWERS)){
      const button=document.createElement('button');button.className='power-button';
      button.title=p.desc;
      button.addEventListener('click',()=>{
        const use=state.usePower(id);
        if(use)this.notify(`祖灵大招「${p.name}」发动${use.cost?` · 声望 -${use.cost}`:' · 首次免费'}`);
        else this.notify(id==='blizzard'?'暴风雪每晚限一次':'声望不足');
        this.updateData();
      },opts);
      this.elements['power-row'].appendChild(button);this.powerButtons[id]=button;
    }
    on('caravan-speed-button',()=>{
      if(state.caravans.upgradeSpeed()){this.notify('雪橇提速完成 · 商队往返更快');audio.play('unlock');}
      else this.notify(state.caravans.speedLevel>=2?'雪橇已到最高速':'现金不足');
      this.updateData();
    });
    // 驯鹿围栏浮动操作：宰杀最肥 / 投喂雪莓
    on('slaughter-button',()=>{
      const r=state.slaughterDeer();
      if(r){this.notify(`宰杀驯鹿 · 生肉 ×${r.meat} 入仓（栏内 ${state.corralDeer.length} 头）`);audio.play('pickup');}
      else if(state.corralDeer.length)this.notify('生肉仓位不足 · 先取走一些生肉再宰杀');
      this.updateData();
    });
    on('feed-button',()=>{
      if(state.feedBerry()){this.notify('投喂雪莓 · 全栏增肥加速半天');audio.play('pickup');}
      else this.notify('需要栏内有鹿且背包有雪莓');
      this.updateData();
    });
    // Focus trap keeps keyboard navigation inside the pause dialog.
    for(const modal of [this.elements.modal,this.elements['landmark-modal'],this.elements['victory-overlay']])modal.addEventListener('keydown',event=>{
      if(event.key!=='Tab')return;
      const nodes=[...modal.querySelectorAll('button:not(:disabled),select:not(:disabled),summary')].filter(n=>n.offsetParent!==null);
      const first=nodes[0],last=nodes.at(-1);
      if(event.shiftKey&&document.activeElement===first){event.preventDefault();last?.focus();}
      else if(!event.shiftKey&&document.activeElement===last){event.preventDefault();first?.focus();}
    },opts);
    this.makeLabels();this.unsubscribe=state.events.on('change',()=>this.updateData());
    this.cashUnsubscribe=state.events.on('cash-collected',amount=>{
      this.cashReceiptAmount+=amount;this.cashReceiptTime=1.1;
      const receipt=this.elements['cash-receipt'];receipt.textContent=`+$${this.cashReceiptAmount}`;receipt.hidden=false;
    });
    // 扩展模块事件提示（payload 带 factionId 的 era-* 来自 AI 营地，不冒泡）
    const factionName=id=>state.factions.list().find(f=>f.id===id)?.name??id;
    this.factionName=factionName;
    this.extUnsubs=[
      state.events.on('daynight-phase',p=>{if(p.phase==='night')this.notify(`第 ${p.day} 天 · 夜幕降临，注意值守`);}),
      state.events.on('daynight-day',p=>{const n=this.state.pendingEvents.length;this.notify(`第 ${p.day} 天 · 黎明到来${n?` · 邻营有 ${n} 条待办（菜单查看）`:''}`);}),
      state.events.on('faction-stance',p=>this.notify(`${factionName(p.id)} 立场变为「${STANCE_LABELS[p.stance]??p.stance}」`)),
      state.events.on('era-upgrade-start',p=>{if(!p.factionId)this.notify('升代施工开始 · 加工停产，当夜夜袭加强');}),
      state.events.on('era-upgraded',p=>{if(!p.factionId)this.openLandmarkModal(p.era);}),
      state.events.on('landmark-lost',p=>this.notify(p.factionId?`落选地标被${factionName(p.factionId)}建起 · 吞并它可夺回`:'一座落选地标流落在雪原')),
      // 吞并 / 商队 / 终局
      state.events.on('annex-buyout-available',p=>this.notify(`${factionName(p.factionId)} 同意收购谈判 · 一口价 $${p.cost}`)),
      state.events.on('annex-occupation-start',p=>{this.notify(`已攻破${factionName(p.factionId)} · 守住营火 ${Math.round(p.seconds)} 秒`);this.audio.play('unlock');}),
      state.events.on('annex-counter-wave',p=>this.notify(p.held?`${factionName(p.factionId)}的反扑被留守兵力击退`:`${factionName(p.factionId)}反扑成功 · 占领倒计时重置！`)),
      state.events.on('annex-complete',p=>{this.notify(`${factionName(p.factionId)}已并入营地 · ${PATH_LABELS[p.path]??p.path} · 战利品入账`);this.audio.play('unlock');}),
      state.events.on('siege-ended',p=>this.notify(`对${factionName(p.id)}的围困中断 · 维持费不足`)),
      state.events.on('caravan-dispatch',p=>this.notify(`商队出发 → ${factionName(p.factionId)} · 木材 ×${p.cargo.count}`)),
      state.events.on('caravan-ambushed',p=>{const parts=[];if(p.loss.cargo)parts.push(`货物 ×${p.loss.cargo}`);if(p.loss.cash)parts.push(`现金 $${p.loss.cash}`);this.notify(`商队遇袭 · 损失${parts.join('、')||'无'}`);}),
      state.events.on('caravan-arrived',p=>{if(p.earnings>0)this.notify(`商队归来 · 收益 $${p.earnings} 已入柜台托管`);}),
      state.events.on('endgame-countdown-start',p=>this.notify(`全图公开倒计时启动 · ${PATH_LABELS[p]??p}之路 · 各势力开始表态`)),
      state.events.on('endgame-victory',p=>this.showVictory(p)),
      state.events.on('raid-report',p=>this.notify(p.repelled?`第 ${p.day} 夜击退来袭（强度 ${p.strength}）· 奖励已入柜台`:`第 ${p.day} 夜防线被突破 · 库存受损，加固防务！`)),
      state.events.on('lamp-added',p=>{if(p.level>1)this.notify(`灯网升至 Lv.${p.level} · 采集加速与商路护航增强`);}),
      state.events.on('quest',()=>{ // 章节跨越横幅
        const i=this.state.quest;if(i<1||i>QUESTS.length)return;
        const before=chapterOf(i-1),now=chapterOf(Math.min(i,QUESTS.length-1));
        if(now.id!==before.id){
          const b=this.elements['chapter-banner'];
          b.textContent=i<QUESTS.length?`${now.name} · 新章节开启`:'全部章节完成 · 雪原传奇';
          b.hidden=false;this.bannerTime=3.4;this.audio.play('quest');
        }
      }),
      state.events.on('greenhouse-halt',p=>this.notify(p.reason==='stock'?'温室满仓停产 · 先领取一些熟食':'温室缺木材停产 · 料仓补 2 根木材')),
      state.events.on('deer-lost',()=>this.notify('狼群夜袭拖走了一头驯鹿 · 把围栏纳入灯网覆盖！')),
    ];
    this.updateData();this.updateSettings();this.updateSound();
    this.elements['version-line'].textContent=`v2.0.0 · 种子 ${state.seedCode} · 分享此种子与朋友比拼同一雪原`;
    this.elements['version-line'].title='种子码：本局里程碑比拼标识（当前地形为固定布局，种子后续将接入地图生成）';
  }
  makeLabels(){
    const parent=document.getElementById('world-labels');
    for(const info of this.map.labels){
      const button=document.createElement('button');button.className=`world-label ${info.type}`;
      const title=document.createElement('strong');title.textContent=info.id==='buy'?'冰湖 · $200':info.title;button.append(title);
      button.setAttribute('aria-label',`${info.title}，${info.detail}，点击前往`);
      button.addEventListener('click',()=>{this.audio.unlock();this.player.moveTo(info.target);},{signal:this.abort.signal});
      parent.appendChild(button);this.labelEntries.push({info,button});
    }
  }
  activateQuestGuide(){
    if(this.blockingModal)return;
    this.audio.unlock();this.elements['controls-hint'].hidden=true;
    if(this.navigationGuide&&this.player.navigationGoal===this.navigationGuide.goal){
      this.player.stop();this.navigationGuide=null;this.notify('已停止带路 · 可自由移动');this.updateQuestGuide();return;
    }
    const guide=this.quest.guidance;
    if(guide.kind==='world'){
      this.onPause(false);
      if(this.player.moveTo(guide.target)){
        this.navigationGuide={id:guide.id,quest:this.state.quest,goal:this.player.navigationGoal};
        this.notify(`正在带路 · ${guide.title}（移动或再次点击任务卡可取消）`);
      }else this.notify('暂时无法到达目标，请先离开障碍附近再试');
    }else if(guide.kind==='resume'){
      this.onPause(false);this.notify(guide.detail);
    }else{
      this.guidedMenu=true;this.guideMenuId=null;this.onPause(true);this.focusQuestMenu(guide,true);
    }
    this.updateQuestGuide();
  }
  clearQuestMenu(){
    this.guideHighlight?.classList.remove('quest-highlight');this.guideHighlight=null;
    this.elements['quest-menu-guide'].hidden=true;this.guideMenuId=null;
  }
  focusQuestMenu(guide,force=false){
    const e=this.elements,note=e['quest-menu-guide'];
    e['quest-menu-title'].textContent=`下一步 · ${guide.title}`;
    e['quest-menu-detail'].textContent=guide.detail;
    e['quest-menu-action'].hidden=!['world','resume'].includes(guide.kind);
    e['quest-menu-action'].textContent=guide.actionLabel;
    if(!force&&this.guideMenuId===guide.id)return;
    this.guideHighlight?.classList.remove('quest-highlight');
    let target;
    if(guide.kind==='faction'){
      const row=this.factionRows.find(row=>row.id===guide.factionId);
      if(row){
        row.detail.hidden=false;row.main.setAttribute('aria-expanded','true');
        target=guide.control==='gift'?row.gift:guide.control==='barter'?row.btns.sellDemand.closest('.fd-section')
          :guide.control==='paths'?row.detail:row.btns[guide.control];
      }
    }else if(guide.kind==='panel')target=document.getElementById(guide.panelId);
    else target=document.getElementById('resume-button');
    if(!target)return;
    const anchor=target.closest('.fd-section,.faction-row')??target;
    anchor.before(note);note.hidden=false;
    target.classList.add('quest-highlight');this.guideHighlight=target;this.guideMenuId=guide.id;
    note.scrollIntoView({block:'start',behavior:'instant'});
    if(target.matches('button:not(:disabled)'))target.focus({preventScroll:true});
    else {note.tabIndex=-1;note.focus({preventScroll:true});}
  }
  updateQuestGuide(){
    const e=this.elements,guide=this.quest.guidance;
    if(this.navigationGuide&&(this.navigationGuide.id!==guide.id||this.navigationGuide.quest!==this.state.quest)){
      if(this.player.navigationGoal===this.navigationGuide.goal)this.player.stop();
      this.navigationGuide=null;
    }
    this.guidance=guide;
    e['quest-next'].textContent=`下一步 · ${guide.title}`;e['quest-detail'].textContent=guide.detail;
    e['quest-next'].hidden=guide.title===this.quest.current.title;
    e['quest-prerequisites'].hidden=!guide.progressLabel;e['quest-prerequisites'].textContent=guide.progressLabel??'';
    e.quest.setAttribute('aria-label',`${this.quest.current.title}。下一步：${guide.title}。${guide.actionLabel}`);
    if(this.guidedMenu&&!e.modal.hidden&&!this.blockingModal)this.focusQuestMenu(guide);
    this.updateQuestNavigation();
  }
  updateQuestNavigation(){
    const e=this.elements,g=this.guidance;if(!g)return;
    if(this.navigationGuide&&this.player.navigationGoal!==this.navigationGuide.goal)this.navigationGuide=null;
    const navigating=!!this.navigationGuide;
    e['quest-action'].textContent=navigating?'带路中 · 再点可停止':`${g.actionLabel} →`;
    e.quest.classList.toggle('navigating',navigating);
    const show=g.kind==='world'&&e.modal.hidden&&!this.blockingModal;
    e['quest-beacon'].hidden=!show;e['quest-route'].toggleAttribute('hidden',!show||!navigating);
    if(!show)return;
    const width=this.sceneSetup.width,height=this.sceneSetup.height;
    const p=this.sceneSetup.project({x:g.target.x,y:.12,z:g.target.z});
    const beacon=e['quest-beacon'];
    e['quest-beacon-title'].textContent=g.title;
    const distance=Math.hypot(g.target.x-this.player.position.x,g.target.z-this.player.position.z);
    e['quest-beacon-detail'].textContent=distance<.9?'已到目标 · 停下作业':navigating?'沿虚线前往 · 可手动接管':'任务目标 · 点击带路';
    const half=beacon.offsetWidth/2+12,halfHeight=beacon.offsetHeight/2+12;
    const top=document.querySelector('.top-hud').getBoundingClientRect().bottom+halfHeight;
    const bottom=Math.max(top,e.quest.getBoundingClientRect().top-halfHeight-8);
    const x=Math.max(half,Math.min(width-half,p.x)),y=Math.max(top,Math.min(bottom,p.y-34));
    beacon.style.left=`${x}px`;beacon.style.top=`${y}px`;
    beacon.dataset.offscreen=String(!p.visible||Math.abs(p.x-x)>1||p.y>bottom+34||p.y<top);
    if(beacon.dataset.offscreen==='true')e['quest-beacon-detail'].textContent=navigating?'画外目标 · 沿虚线前往':'目标在画外 · 点击带路';
    e['quest-beacon-arrow'].style.transform=`rotate(${Math.atan2(p.y-y,p.x-x)*180/Math.PI+90}deg)`;
    beacon.setAttribute('aria-label',`${g.title}，${navigating?'停止带路':'点击带路'}`);
    if(navigating){
      e['quest-route'].setAttribute('viewBox',`0 0 ${width} ${height}`);
      const bounds=e['quest-route-bounds'];bounds.setAttribute('x','0');bounds.setAttribute('y',String(top-halfHeight));
      bounds.setAttribute('width',String(width));bounds.setAttribute('height',String(Math.max(0,bottom-top+halfHeight)));
      const points=[this.player.position,...this.player.path].map(v=>this.sceneSetup.project({x:v.x,y:.12,z:v.z}))
        .map(v=>`${v.x.toFixed(1)},${v.y.toFixed(1)}`).join(' ');
      e['quest-route-outline'].setAttribute('points',points);e['quest-route-line'].setAttribute('points',points);
    }
  }
  updateData(){
    this.staffPanel.update();
    const s=this.state,e=this.elements;e.cash.textContent=s.cash.toLocaleString('en-US');e.capacity.textContent=`${s.inventory.length} / ${s.capacity}`;
    e['counter-note'].hidden=s.counterCash===0;e['counter-cash'].textContent=`$${s.counterCash}`;
    const counts=Object.fromEntries(Object.keys(RESOURCE).filter(t=>t!=='cash').map(t=>[t,s.count(t)])),key=JSON.stringify(counts);
    if(key!==this.lastInventory){
      this.lastInventory=key;e.inventory.replaceChildren();
      for(const [type,count]of Object.entries(counts)){
        if(!count)continue;const chip=document.createElement('div');chip.className='inventory-chip';chip.title=RESOURCE[type].name;
        chip.setAttribute('aria-label',`${RESOURCE[type].name} ${count}`);
        const icon=document.createElement('span');icon.className=`resource-icon ${type}`;icon.style.setProperty('--resource',RESOURCE[type].color);
        const amount=document.createElement('span');amount.textContent=String(count);chip.append(icon,amount);e.inventory.appendChild(chip);
      }
    }
    const q=this.quest.current,progress=this.quest.progress;
    e['quest-title'].textContent=q.title;
    const ch=this.quest.chapter,within=Math.min(s.quest,QUESTS.length-1)-ch.first+1;
    e['quest-step'].textContent=s.quest<QUESTS.length?`${ch.name} · ${within} / ${chapterSize(ch.id)}`:'全部章节完成 · 自由经营';
    e['quest-count'].textContent=q.total?`${Math.min(progress,q.total)} / ${q.total}`:`已售 ${s.stats.sold}`;
    e['quest-fill'].style.width=(q.total?Math.min(1,progress/q.total)*100:100)+'%';
    this.updateQuestGuide();
    e['upgrade-button'].disabled=s.backpackUpgraded;e['discard-button'].disabled=s.freeSlots>0||!s.count('raw');
    e['upgrade-button'].innerHTML=s.backpackUpgraded?'大号背包<strong>60 份 · 已扩容</strong>':'背包 36 → 60<strong>$120</strong>';
    e['auto-stock'].textContent=`烤肉 ${s.camp.stock.cooked}　鲜鱼 ${s.camp.stock.fish}`;
    const c=s.camp,load=s.getLoad(),cap=s.getLoadCap();
    e['production-status'].textContent=`工人 ${c.workers.length} / 4　负荷 ${load} / ${cap}　木材 ${c.stock.wood}　生肉 ${c.stock.raw}　成品 ${c.stock.cooked}　鲜鱼 ${c.stock.fish}${c.fishtraps?`　鱼陷阱 ${c.fishtraps}`:''}${c.purchases.corral?`　驯鹿 ${s.corralDeer.length}`:''}`;
    for(const [key,{button,value}]of Object.entries(this.upgradeButtons)){
      const gate=ERA_GATED_PURCHASES[key],locked=gate&&s.ages.getEra()<gate;
      const loadCost=LOAD_RULES.cost[key]??0,loadBlock=!c.purchases[key]&&loadCost>0&&load+loadCost>cap;
      button.disabled=c.purchases[key]||locked||loadBlock;
      value.textContent=c.purchases[key]?'已启用':locked?`时代${ERA_NUMERALS[gate-1]}解锁`:loadBlock?`负荷满 ${load}/${cap}`:`$${PURCHASES[key].cost}`;
    }
    for(const {info,button}of this.labelEntries)if(info.id==='buy')button.classList.toggle('affordable',s.cash>=BALANCE.pondCost);
    e['prestige-points'].textContent=String(Math.floor(s.prestige.points));
    if(!e.modal.hidden)this.updateExtensions();
  }
  /** 时代面板 + 势力面板刷新；数据来自 GameState.getExtensionState() 只读摘要。 */
  updateExtensions(){
    const s=this.state,e=this.elements,ext=s.getExtensionState();
    e['era-name'].textContent=`${ERA_NUMERALS[ext.era-1]??ext.era} ${ext.eraName}`;
    const owned=ext.landmarks.length?`地标 ${ext.landmarks.length} 座`:'';
    const btn=e['era-upgrade-button'];
    if(ext.eraUpgrading){
      btn.disabled=true;btn.innerHTML='升代施工中<strong>停产 · 夜袭加强</strong>';
      e['era-missing'].textContent='施工期约 1 天 · 完工后亲手选择本时代地标';
      e['era-status'].textContent=`⚠ 脆弱窗口 ${owned}`;
    }else if(ext.era>=4){
      btn.disabled=true;btn.innerHTML='冰城营<strong>已达最高时代</strong>';e['era-missing'].textContent='';
      e['era-status'].textContent=owned;
    }else{
      const chk=s.canUpgradeEra();btn.disabled=!chk.ok;
      btn.innerHTML=`升级到 ${ERA_NAMES[ext.era+1]}<strong>${chk.ok?'开工':'未满足门槛'}</strong>`;
      e['era-missing'].textContent=chk.ok?'门槛已满足 · 随时可开工':chk.missing.map(m=>m.kind==='resource'
        ?(m.id==='cash'?`现金 $${m.have} / $${m.need}`:`可支配木材 ${m.have} / ${m.need}`)
        :`${BUILDING_LABELS[m.id]??m.id}未建成`).join(' · ');
      e['era-status'].textContent=owned;
    }
    if(ext.lamps.count)e['era-status'].textContent+=` · 灯网Lv${ext.lamps.level}（${ext.lamps.count}根）`;
    this.factionRows.forEach((row,i)=>{
      const f=ext.factions[i];if(!f)return;
      row.tag.textContent=`${f.personalityLabel} · 时代${ERA_NUMERALS[f.campEra-1]??f.campEra}`;
      row.rel.textContent=`关系 ${f.relationship} · ${STANCE_LABELS[f.stance]??f.stance}`;
      row.rel.dataset.stance=f.stance;
      row.gift.disabled=f.stance==='merged'||s.cash<GIFT_COST;
      // 吞并三路径 + 商路区块
      const prog=s.annexation.getProgress(f.id),b=row.btns;
      const merged=f.stance==='merged',hostile=f.stance==='hostile',allied=['allied','dependent'].includes(f.stance);
      b.declareWar.disabled=merged||hostile||prog.assault.phase!=='none';
      b.declareWar.textContent=allied?'背盟宣战 · 留下背信记录':'宣战 · 关系转敌对';
      const routes=s.caravans.listRoutes().filter(r=>r.factionId===f.id&&r.type==='trade'),route=routes[0];
      row.routeStatus.textContent=merged?'已并入营地':route?`${CARAVAN_PHASE_LABELS[route.status]} · 估值 $${route.estimate}`:'未开通';
      b.openRoute.disabled=merged||!allied||!s.camp.purchases.tradePost||!!route;
      b.dispatch.disabled=!allied||!route||route.status!=='idle'||s.camp.stock.wood<20
        ||(s.coupons.guardVouchers===0&&s.cash<(this.guardChoice[f.id]??0)*GUARD_COST);
      const siegeOn=!!s.sieges[f.id],tribute=s.factions.getTribute(f.id);
      row.siegeText.textContent=merged?'—':`${siegeOn?'围困中':'未围困'} · 压力 ${Math.round(prog.siege.pressure)} · 战备 ${Math.round(prog.siege.warReadiness)}${tribute?.active?' · 朝贡中':''}`;
      row.bars.pressure.style.width=`${Math.min(100,prog.siege.pressure)}%`;
      row.bars.readiness.style.width=`${Math.min(100,prog.siege.warReadiness)}%`;
      b.siege.disabled=merged||(!siegeOn&&!hostile);b.siege.textContent=siegeOn?'解除围困':`围困 · $${SIEGE_COST}/天`;
      b.tribute.disabled=merged||prog.siege.pressure<50||tribute?.active;
      row.buyoutText.textContent=merged?'—':`额度 $${Math.round(prog.buyout.acquisition)} / $${prog.buyout.target}`;
      row.bars.acquisition.style.width=`${prog.buyout.percent}%`;
      b.buyout.disabled=merged||!allied||!prog.buyout.unlocked||s.cash<prog.buyout.cost;
      b.buyout.textContent=prog.buyout.unlocked?`收购 · $${prog.buyout.cost}`:'收购 · 额度未达标';
      const a=prog.assault;
      row.assaultText.textContent=merged?'已并入营地':a.phase==='occupying'?`占领 ${Math.ceil(a.occupation.remaining)}s · 留守 ${Math.round(Math.max(25,s.getDefense()))} / 反扑 ${8+s.annexation.factions.get(f.id).strength*6}`:a.phase==='assaulting'?'总攻交战中…':`防御 ${Math.round(a.defense)}${a.productionHalt>0?` · 停产 ${Math.ceil(a.productionHalt)} 分`:''}`;
      row.bars.defense.style.width=`${a.percent}%`;
      b.raid.disabled=merged||!hostile||s.distanceToGate(f.id)>3.2||a.phase!=='none';
      b.assault.disabled=merged||!hostile||s.distanceToGate(f.id)>3.2||!s.camp.purchases.siegeEngine||a.defense>=40||a.phase!=='none';
      // 互市（结盟后）：对方需求/报价各取首项；护卫选择
      const ledger=s.aiCamps.get(f.id),demand=ledger?.getDemands()[0],offer=ledger?.getOffers()[0];
      row.barterText.textContent=merged?'—':!allied?'结盟后开放':[demand?`缺${RESOURCE[demand.resource]?.name}×${demand.amount} · $${demand.unitPrice}/个`:null,offer?`售${RESOURCE[offer.resource]?.name}×${offer.amount} · $${offer.unitPrice}/个`:null].filter(Boolean).join('　')||'供需平衡';
      b.sellDemand.disabled=!allied||!demand||(s.camp.stock[demand?.resource]??0)<(demand?.amount??1);
      b.buyOffer.disabled=!allied||!offer||s.cash<(offer?.unitPrice??1)*(offer?.amount??1)||(BALANCE.maxStock-(s.camp.stock[offer?.resource]??0))<(offer?.amount??1);
      const g=this.guardChoice[f.id]??0;
      b.guards.textContent=`护卫 ×${g}${g?`（$${g*GUARD_COST}）`:''}`;
      b.guards.disabled=!route||route.status!=='idle';
    });
    // 霸主终局面板
    const eg=ext.endgame,friendly=ext.factions.filter(f=>['allied','dependent','merged'].includes(f.stance)).length,
      mergedCount=ext.factions.filter(f=>f.stance==='merged').length;
    e['hegemony-progress'].textContent=`友好 ${friendly} / 5 · 已维持 ${eg.hegemonyDays} / ${eg.hegemonyRequired} 天`;
    e['wonder-status'].textContent=eg.wonder.built?'已建成 · 守夜倒计时中':eg.wonder.started?`建造中 · 第 ${Math.floor(eg.wonder.buildProgress)+1} 天`:'未开工';
    const cost=eg.wonderCost,afford=s.cash>=cost.cash&&s.camp.stock.wood>=cost.wood&&s.camp.stock.cooked>=cost.cooked;
    e['wonder-button'].disabled=!!eg.victory||eg.wonder.started||!afford;
    e['relic-status'].textContent=`${eg.relics} / ${eg.relicsTotal} · 去雪原寻找发光石碑${eg.relics?' · 日产出已生效':''}`;
    e['conquest-status'].textContent=`已吞并 ${mergedCount} / 5`;
    const rx=e['endgame-reactions'],entries=Object.entries(eg.reactions);
    rx.hidden=!eg.countdown||!entries.length;
    if(!rx.hidden)rx.textContent=`各势力表态：${entries.map(([id,r])=>`${this.factionName(id)}·${REACTION_LABELS[r]}`).join('，')}`;
    // 声望 / 补给卡组 / 祖灵大招 / 雪橇提速 / 邻营待办
    e['prestige-points'].textContent=String(ext.prestige.points);
    e['supply-status'].textContent=`声望 ${ext.prestige.points} ✦ · 下一档 ${ext.prestige.supplyCost} ✦`;
    for(const [cid,{button,card}]of Object.entries(this.supplyButtons)){
      const unlocked=!card.annex||s.prestige.unlocked.has(cid);
      button.disabled=!unlocked||ext.prestige.points<ext.prestige.supplyCost;
      button.innerHTML=`${card.name}<small>${unlocked?card.desc:`🔒 吞并${this.factionName(card.annex)}解锁`}</small>`;
    }
    for(const [id,button]of Object.entries(this.powerButtons)){
      const cost=s.prestige.powerCost(id),usedToday=id==='blizzard'&&s.powers.blizzardDay===s.nextNightDay();
      button.disabled=cost===null||ext.prestige.points<cost||usedToday;
      button.innerHTML=`${POWERS[id].name}<small>${usedToday?'下次夜袭已部署':cost===0?'首次免费':`✦${cost}`}</small>`;
    }
    const nextSpeedCost=[60,140][ext.caravanSpeedLevel];
    e['caravan-speed-button'].disabled=nextSpeedCost===undefined||s.cash<nextSpeedCost;
    e['caravan-speed-button'].textContent=nextSpeedCost===undefined?'雪橇已到最高速':`雪橇提速 Lv${ext.caravanSpeedLevel+2} · $${nextSpeedCost}`;
    const evKey=JSON.stringify(ext.pendingEvents.map(x=>x.uid));
    if(evKey!==this.lastEventKey){
      this.lastEventKey=evKey;
      const box=e['event-list'];box.replaceChildren();
      if(!ext.pendingEvents.length){
        const p=document.createElement('p');p.className='era-missing';p.textContent='今天各家安好，没有待办。';box.appendChild(p);
      }
      for(const ev of ext.pendingEvents){
        const row=document.createElement('div');row.className='event-row';
        const text=document.createElement('span');text.textContent=this.eventText(ev);
        const accept=document.createElement('button');accept.textContent='接受';
        accept.addEventListener('click',()=>{
          if(this.state.acceptEvent(ev.uid)){this.notify('已接下 · 报酬与关系入账');this.audio.play('unlock');}
          else this.notify('条件不足（仓储/现金不够，或对方已不在）');
          this.updateData();
        },{signal:this.abort.signal});
        const reject=document.createElement('button');reject.textContent='拒绝';reject.className='event-reject';
        reject.addEventListener('click',()=>{this.state.rejectEvent(ev.uid);this.notify('已回绝');this.updateData();},{signal:this.abort.signal});
        row.append(text,accept,reject);box.appendChild(row);
      }
    }
  }
  /** 邻营待办文案。 */
  eventText(ev){
    const name=this.factionName(ev.factionId);
    if(ev.type==='request')return `${name} 求援：送 ${RESOURCE[ev.resource]?.name??ev.resource} ×${ev.amount}（料仓）· 报酬 $${ev.reward}，关系 +15`;
    if(ev.type==='extort')return `${name} 勒索保护费 $${ev.amount} · 拒绝则关系下降`;
    if(ev.type==='trade-offer'&&ev.offer)return `${name} 高价收 ${RESOURCE[ev.offer.resource]?.name??ev.offer.resource} ×${ev.offer.amount} · $${ev.offer.unitPrice}/个`;
    return `${name} 来访`;
  }
  /** 势力行吞并区块的按钮动作（全部经 GameState 权威校验）。 */
  factionAction(id,k){
    const s=this.state,name=this.factionName(id);
    if(k==='visit'){this.onPause(false);this.player.moveTo(AI_CAMPS[id].gate);return;}
    if(k==='guards'){ // 护卫数循环 0→4→0（仅 UI 选择，派出时结算）
      this.guardChoice[id]=((this.guardChoice[id]??0)+1)%5;
      this.updateData();return;
    }
    const acts={
      declareWar:()=>s.declareWar(id)?`已向${name}宣战 · 围困与突袭已开放，注意报复预告`:'当前无法宣战',
      openRoute:()=>s.openRoute(id)?`与${name}的商路已开通`:(s.camp.purchases.tradePost?'需先结盟':'需先建贸易站'),
      dispatch:()=>{const g=this.guardChoice[id]??0;return s.dispatchCaravan(id,g)?`商队出发 → ${name}${g?` · 护卫 ×${g}`:''}`:'路线未开通/在途，或料仓木材不足 20';},
      sellDemand:()=>{const d=s.aiCamps.get(id)?.getDemands()[0];return s.sellToDemand(id)?`已卖给${name} · $${d.unitPrice*d.amount} 入柜，收购额度 +${d.unitPrice*d.amount}`:'对方暂无需求或仓储不足';},
      buyOffer:()=>{const o=s.aiCamps.get(id)?.getOffers()[0];return s.buyFromOffer(id)?`已买入${name}的${RESOURCE[o.resource]?.name??o.resource} ×${o.amount}`:'对方暂无报价，或现金/仓位不足';},
      siege:()=>{const on=!!s.sieges[id];return s.toggleSiege(id)?(on?`已解除对${name}的围困`:`开始围困${name} · 每日 $${SIEGE_COST}，断供自动解除`):'围困需先敌对（误伤/突袭可翻脸）';},
      tribute:()=>s.signTribute(id)?`与${name}签下朝贡契约 · 每日上缴 15% 现金`:'需围困压力 ≥ 50 且未签约',
      buyout:()=>s.buyoutFaction(id)?`收购${name}成交！`:'收购未解锁或现金不足',
      raid:()=>s.raidFaction(id)?`突袭${name}得手 · 防御削弱、停产、库存被劫`:'突袭需敌对立场，且走到对方营地门口',
      assault:()=>s.assaultFaction(id)?`对${name}发起总攻 · 交战 45 秒后进入占领倒计时`:'总攻需到门口 + 敌对 + 破冰橇车 + 对方防御 < 40',
    };
    const ok=acts[k]?.();if(ok)this.notify(ok);
    if(['openRoute','dispatch','siege','buyout','raid','assault','sellDemand','buyOffer'].includes(k)&&ok&&!ok.includes('需')&&!ok.includes('不足')&&!ok.includes('未')&&!ok.includes('暂无'))this.audio.play('unlock');
    this.updateData();
  }
  /** 胜利结算画面：路径 + 里程碑时间轴。 */
  showVictory(path){
    const e=this.elements,s=this.state;
    e['victory-title'].textContent=`雪原霸主 · ${PATH_LABELS[path]??path}之路达成`;
    e['victory-detail'].textContent=`第 ${s.dayNight.getDay()} 天 · 累计售出 ${s.stats.sold} 份 · 总收入 $${s.stats.earned} · 营地时代 ${s.ages.getEraName()} · 种子 ${s.seedCode}`;
    const box=e['victory-milestones'];box.replaceChildren();
    const entries=Object.entries(s.milestones).filter(([k])=>MILESTONE_LABELS[k]).sort((a,b)=>a[1]-b[1]);
    for(const [key,day]of entries){
      const row=document.createElement('div');row.className='milestone-row';
      const d=document.createElement('span');d.textContent=`第 ${day} 天`;
      const t=document.createElement('strong');t.textContent=MILESTONE_LABELS[key];
      row.append(d,t);box.appendChild(row);
    }
    this.openBlockingModal('victory-overlay');this.audio.play('unlock');
  }
  /** 升代完成后的地标二选一模态框；选定前不关闭。 */
  openLandmarkModal(era){
    const choices=this.state.ages.getLandmarkChoices(era);if(!choices.length)return;
    const box=this.elements['landmark-options'];box.replaceChildren();
    for(const c of choices){
      const button=document.createElement('button');button.className='landmark-option';
      const name=document.createElement('strong');name.textContent=c.name;
      const mods=document.createElement('span');mods.textContent=Object.keys(c.modifiers).map(k=>MODIFIER_LABELS[k]??k).join(' · ');
      const unlocks=document.createElement('small');unlocks.textContent=`解锁：${c.unlocks.map(u=>UNLOCK_LABELS[u]??u).join('、')}`;
      button.append(name,mods,unlocks);
      button.addEventListener('click',()=>{
        if(this.state.chooseLandmark(era,c.id)){
          this.closeBlockingModal();this.notify(`已建起 ${c.name}`);this.audio.play('unlock');this.updateData();
        }
      },{signal:this.abort.signal});
      box.appendChild(button);
    }
    this.openBlockingModal('landmark-modal');
  }
  openBlockingModal(id){
    this.modalWasPaused=!this.elements.modal.hidden;
    this.blockingModal=id;
    this.onPause(true);
    this.elements[id].hidden=false;
    this.elements[id].querySelector('button')?.focus({preventScroll:true});
  }
  closeBlockingModal(){
    if(!this.blockingModal)return;
    this.elements[this.blockingModal].hidden=true;
    this.blockingModal=null;
    this.onPause(this.modalWasPaused);
    this.restorePendingModal();
  }
  restorePendingModal(){
    if(this.state.ages.isVulnerable())return;
    for(let era=2;era<=this.state.ages.getEra();era++){
      if(this.state.ages.chosen.some(id=>this.state.ages.getLandmarkChoices(era).some(c=>c.id===id)))continue;
      this.openLandmarkModal(era);break;
    }
  }
  updateSettings(){this.elements['quality-label'].textContent=this.sceneSetup.quality==='high'?'精致':'流畅';this.elements['camera-label'].textContent=this.sceneSetup.cameraMode==='reference'?'参考视角':'45° 等距';}
  notify(message){this.elements.toast.textContent=message;this.elements.toast.hidden=false;this.toastTime=3.3;}
  updateSound(){const b=this.elements['sound-button'];b.classList.toggle('muted',!this.audio.enabled);b.textContent=this.audio.enabled?'♪':'♩';b.setAttribute('aria-label',this.audio.enabled?'关闭声音':'开启声音');}
  showPause(value){
    if(!value){this.guidedMenu=false;this.clearQuestMenu();}
    this.elements.modal.hidden=!value;document.getElementById('pause-button').setAttribute('aria-label',value?'继续':'暂停');
    if(value){this.updateData();document.getElementById('resume-button').focus();}else this.sceneSetup.renderer.domElement.focus({preventScroll:true});
    this.updateQuestNavigation();
  }
  tick(dt){this.cashReceiptTime=Math.max(0,this.cashReceiptTime-dt);if(!this.cashReceiptTime){this.cashReceiptAmount=0;this.elements['cash-receipt'].hidden=true;}this.time+=dt;this.toastTime-=dt;if(this.toastTime<=0)this.elements.toast.hidden=true;this.bannerTime-=dt;if(this.bannerTime<=0)this.elements['chapter-banner'].hidden=true;}
  update(dt,prompt=''){
    const e=this.elements;if(this.player.travelled>1||this.state.inventory.length||this.time>14)e['controls-hint'].hidden=true;
    // 顶部昼夜时钟：天数按事件变更刷新文案，阶段进度条逐帧推进
    const dn=this.state.dayNight,day=dn.getDay();
    if(day!==this.lastDay){this.lastDay=day;e['day-count'].textContent=`第 ${day} 天`;}
    e['daynight-icon'].textContent=dn.isNight()?'☾':'☀';
    e['daynight-fill'].style.width=(dn.getProgress()*100)+'%';
    e['daynight-fill'].parentElement.classList.toggle('night',dn.isNight());
    // 威胁预告（白天显示下一波敌袭，hover 看来源）
    const threats=this.state.dayNight.getUpcomingThreats(),nextThreat=threats[0];
    e['threat-pill'].hidden=!nextThreat||dn.isNight();
    if(nextThreat){e['threat-pill'].textContent=nextThreat.nightsAway===0?'⚠今夜':`⚠${nextThreat.nightsAway}夜`;
      e['threat-pill'].title=`${nextThreat.threat?.source??'敌袭'} · ${nextThreat.nightsAway===0?'今夜抵达':nextThreat.nightsAway+' 夜后抵达'}`;}
    // 夜袭战报条：当夜显示结算结果（背景实色，夜晚也可读）
    const rep=this.state.raidWaves.lastReport,showRep=rep&&rep.day===day&&(dn.isNight()||rep.finalAssault);
    e['raid-report'].hidden=!showRep;
    if(showRep){
      const src=rep.waves.map(w=>w.source).join('+');
      e['raid-report-text'].textContent=rep.repelled
        ?`第${rep.day}夜 · 击退来袭（${src} · 强度${rep.strength} vs 防御${rep.defense}）· 奖励 $${rep.rewardCash} + 木材${rep.rewardWood} 已入柜`
        :`第${rep.day}夜 · 防线被突破！（${src} · 强度${rep.strength} vs 防御${rep.defense}）· 库存 -${Math.round(rep.stockLossPct*100)}%`;
    }
    // 驯鹿围栏浮动操作（驻留围栏南侧时显示）
    const cor=this.interaction?.corral,showCorral=!!cor?.inside&&this.state.camp.purchases.corral;
    e['corral-actions'].hidden=!showCorral;
    if(showCorral){
      const deer=this.state.corralDeer,n=deer.length,fattest=n?Math.max(...deer.map(d=>this.state.deerValue(d))):0;
      e['slaughter-button'].disabled=!n;
      e['slaughter-button'].textContent=n?`宰杀最肥的 · 值 $${fattest}`:'围栏空空 · 等黎明';
      e['feed-button'].disabled=!n||!this.state.count('berry');
      e['feed-button'].textContent=`投喂雪莓（有 ${this.state.count('berry')} 颗）`;
    }
    // 终局公开倒计时大条幅（最后一夜提示联合夜袭）
    const cd=this.state.endgame.countdown;
    e['endgame-banner'].hidden=!cd;
    if(cd){
      e['endgame-title'].textContent=`${PATH_LABELS[cd.path]}之路 · 全图倒计时${cd.remaining<this.state.endgame.config.finalPhaseSeconds?' · 最后一夜，联合夜袭将至！':''}`;
      e['endgame-fill'].style.width=(cd.remaining/cd.total*100)+'%';
      e['endgame-count'].textContent=`${Math.ceil(cd.remaining)}s`;
    }
    // 菜单打开或倒计时进行时：低频刷新扩展面板（围困压力/占领秒数/商路状态）
    this.extTimer=(this.extTimer??0)+dt;
    if(this.extTimer>.3){this.extTimer=0;if(!e.modal.hidden||cd)this.updateExtensions();this.updateQuestGuide();}
    e['action-status'].hidden=!prompt;e['action-status'].textContent=prompt;e['cook-progress'].hidden=!this.state.cooking||(this.state.cooking.destination==='stock'&&Math.hypot(this.player.position.x,this.player.position.z)>3);
    if(this.state.cooking)e['cook-progress'].firstElementChild.style.width=(1-this.state.cooking.remaining/this.state.getCookTime())*100+'%';
    for(const {info,button}of this.labelEntries){
      const point=this.sceneSetup.project(info.position),distance=Math.hypot(info.target.x-this.player.position.x,info.target.z-this.player.position.z);
      // Most labels are contextual, never a wall of floating cards. Cost remains visible from afar.
      const wanted=info.type==='outpost'?true:['deepfish','relic'].includes(info.type)?distance<9:info.id==='rawStock'?distance<5.5&&(this.state.count('raw')>0||this.state.camp.stock.raw>0):info.id==='buy'?distance<7.0:info.id==='fish'?distance>3&&distance<8:this.time<4&&['forest','market'].includes(info.id);
      const guideTarget=this.guidance?.kind==='world'?this.guidance.target:null;
      const guided=guideTarget&&Math.hypot(info.target.x-guideTarget.x,info.target.z-guideTarget.z)<.6;
      const visible=!guided&&wanted&&(!info.show||info.show())&&point.visible&&point.y>88&&point.y<this.sceneSetup.height-170;
      button.hidden=!visible;if(visible){const half=button.offsetWidth/2+8;button.style.left=Math.max(half,Math.min(this.sceneSetup.width-half,point.x))+'px';button.style.top=point.y+'px';}
    }
    this.updateQuestNavigation();
  }
  dispose(){this.clearQuestMenu();document.getElementById('resume-button').before(this.elements['quest-menu-guide']);this.elements['quest-beacon'].hidden=true;this.elements['quest-route'].toggleAttribute('hidden',true);this.staffPanel.dispose();this.questResize.disconnect();this.abort.abort();this.unsubscribe();this.cashUnsubscribe();this.extUnsubs.forEach(fn=>fn());this.labelEntries.forEach(e=>e.button.remove());for(const {button}of Object.values(this.upgradeButtons))button.remove();for(const {item}of this.factionRows)item.remove();}
}
