import { GameManager } from './engine/GameManager.js';
try {
  const game=new GameManager(document.getElementById('viewport'));
  window.addEventListener('pagehide',()=>{ /* SaveSystem handles pagehide without breaking bfcache. */ });
  if(import.meta.hot)import.meta.hot.dispose(()=>game.dispose());
} catch(error) {
  console.error(error);document.getElementById('boot').hidden=true;
  document.getElementById('fatal').hidden=false;
  document.getElementById('fatal-detail').textContent=error instanceof Error?error.message:String(error);
}
