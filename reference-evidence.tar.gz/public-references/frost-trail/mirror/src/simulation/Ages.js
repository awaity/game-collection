/** 营地时代与地标：纯数据+纯函数，不依赖 Three.js / DOM，可用 node:test 直接测试。 */

export const MAX_ERA = 4;
export const ERA_NAMES = Object.freeze({ 1: '篝火营', 2: '木屋营', 3: '集镇营', 4: '冰城营' });

/** 升代双门槛：资源储备 + 前置建筑数量。数值可调。
 * 时代 3/4 木材门槛对齐可支配上限（料仓 180 + 燃料垫 18 + 扩容背包 60 = 258）。 */
export const ERA_REQUIREMENTS = Object.freeze({
  2: Object.freeze({ wood: 200, cash: 500, buildings: Object.freeze(['warehouse', 'belt']) }),      // 可调
  3: Object.freeze({ wood: 220, cash: 2000, buildings: Object.freeze(['tradePost', 'lampline']) }),  // 可调
  4: Object.freeze({ wood: 240, cash: 6000, buildings: Object.freeze(['stoneWall', 'watchPost']) }),// 可调
});

/** 地标二选一：每时代 2 座，各带 modifiers（加成）与 unlocks（解锁项）。数值可调。 */
export const LANDMARKS = Object.freeze({
  sawTower: Object.freeze({ era: 2, name: '伐木高塔', modifiers: Object.freeze({ forestry: 0.20 }), unlocks: Object.freeze(['fastAxe']) }),
  hunterLodge: Object.freeze({ era: 2, name: '猎人长屋', modifiers: Object.freeze({ hunting: 0.20, wolfDeterrence: 1 }), unlocks: Object.freeze(['wolfWard']) }),
  caravanStation: Object.freeze({ era: 3, name: '商队驿站', modifiers: Object.freeze({ tradeRoutes: 0.25 }), unlocks: Object.freeze(['sledgeConvoy']) }),
  watchTower: Object.freeze({ era: 3, name: '警戒哨塔', modifiers: Object.freeze({ nightDefense: 0.25 }), unlocks: Object.freeze(['alarmBell']) }),
  crystalRefinery: Object.freeze({ era: 4, name: '冰晶熔炉', modifiers: Object.freeze({ cooking: 0.30 }), unlocks: Object.freeze(['fastGrill']) }),
  emberCitadel: Object.freeze({ era: 4, name: '炉火议事厅', modifiers: Object.freeze({ morale: 0.20, prestige: 0.25 }), unlocks: Object.freeze(['hegemonBanner']) }),
});

/** 施工期长度（游戏日）与脆弱窗口修饰符。可调。 */
export const UPGRADE_DAYS = 1;                                                        // 可调
export const VULNERABILITY_MODIFIERS = Object.freeze({ productionHalted: true, raidIntensity: 1.5 }); // 可调

const buildingCount = (state, id) => {
  const b = state?.buildings;
  if (Array.isArray(b)) return b.filter(x => x === id).length;
  if (b && typeof b === 'object') return Number.isFinite(b[id]) ? Math.max(0, Math.floor(b[id])) : 0;
  return 0;
};

/** 权威时代状态：升代门槛、施工脆弱窗口、地标二选一与吞并夺回。 */
export class Ages {
  /** @param emitter 可选事件发射器（emit(type, payload)），缺省则静默 */
  constructor({ emitter = null } = {}) {
    this.emitter = emitter;
    this.era = 1;
    this.upgrading = null;   // { targetEra, remaining }（remaining 单位：游戏日）
    this.chosen = [];        // 已建地标 id
    this.lost = {};          // 落选地标 id -> 持有它的敌营 factionId
    this.recovered = [];     // 吞并后夺回的地标 id
  }
  emit(type, payload) { this.emitter?.emit(type, payload); }

  getEra() { return this.era; }
  getEraName() { return ERA_NAMES[this.era]; }
  isVulnerable() { return this.upgrading !== null; }
  /** 施工期修饰符：加工停产 + 夜袭强度上调，供生产/夜哨系统消费。 */
  getVulnerabilityModifiers() {
    return this.upgrading ? { ...VULNERABILITY_MODIFIERS } : { productionHalted: false, raidIntensity: 1 };
  }

  /** 门槛判定，返回 { ok, missing:[{kind,id,need,have}] } 供 UI 显示缺什么。 */
  canUpgrade(state) {
    const missing = [];
    if (this.era >= MAX_ERA || this.upgrading) return { ok: false, missing };
    const req = ERA_REQUIREMENTS[this.era + 1];
    for (const res of ['wood', 'cash']) {
      const have = res === 'cash' ? (Number.isFinite(state?.cash) ? state.cash : 0)
        : (Number.isFinite(state?.camp?.stock?.wood) ? state.camp.stock.wood : 0);
      if (have < req[res]) missing.push({ kind: 'resource', id: res, need: req[res], have });
    }
    for (const id of req.buildings) {
      const have = buildingCount(state, id);
      if (have < 1) missing.push({ kind: 'building', id, need: 1, have });
    }
    return { ok: missing.length === 0, missing };
  }

  /** 满足门槛后进入施工期；返回 false 表示不能开工。 */
  startUpgrade(state) {
    if (!this.canUpgrade(state).ok) return false;
    this.upgrading = { targetEra: this.era + 1, remaining: UPGRADE_DAYS };
    this.emit('era-upgrade-start', { era: this.upgrading.targetEra });
    return true;
  }
  /** 推进施工进度（单位：游戏日）；本调用内完工则返回 true。 */
  advance(days = 1) {
    if (!this.upgrading || !Number.isFinite(days) || days <= 0) return false;
    this.upgrading.remaining -= days;
    if (this.upgrading.remaining > 1e-8) return false;
    this.completeUpgrade();
    return true;
  }
  /** 结算升代；未在施工返回 false。 */
  completeUpgrade() {
    if (!this.upgrading) return false;
    this.era = this.upgrading.targetEra;
    this.upgrading = null;
    this.emit('era-upgraded', { era: this.era });
    return true;
  }

  /** 某时代的 2 座候选地标（含 id 与完整定义）。 */
  getLandmarkChoices(era) {
    return Object.entries(LANDMARKS).filter(([, l]) => l.era === era)
      .map(([id, l]) => ({ id, ...l }));
  }
  /** 已拥有（自建+夺回）的地标 id 列表。 */
  getOwnedLandmarks() { return [...this.chosen, ...this.recovered]; }
  /** 汇总已拥有地标的修饰符（同名相加），供各系统消费。 */
  getActiveModifiers() {
    const total = {};
    for (const id of this.getOwnedLandmarks())
      for (const [k, v] of Object.entries(LANDMARKS[id].modifiers)) total[k] = (total[k] ?? 0) + v;
    return total;
  }
  /** 已拥有地标提供的解锁项列表。 */
  getUnlocks() { return this.getOwnedLandmarks().flatMap(id => LANDMARKS[id].unlocks); }

  /** 升代后二选一：选定 choice，另一座归敌营 factionId（供吞并夺回）。 */
  chooseLandmark(era, choice, factionId = null) {
    if (!Number.isInteger(era) || era < 2 || era > this.era || this.upgrading) return false;
    const candidates = this.getLandmarkChoices(era).map(c => c.id);
    if (!candidates.includes(choice) || this.chosen.some(id => LANDMARKS[id].era === era)) return false;
    this.chosen.push(choice);
    const other = candidates.find(id => id !== choice);
    this.lost[other] = factionId;
    this.emit('landmark-chosen', { id: choice, era });
    this.emit('landmark-lost', { id: other, factionId });
    return true;
  }
  /** 吞并敌营后夺回其持有的落选地标，并入我方加成。 */
  annexRecoverLandmark(landmarkId) {
    if (!Object.hasOwn(this.lost, landmarkId)) return false;
    const factionId = this.lost[landmarkId];
    delete this.lost[landmarkId];
    this.recovered.push(landmarkId);
    this.emit('landmark-recovered', { id: landmarkId, factionId });
    return true;
  }

  snapshot() {
    return { version: 1, era: this.era,
      upgrading: this.upgrading ? { ...this.upgrading } : null,
      chosen: [...this.chosen], lost: { ...this.lost }, recovered: [...this.recovered] };
  }
  restore(data) {
    if (!data || typeof data !== 'object' || data.version !== 1) return false;
    const era = Number.isInteger(data.era) && data.era >= 1 && data.era <= MAX_ERA ? data.era : 1;
    const known = id => typeof id === 'string' && Object.hasOwn(LANDMARKS, id);
    this.era = era;
    this.chosen = (Array.isArray(data.chosen) ? data.chosen : []).filter(known)
      .filter((id, i, arr) => arr.indexOf(id) === i && LANDMARKS[id].era <= era);
    this.recovered = (Array.isArray(data.recovered) ? data.recovered : []).filter(known)
      .filter((id, i, arr) => arr.indexOf(id) === i && !this.chosen.includes(id) && LANDMARKS[id].era <= era);
    this.lost = {};
    for (const [id, fid] of Object.entries(data.lost && typeof data.lost === 'object' ? data.lost : {}))
      if (known(id) && LANDMARKS[id].era <= era && !this.chosen.includes(id) && !this.recovered.includes(id))
        this.lost[id] = typeof fid === 'string' ? fid : null;
    this.upgrading = null;
    const up = data.upgrading;
    if (up && Number.isInteger(up.targetEra) && up.targetEra === era + 1 && era < MAX_ERA)
      this.upgrading = { targetEra: up.targetEra,
        remaining: Number.isFinite(up.remaining) ? Math.max(0.001, Math.min(UPGRADE_DAYS, up.remaining)) : UPGRADE_DAYS };
    return true;
  }
}
