import * as THREE from 'three';
import { BALANCE } from '../simulation/Balance.js';
import { damp } from '../utils/math.js';

/** Camera-relative WASD, ground raycasting, obstacle-aware click paths and slerp. */
export class PlayerController {
  constructor({ root, visual, state, camera, canvas, input, collision }) {
    Object.assign(this, { root, visual, state, camera, canvas, input, collision });
    this.position = new THREE.Vector3(state.position.x, 0, state.position.z);
    this.velocity = new THREE.Vector3(); this.direction = new THREE.Vector3();
    this.targetRotation = new THREE.Quaternion(); this.up = new THREE.Vector3(0,1,0);
    this.raycaster = new THREE.Raycaster(); this.pointer = new THREE.Vector2();
    this.ground = new THREE.Plane(this.up, 0); this.hit = new THREE.Vector3();
    this.axes = {x:0,y:0}; this.path = []; this.walkTime = 0; this.action = 0;
    this.moving = false; this.travelled = 0; this.aimTime = 0;
    this.navigationGoal=null;this.blockedTime=0;this.replans=0;
    const safe = collision.nearestFree(this.position) ?? collision.nearestFree({x:-2.2,z:2.1}); if (safe) this.position.set(safe.x, 0, safe.z);
    this.root.position.copy(this.position);this.state.position={x:this.position.x,z:this.position.z}; this.marker = null;
  }
  moveTo(point) {
    this.path = this.collision.findPath(this.position, point);
    this.navigationGoal=this.path.length?{...this.path.at(-1)}:null;this.blockedTime=0;this.replans=0;
    this.onDestination?.(this.navigationGoal);
    return this.path.length > 0;
  }
  click(clientX, clientY) {
    const rect = this.canvas.getBoundingClientRect();
    this.pointer.set((clientX-rect.left)/rect.width*2-1, -(clientY-rect.top)/rect.height*2+1);
    this.camera.updateMatrixWorld(); this.raycaster.setFromCamera(this.pointer, this.camera);
    if (this.raycaster.ray.intersectPlane(this.ground, this.hit)) return this.moveTo(this.hit);
    return false;
  }
  stop() { this.navigationGoal=null;this.blockedTime=0;this.replans=0;this.path.length=0; this.velocity.set(0,0,0); this.moving=false; this.onDestination?.(null); }
  getCashPickupPosition(out=new THREE.Vector3()) {
    this.root.updateWorldMatrix(true,false);return this.root.localToWorld(out.set(.30,1.02,.10));
  }
  swing() { this.action = 1; }
  aim(x,z) { this.aimTime=.15; this.targetRotation.setFromAxisAngle(this.up,Math.atan2(x-this.position.x,z-this.position.z)); }
  update(dt) {
    if (!Number.isFinite(dt) || dt <= 0) return;
    dt = Math.min(dt, 0.05); this.input.getAxes(this.axes);
    const manual = Math.hypot(this.axes.x, this.axes.y) > 0.08;
    this.direction.set(0,0,0);
    if (manual) {
      this.path.length=0;this.navigationGoal=null;this.blockedTime=0;this.replans=0; this.onDestination?.(null);
      // Derive the basis from the orthographic camera, not a hard-coded 45° assumption.
      const yaw = this.camera.userData.azimuth ?? Math.PI / 4;
      const c = Math.cos(yaw), s = Math.sin(yaw);
      this.direction.set(this.axes.x*c + this.axes.y*s, 0, -this.axes.x*s + this.axes.y*c);
    } else if (this.path.length) {
      const next=this.path[0]; this.direction.set(next.x-this.position.x,0,next.z-this.position.z);
      const distance=this.direction.length();
      if(distance<0.12) {this.path.shift();this.direction.set(0,0,0);if(!this.path.length)this.onDestination?.(null);}
      else this.direction.multiplyScalar(Math.min(1, distance/(BALANCE.speed*dt))/distance);
    }
    const response=damp(this.direction.lengthSq()?18:24,dt);
    this.velocity.lerp(this.direction.multiplyScalar(BALANCE.speed),response);
    if(this.velocity.lengthSq()<0.001)this.velocity.set(0,0,0);
    const x=this.position.x,z=this.position.z;
    this.collision.move(this.position,this.velocity.x*dt,this.velocity.z*dt);
    const travelled=Math.hypot(this.position.x-x,this.position.z-z);
    this.moving=travelled>0.0005;this.travelled+=travelled;
    // Regenerated trees can invalidate a previously clear click route. Retry a bounded
    // number of times rather than continuing to walk into a wall forever.
    if(!manual&&this.path.length&&this.navigationGoal){
      const node=this.path[0],before=Math.hypot(node.x-x,node.z-z),after=Math.hypot(node.x-this.position.x,node.z-this.position.z);
      this.blockedTime=before-after<dt*.10?this.blockedTime+dt:0;
      if(this.blockedTime>=.45){
        this.blockedTime=0;this.replans++;
        const route=this.replans<=3?this.collision.findPath(this.position,this.navigationGoal):[];
        if(route.length){this.path=route;this.velocity.set(0,0,0);}else{this.stop();this.onBlocked?.();}
      }
    }else if(!this.path.length)this.navigationGoal=null;
    if(this.moving) {
      this.targetRotation.setFromAxisAngle(this.up,Math.atan2(this.velocity.x,this.velocity.z));
      this.root.quaternion.slerp(this.targetRotation,damp(14,dt));
      this.walkTime+=dt*12;
    }
    if(!this.moving&&(this.action>0||this.aimTime>0))this.root.quaternion.slerp(this.targetRotation,damp(14,dt));
    this.root.position.copy(this.position);
    this.state.position.x=this.position.x;this.state.position.z=this.position.z;
    this.action=Math.max(0,this.action-dt*3.8);this.aimTime=Math.max(0,this.aimTime-dt);
    const stride=this.moving?Math.sin(this.walkTime)*0.6:0;
    const rig=this.visual.userData.rig;
    if(rig){rig.legs[0].rotation.x=stride;rig.legs[1].rotation.x=-stride;
      rig.arms[0].rotation.x=-stride*0.7;
      rig.arms[1].rotation.x=this.action>0 ? -Math.sin(this.action*Math.PI)*2.1 : stride*0.7;
      rig.tool.visible=this.action>0&&!this.fishing;
      if(rig.rod)rig.rod.visible=!!this.fishing;
      if(this.fishing)rig.arms[1].rotation.x=-.70+Math.sin(this.walkTime)*.05;
    }
    this.visual.position.y=this.moving?Math.abs(Math.sin(this.walkTime))*0.055:Math.sin(this.walkTime)*0.012;
  }
  dispose() { this.stop(); }
}
