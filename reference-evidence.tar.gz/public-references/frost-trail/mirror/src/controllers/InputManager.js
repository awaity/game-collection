/** Single-owner floating joystick + keyboard input. Other touches cannot cancel it. */
export class InputManager {
  constructor(canvas, { onTap, onPause, onZoom, onInteract, isEnabled = () => true } = {}) {
    Object.assign(this, { canvas, onTap, onPause, onZoom, onInteract, isEnabled });
    this.keys = new Set(); this.axis = { x: 0, y: 0 }; this.pointer = null;
    this.abort = new AbortController(); const opts = { signal: this.abort.signal };
    this.joystick = document.querySelector('#joystick'); this.knob = document.querySelector('#joystick-knob');
    window.addEventListener('keydown', e => {
      if (/INPUT|TEXTAREA|SELECT/.test(e.target?.tagName) || e.target?.isContentEditable) return;
      if (e.code === 'Escape' && !e.repeat) { this.onPause?.(); return; }
      if (!this.isEnabled()) return;
      if (['KeyW','KeyA','KeyS','KeyD','ArrowUp','ArrowDown','ArrowLeft','ArrowRight','Space'].includes(e.code)) e.preventDefault();
      if (e.code === 'KeyE' && !e.repeat) this.onInteract?.();
      this.keys.add(e.code);
    }, opts);
    window.addEventListener('keyup', e => this.keys.delete(e.code), opts);
    window.addEventListener('blur', () => this.reset(), opts);
    document.addEventListener('visibilitychange', () => { if (document.hidden) this.reset(); }, opts);
    canvas.addEventListener('pointerdown', e => {
      if (!this.isEnabled() || e.button !== 0 || this.pointer || e.isPrimary === false) return;
      canvas.focus({ preventScroll: true });
      this.pointer = { id: e.pointerId, x: e.clientX, y: e.clientY, drag: false };
      try { canvas.setPointerCapture(e.pointerId); } catch { /* Synthetic input / canceled contact. */ }
    }, opts);
    canvas.addEventListener('pointermove', e => {
      const p = this.pointer; if (!p || p.id !== e.pointerId || !this.isEnabled()) return;
      const dx = e.clientX - p.x, dy = e.clientY - p.y;
      if (Math.hypot(dx, dy) > 9) p.drag = true;
      if (p.drag) {
        const length = Math.max(48, Math.hypot(dx, dy));
        this.axis.x = dx / length; this.axis.y = dy / length;
        if (this.joystick) {
          this.joystick.hidden = false; this.joystick.style.left = p.x + 'px'; this.joystick.style.top = p.y + 'px';
        }
        if (this.knob) this.knob.style.transform = `translate(${this.axis.x * 34}px,${this.axis.y * 34}px)`;
      }
    }, opts);
    canvas.addEventListener('pointerup', e => {
      if (this.pointer?.id !== e.pointerId) return;
      if (!this.pointer.drag && this.isEnabled()) this.onTap?.(e.clientX, e.clientY);
      this.release();
    }, opts);
    for (const name of ['pointercancel', 'lostpointercapture']) canvas.addEventListener(name, e => {
      if (this.pointer?.id === e.pointerId) this.release();
    }, opts);
    canvas.addEventListener('contextmenu', e => e.preventDefault(), opts);
    canvas.addEventListener('wheel', e => {
      if (!this.isEnabled()) return;
      e.preventDefault(); this.onZoom?.(Math.sign(e.deltaY));
    }, { ...opts, passive: false });
  }
  getAxes(out = { x: 0, y: 0 }) {
    if (!this.isEnabled()) { out.x = out.y = 0; return out; }
    const k = this.keys;
    out.x = (k.has('KeyD') || k.has('ArrowRight') ? 1 : 0) - (k.has('KeyA') || k.has('ArrowLeft') ? 1 : 0) + this.axis.x;
    out.y = (k.has('KeyS') || k.has('ArrowDown') ? 1 : 0) - (k.has('KeyW') || k.has('ArrowUp') ? 1 : 0) + this.axis.y;
    const length = Math.hypot(out.x, out.y); if (length > 1) { out.x /= length; out.y /= length; }
    return out;
  }
  release() {
    const id = this.pointer?.id; this.pointer = null; // Clear before lostpointercapture can re-enter.
    this.axis.x = this.axis.y = 0;
    if (this.joystick) this.joystick.hidden = true;
    try { if (id !== undefined && this.canvas.hasPointerCapture?.(id)) this.canvas.releasePointerCapture(id); } catch { /* Already released. */ }
  }
  reset() { this.keys.clear(); this.release(); }
  dispose() { this.abort.abort(); this.reset(); }
}
