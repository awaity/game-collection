export const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
export const damp = (rate, dt) => 1 - Math.exp(-rate * Math.max(0, dt));
export const easeOutCubic = t => 1 - (1 - clamp(t, 0, 1)) ** 3;
export const easeInOutCubic = t => t < 0.5 ? 4 * t ** 3 : 1 - (-2 * t + 2) ** 3 / 2;
export const distance = (a, b) => Math.hypot(a.x - b.x, a.z - b.z);
export function seededRandom(seed = 20260916) {
  return () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0;
    let t = Math.imul(seed ^ seed >>> 15, 1 | seed);
    t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t;
    return ((t ^ t >>> 14) >>> 0) / 4294967296;
  };
}
