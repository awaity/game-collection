import * as THREE from 'three';
import { damp } from '../utils/math.js';

/** Orthographic-only renderer. Reference camera is an estimate from screen axes,
 * not a claim that the source game's camera parameters were recovered. */
export class SceneSetup {
  constructor(container, { quality = 'high', cameraMode = 'reference' } = {}) {
    this.container = container; this.quality = quality; this.cameraMode = cameraMode;
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0xe9edf4).convertSRGBToLinear();
    this.scene.fog = new THREE.Fog(new THREE.Color(0xe9edf4).convertSRGBToLinear(), 70, 150);
    this.renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
    // r140 is vendored. Do not mix in the r152+ outputColorSpace API without migrating.
    this.renderer.outputEncoding = THREE.sRGBEncoding;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping; this.renderer.toneMappingExposure = .92;
    this.renderer.shadowMap.enabled = true; this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.domElement.setAttribute('aria-label', '雪原小营三维游戏画面');
    this.renderer.domElement.tabIndex = 0; container.appendChild(this.renderer.domElement);
    this.camera = new THREE.OrthographicCamera(-10, 10, 10, -10, .1, 180);
    this.offset = new THREE.Vector3(); this.focus = new THREE.Vector3(-1.5, 0, .8);
    this.desired = this.focus.clone(); this.zoomFactor = 1; this.stackHeight = 0; this.framedHeight = 0;
    this.hemi = new THREE.HemisphereLight(0xdcecff, 0xb0b3c6, .65);
    this.fill = new THREE.AmbientLight(0xfff8ee, .08);
    this.sun = new THREE.DirectionalLight(0xffefdb, 1.12);
    this.sun.position.set(-9, 35, 10); this.sun.castShadow = true;
    Object.assign(this.sun.shadow.camera, { left: -23, right: 23, top: 23, bottom: -23, near: 1, far: 85 });
    this.sun.shadow.bias = -.0001; this.sun.shadow.normalBias = .025;
    this.sun.shadow.mapSize.set(2048, 2048);
    this.scene.add(this.hemi, this.fill, this.sun, this.sun.target);
    // 昼夜光照基准（可调）：强度 = 基准 × DayNight.getLighting() 归一化系数；首次调用直接落定避免跳变
    this.lightBase = { sun: this.sun.intensity, hemi: this.hemi.intensity };
    this.lighting = null;
    this.abort = new AbortController();
    this.observer = new ResizeObserver(() => this.resize()); this.observer.observe(container);
    window.addEventListener('resize', () => this.resize(), { signal: this.abort.signal });
    this.renderer.domElement.addEventListener('webglcontextlost', event => {
      event.preventDefault(); this.onContextLost?.();
    }, { signal: this.abort.signal });
    this.renderer.domElement.addEventListener('webglcontextrestored', () => {
      this.renderer.shadowMap.needsUpdate = true; this.onContextRestored?.();
    }, { signal: this.abort.signal });
    this.setCameraMode(cameraMode); this.setQuality(quality); this.follow(this.focus, 1, true);
  }
  setCameraMode(mode) {
    this.cameraMode = mode === 'classic' ? 'classic' : 'reference';
    const azimuth = THREE.MathUtils.degToRad(this.cameraMode === 'classic' ? 45 : 22);
    const elevation = THREE.MathUtils.degToRad(this.cameraMode === 'classic' ? 35.26438968 : 48);
    const distance = 44;
    this.offset.set(Math.sin(azimuth) * Math.cos(elevation) * distance,
      Math.sin(elevation) * distance, Math.cos(azimuth) * Math.cos(elevation) * distance);
    this.azimuth = azimuth; this.camera.userData.azimuth = azimuth;
    if (this.width) this.follow(this.focus, 1, true);
  }
  resize() {
    this.width = Math.max(1, this.container.clientWidth); this.height = Math.max(1, this.container.clientHeight);
    this.projection(); this.renderer.setSize(this.width, this.height, false); this.onResize?.();
  }
  projection() {
    const aspect = this.width / this.height;
    const baseHeight = aspect < .8 ? 24 : aspect < 1.4 ? 23 : 21.5;
    this.viewHeight = (baseHeight + Math.max(0, this.framedHeight - 7) * .60) / this.zoomFactor;
    const half = this.viewHeight / 2;
    Object.assign(this.camera, { left: -half * aspect, right: half * aspect, top: half, bottom: -half });
    this.camera.updateProjectionMatrix();
  }
  setQuality(quality) {
    this.quality = quality === 'low' ? 'low' : 'high';
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, this.quality === 'high' ? 2 : 1.25));
    const size = this.quality === 'high' ? 2048 : 1024;
    if (this.sun.shadow.mapSize.x !== size) {
      this.sun.shadow.mapSize.set(size, size); this.sun.shadow.map?.dispose(); this.sun.shadow.map = null;
    }
    this.resize();
  }
  setZoom(value) { this.zoomFactor = THREE.MathUtils.clamp(value, .75, 1.30); this.projection(); }
  follow(position, dt, snap = false) {
    const response = snap ? 1 : damp(3.5, dt);
    this.framedHeight = THREE.MathUtils.lerp(this.framedHeight, this.stackHeight, response);
    this.desired.set(position.x, Math.min(3.8, Math.max(0, this.framedHeight - 3) * .23), position.z);
    this.focus.lerp(this.desired, response);
    this.camera.position.copy(this.focus).add(this.offset); this.camera.lookAt(this.focus); this.camera.updateMatrixWorld();
    if (this.width) this.projection();
  }
  project(world, out = new THREE.Vector3()) {
    out.copy(world).project(this.camera);
    return { x: (out.x * .5 + .5) * this.width, y: (-out.y * .5 + .5) * this.height,
      visible: Math.abs(out.x) < 1.15 && Math.abs(out.y) < 1.15 && out.z < 1 };
  }
  /** 每帧消费 DayNight.getLighting()：平滑驱动半球光/平行光强度与天色（雾随天色）。
   * 正交相机与阴影配置不变；lampGlow 预留给灯网，本轮只读光照/天空。 */
  applyLighting(target, dt = 1 / 60) {
    if (!target) return;
    if (!this.lighting) this.lighting = { sunIntensity: target.sunIntensity, ambientIntensity: target.ambientIntensity, skyColor: [...target.skyColor] };
    const response = damp(4.5, dt), lerp = (a, b) => a + (b - a) * response, cur = this.lighting;
    cur.sunIntensity = lerp(cur.sunIntensity, target.sunIntensity);
    cur.ambientIntensity = lerp(cur.ambientIntensity, target.ambientIntensity);
    for (let i = 0; i < 3; i++) cur.skyColor[i] = lerp(cur.skyColor[i], target.skyColor[i]);
    this.sun.intensity = this.lightBase.sun * cur.sunIntensity;
    this.hemi.intensity = this.lightBase.hemi * cur.ambientIntensity / 0.65; // 0.65 = 白昼基准环境光
    const sky = this.scene.background.setRGB(cur.skyColor[0], cur.skyColor[1], cur.skyColor[2]);
    this.scene.fog.color.copy(sky);
  }
  render() { this.renderer.render(this.scene, this.camera); }
  dispose() { this.abort.abort(); this.observer.disconnect(); this.renderer.dispose(); this.renderer.domElement.remove(); }
}
