import * as THREE from 'three';
import { SceneSetup } from './SceneSetup.js';
import { AssetFactory } from '../assets/AssetFactory.js';
import { PlayerController } from '../controllers/PlayerController.js';
import { InputManager } from '../controllers/InputManager.js';
import { readSettings } from '../systems/UserSettings.js';
import { CampProduction } from '../simulation/CampProduction.js';
import { CounterStaff, snapshotCounterStaff } from '../simulation/CounterStaff.js';
import { CounterStaffView } from '../world/CounterStaffView.js';
import { WorkerSystem } from '../systems/WorkerSystem.js';
import { LogisticsSystem } from '../systems/LogisticsSystem.js';
import { InventoryStack } from '../inventory/InventoryStack.js';
import { GameState } from '../simulation/GameState.js';
import { CollisionWorld } from '../world/CollisionWorld.js';
import { MapManager } from '../world/MapManager.js';
import { CaravanView } from '../world/CaravanView.js';
import { ResourceSystem } from '../systems/ResourceSystem.js';
import { CrowdSystem } from '../systems/CrowdSystem.js';
import { EffectsSystem } from '../systems/EffectsSystem.js';
import { InteractionSystem } from '../systems/InteractionSystem.js';
import { QuestSystem } from '../systems/QuestSystem.js';
import { AudioSystem } from '../systems/AudioSystem.js';
import { SaveSystem } from '../systems/SaveSystem.js';
import { HUD } from '../ui/HUD.js';

/** Owns lifetime and ordering; the 60 Hz simulation never depends on real-time timers. */
export class GameManager {
  constructor(container) {
    this.disposed=false;this.paused=false;this.contextLost=false;this.hidden=document.hidden;
    this.testFrozen=false;this.accumulator=0;this.time=0;this.last=performance.now();this.footDistance=0;
    this.abort=new AbortController();this.params=new URLSearchParams(location.search);
    let storage;try{storage=window.localStorage;}catch{storage={getItem:()=>null,setItem:()=>{throw new Error('Storage unavailable');},removeItem:()=>{}};}
    this.state=new GameState(this.params.has('fresh')?{}:SaveSystem.load(storage));
    this.storage=storage;
    const settings=readSettings(storage);
    this.sceneSetup=new SceneSetup(container,{quality:settings.quality==='low'?'low':'high',cameraMode:settings.cameraMode==='classic'?'classic':'reference'});this.factory=new AssetFactory();this.collision=new CollisionWorld();this.audio=new AudioSystem();
    const {scene,camera,renderer}=this.sceneSetup;
    this.map=new MapManager({scene,factory:this.factory,collision:this.collision,state:this.state});
    const {root,visual}=this.factory.createPlayer();scene.add(root);
    this.input=new InputManager(renderer.domElement,{isEnabled:()=>!this.paused&&!this.hidden&&!this.contextLost&&!this.disposed,onTap:(x,y)=>{if(!this.paused&&!this.contextLost){this.audio.unlock();this.player.click(x,y);}},onPause:()=>this.setPaused(!this.paused),onZoom:direction=>{if(!this.paused)this.sceneSetup.setZoom(this.sceneSetup.zoomFactor-direction*0.05);}});
    this.player=new PlayerController({root,visual,state:this.state,camera,canvas:renderer.domElement,input:this.input,collision:this.collision});
    this.inventory=new InventoryStack({playerRoot:root,state:this.state,factory:this.factory});
    const shadow=this.factory.blob(1.1,0.90);root.add(shadow);
    const ring=new THREE.Mesh(this.factory.geo('player-ring',()=>new THREE.RingGeometry(0.38,0.415,32)),this.factory.basic(0xf9ffff,{transparent:true,opacity:0.84,depthWrite:false}));ring.rotation.x=-Math.PI/2;ring.position.y=0.042;root.add(ring);
    this.effects=new EffectsSystem({scene,factory:this.factory});this.player.onDestination=point=>this.effects.destination(point);
    const notify=message=>this.hud?.notify(message);
    this.player.onBlocked=()=>notify('前方道路被挡住了，请换个位置');
    this.resources=new ResourceSystem({scene,factory:this.factory,state:this.state,player:this.player,inventory:this.inventory,collision:this.collision,effects:this.effects,audio:this.audio});
    this.workers=new WorkerSystem({scene,factory:this.factory,state:this.state,collision:this.collision,resources:this.resources,effects:this.effects,audio:this.audio});
    this.production=new CampProduction(this.state);
    this.counterStaff=new CounterStaff(this.state,this.collision);
    this.counterStaffView=new CounterStaffView({scene,factory:this.factory,state:this.state,effects:this.effects,player:this.player});
    this.logistics=new LogisticsSystem({scene,factory:this.factory,state:this.state});
    this.crowd=new CrowdSystem({scene,factory:this.factory,state:this.state});
    this.caravanView=new CaravanView({scene,factory:this.factory,state:this.state});
    this.interaction=new InteractionSystem({state:this.state,player:this.player,inventory:this.inventory,map:this.map,effects:this.effects,audio:this.audio,notify});
    this.quest=new QuestSystem(this.state,notify,this.audio);
    this.hud=new HUD({state:this.state,sceneSetup:this.sceneSetup,map:this.map,quest:this.quest,player:this.player,audio:this.audio,interaction:this.interaction,onPause:value=>this.setPaused(value??!this.paused),onReset:()=>{if(this.save.clear())location.reload();else this.hud.notify('未能清除本地进度，请检查浏览器存储权限');},onSettings:()=>{try{storage.setItem('frost-trail-settings',JSON.stringify({quality:this.sceneSetup.quality,cameraMode:this.sceneSetup.cameraMode,sound:this.audio.enabled}));}catch{}}});
    this.save=new SaveSystem(this.state,notify,storage);
    if(settings.sound===false){this.audio.setEnabled(false);this.hud.updateSound();}
    this.sceneSetup.onResize=()=>{if(!this.contextLost&&(this.paused||this.testFrozen))this.render(0);};
    this.sceneSetup.follow(this.player.position,1,true);
    this.sceneSetup.onContextLost=()=>{this.contextLost=true;this.audio.setPaused(true);this.input.reset();this.player.stop();document.getElementById('context-message').hidden=false;this.save.save();};
    this.sceneSetup.onContextRestored=()=>{this.contextLost=false;this.audio.setPaused(this.paused||this.hidden);this.last=performance.now();this.accumulator=0;document.getElementById('context-message').hidden=true;this.hud.notify('图形已恢复，进度保留');};
    const opts={signal:this.abort.signal};
    window.addEventListener('pointerdown',()=>this.audio.unlock(),opts);
    window.addEventListener('keydown',()=>this.audio.unlock(),opts);
    document.addEventListener('visibilitychange',()=>{this.hidden=document.hidden;this.input.reset();this.player.stop();this.accumulator=0;this.last=performance.now();this.audio.setPaused(this.hidden||this.paused||this.contextLost);if(this.hidden)this.save.save();},opts);
    window.addEventListener('blur',()=>{this.input.reset();this.player.stop();},opts);
    window.addEventListener('pagehide',()=>this.save.save(),opts);
    this.render(0);document.getElementById('boot').hidden=true;
    if(this.params.get('debug')==='1')this.installDebug();
    window.render_game_to_text=()=>this.renderGameToText();
    this.hud.restorePendingModal();
    this.frame=this.frame.bind(this);this.raf=requestAnimationFrame(this.frame);
  }
  simulate(dt){
    this.time+=dt;this.state.elapsed+=dt;
    // 扩展模块先行：昼夜时钟推进（跨天事件联动市场回归/关系衰减/升代施工），AI 营地账本随后
    this.state.dayNight.update(dt);this.state.aiCamps.update(dt);
    // 吞并三路径 / 商队在途 / 围困维持 / 终局倒计时（全部确定性，__FROST__.advance 可复现）
    this.state.annexation.update(dt);this.state.caravans.update(dt);this.state.tickSieges(dt);this.state.endgame.update(dt);
    const oldDistance=this.player.travelled;this.player.update(dt);
    this.footDistance+=this.player.travelled-oldDistance;
    if(this.footDistance>0.26){this.footDistance=0;this.effects.footprint(this.player.position,this.player.root.rotation.y,this.effects.footCursor%2?1:-1);}
    this.resources.update(dt);this.workers.update(dt);this.interaction.update(dt);
    this.production.update(dt,{manualPriority:this.interaction.fire.inside&&(this.state.count('raw')>0||this.state.count('fish')>0)});
    this.counterStaff.update(dt);this.counterStaffView.update(dt);
    this.quest.update();this.hud.tick(dt);
    this.inventory.update(dt,this.player.velocity);this.logistics.update(dt);this.map.update(dt,this.time);this.crowd.update(dt);this.caravanView.update();this.effects.update(dt);this.save.update(dt);
  }
  render(dt){
    this.sceneSetup.stackHeight=this.inventory.height+1.0;
    this.sceneSetup.follow(this.player.position,dt);
    this.sceneSetup.applyLighting(this.state.dayNight.getLighting(),dt);
    this.sceneSetup.render();this.hud.update(dt,this.interaction.prompt||this.resources.prompt);
  }
  frame(now){
    if(this.disposed)return;
    const dt=Math.min(0.08,Math.max(0,(now-this.last)/1000));this.last=now;
    if(!this.paused&&!this.hidden&&!this.contextLost&&!this.testFrozen){
      this.accumulator+=dt;let steps=0;
      while(this.accumulator>=1/60&&steps<5){this.simulate(1/60);this.accumulator-=1/60;steps++;}
      if(steps===5)this.accumulator=0;
      this.render(dt);
    }
    this.raf=requestAnimationFrame(this.frame);
  }
  setPaused(value){
    if(!value&&this.hud.blockingModal)return;
    this.paused=!!value;this.input.reset();this.player.stop();this.accumulator=0;this.last=performance.now();
    this.hud.showPause(this.paused);this.audio.setPaused(this.paused||this.hidden||this.contextLost);if(this.paused)this.save.save();
  }
  renderGameToText(){
    const s=this.state,p=this.player.position,guide=this.quest.guidance;
    return JSON.stringify({coordinates:'XZ ground plane; +x east, +z south; movement is camera relative',
      mode:this.hud.blockingModal??(this.paused?'paused':'playing'),elapsed:s.elapsed,
      player:{x:p.x,z:p.z,moving:this.player.moving,path:this.player.path},
      cash:s.cash,counterCash:s.counterCash,inventory:s.inventory.map(i=>i.type),capacity:s.capacity,
      quest:{index:s.quest,title:this.quest.current.title,progress:this.quest.progress,target:guide.target??null,
        guidance:guide,navigating:!!this.hud.navigationGuide},
      prompt:this.interaction.prompt||this.resources.prompt,stock:{...s.camp.stock},cooking:s.cooking,
      staff:snapshotCounterStaff(s.camp.staff),
      world:s.world.nodes.filter(n=>Math.hypot(n.x-p.x,n.z-p.z)<9).map(n=>({id:n.id,x:n.x,z:n.z,hp:n.hp,active:n.active})),
      ...s.getExtensionState()});
  }
  installDebug(){
    // Only available with ?debug=1. No debug control or bonus resources in normal play.
    const game=this;
    window.__FROST__={
      version:'2.0.0',snapshot:()=>({...game.state.snapshot(),player:{x:game.player.position.x,z:game.player.position.z,moving:game.player.moving,path:game.player.path.map(p=>({...p})),velocity:game.player.velocity.toArray(),rotation:game.player.root.quaternion.toArray()},
        render:{calls:game.sceneSetup.renderer.info.render.calls,triangles:game.sceneSetup.renderer.info.render.triangles,geometries:game.sceneSetup.renderer.info.memory.geometries,textures:game.sceneSetup.renderer.info.memory.textures,quality:game.sceneSetup.quality,shadowSize:game.sceneSetup.sun.shadow.mapSize.x,pixelRatio:game.sceneSetup.renderer.getPixelRatio()},
        workers:[...game.workers.workers.values()].map(w=>({id:w.data.id,role:w.data.role,cargo:w.data.cargo,x:w.data.x,z:w.data.z,mode:w.mode,path:w.path.length,target:w.target?.data.id})),crowdServed:game.crowd.served,cashHeight:0,cashReceipt:game.hud.cashReceiptAmount,rawStoreOperation:game.interaction.rawStoreOperation,
        camera:{mode:game.sceneSetup.cameraMode,azimuth:game.sceneSetup.camera.userData.azimuth,orthographic:game.sceneSetup.camera.isOrthographicCamera,position:game.sceneSetup.camera.position.toArray(),focus:game.sceneSetup.focus.toArray(),viewHeight:game.sceneSetup.viewHeight,width:game.sceneSetup.width,height:game.sceneSetup.height},
        drops:game.resources.drops.map(e=>({...e.data})),stackMeshes:game.inventory.visuals.size,stackHeight:game.inventory.height,stackOffsets:game.inventory.order.map(id=>game.inventory.visuals.get(id).mesh.position.y),effects:{flights:game.effects.items.length,particleSlots:game.effects.particles.length,footprintSlots:game.effects.footprints.length},soundEnabled:game.audio.enabled,gateOpen:!game.collision.obstacles.has('gate'),paused:game.paused,contextLost:game.contextLost,
        daynight:{day:game.state.dayNight.getDay(),phase:game.state.dayNight.getPhase(),progress:game.state.dayNight.getProgress()},era:game.state.ages.getEra(),eraUpgrading:game.state.ages.isVulnerable(),market:Object.fromEntries(game.state.market.goods().map(g=>[g,game.state.market.marketPrice(g)])),factions:Object.fromEntries(game.state.factions.list().map(f=>[f.id,{relationship:game.state.factions.getRelationship(f.id),stance:game.state.factions.getStance(f.id)}])),aiCamps:game.state.aiCamps.list().map(c=>({id:c.factionId,era:c.era,readiness:c.getWarReadiness()})),
        routes:game.state.caravans.listRoutes(),annexation:Object.fromEntries(game.state.factions.list().map(f=>[f.id,game.state.annexation.getProgress(f.id)])),sieges:{...game.state.sieges},endgame:{victory:game.state.endgame.isVictory(),countdown:game.state.endgame.countdown?{...game.state.endgame.countdown}:null,wonder:{...game.state.endgame.wonder},relics:game.state.endgame.relics.size,hegemonyDays:game.state.endgame.hegemonyDays},
        lamps:{count:game.state.lampNetwork.lamps.length,level:game.state.lampNetwork.getNetworkLevel()},nightReport:game.state.raidWaves.lastReport,threats:game.state.dayNight.getUpcomingThreats().map(t=>({nightsAway:t.nightsAway,source:t.threat?.source})),
        prestige:{points:Math.floor(game.state.prestige.points),supplyCost:game.state.prestige.supplyCost(),calls:game.state.prestige.calls,powerUses:{...game.state.prestige.powerUses}},pendingEvents:game.state.pendingEvents.map(e=>({uid:e.uid,type:e.type,factionId:e.factionId})),coupons:{...game.state.coupons}}),
      freeze:value=>{game.testFrozen=value;game.last=performance.now();},
      goTo:(x,z)=>game.player.moveTo({x,z}),
      project:(x,z,y=0)=>game.sceneSetup.project(new THREE.Vector3(x,y,z)),
      advance:(seconds,{render=true}={})=>{if(!Number.isFinite(seconds)||seconds<0||seconds>120)throw new Error('advance: 0..120 seconds');
        for(let i=0;i<Math.ceil(seconds*60)&&!game.paused;i++)game.simulate(1/60);game.sceneSetup.stackHeight=game.inventory.height+1;game.sceneSetup.follow(game.player.position,1,true);if(render)game.render(0);return window.__FROST__.snapshot();},
      render:()=>game.render(0),save:()=>game.save.save(),dispose:()=>game.dispose(),
      context:()=>game.sceneSetup.renderer.getContext().getExtension('WEBGL_lose_context'),
      test:{collectCash:limit=>game.state.collectCash(limit),setCounterCash:value=>{game.state.counterCash=Math.max(0,Math.min(99999999,Math.floor(value)));game.state.changed('state');},purchase:key=>game.state.purchase(key),setStock:(type,value)=>{if(type in game.state.camp.stock){game.state.camp.stock[type]=Math.max(0,Math.min(180,Math.floor(value)));game.state.changed('camp');}},setFuel:value=>{game.state.camp.fuel=Math.max(0,Math.min(3,Math.floor(value)));},setCash:value=>{game.state.cash=Math.max(0,Math.min(99999999,Math.floor(value)));game.state.changed('cash');},
        setStance:(id,stance)=>{const ok=game.state.factions.setStance(id,stance);game.state.changed('state');return ok;},openRoute:id=>game.state.openRoute(id),dispatchCaravan:id=>game.state.dispatchCaravan(id),raid:id=>game.state.raidFaction(id),assault:id=>game.state.assaultFaction(id),toggleSiege:id=>game.state.toggleSiege(id),collectRelic:id=>game.state.collectRelic(id),startWonder:()=>game.state.startWonder(),
        addPrestige:n=>{game.state.prestige.gain(Math.max(0,Math.floor(n)||0),'debug');game.state.changed('state');},callCard:id=>game.state.callSupplyCard(id),usePower:id=>game.state.usePower(id),acceptEvent:uid=>game.state.acceptEvent(uid),
        pushEvent:e=>{game.state.pendingEvents.push({expiresDay:999,...e});game.state.changed('camp-event');},
        setEra:n=>{game.state.ages.restore({version:1,era:Math.max(1,Math.min(4,Math.floor(n)||1))});game.state.changed('state');},
        setQuest:n=>{game.state.quest=Math.max(0,Math.min(64,Math.floor(n)||0));game.state.changed('quest');},
        setStat:(key,value)=>{if(Object.hasOwn(game.state.stats,key)){game.state.stats[key]=Math.max(0,Math.floor(value)||0);game.state.changed('state');}},
        inventory:types=>{game.state.cooking=null;game.state.inventory=[];game.state.changed('inventory');types.forEach(type=>game.state.add(type));},
        teleport:(x,z,{render=true}={})=>{const p=game.collision.nearestFree({x,z});if(p){game.player.stop();game.player.position.set(p.x,0,p.z);game.player.root.position.copy(game.player.position);game.state.position={...p};game.state.changed('state');game.sceneSetup.follow(game.player.position,1,true);if(render)game.render(0);}},
      },
    };
    window.advanceTime=ms=>{game.testFrozen=true;return window.__FROST__.advance(ms/1000);};
  }
  dispose(){
    if(this.disposed)return;this.disposed=true;cancelAnimationFrame(this.raf);this.abort.abort();
    this.save.dispose();this.input.dispose();this.hud.dispose();this.player.dispose();this.inventory.dispose();this.workers.dispose();this.logistics.dispose();this.resources.dispose();
    this.counterStaffView.dispose();
    this.interaction.dispose();this.crowd.dispose();this.effects.dispose();this.map.dispose();this.caravanView.dispose();this.audio.dispose();this.state.events.clear();
    this.factory.dispose();this.sceneSetup.dispose();delete window.__FROST__;delete window.advanceTime;delete window.render_game_to_text;
  }
}
