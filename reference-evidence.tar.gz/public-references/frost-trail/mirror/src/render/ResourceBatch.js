import * as THREE from 'three';

/** Fixed-capacity, shared-geometry instancing for one resource type. */
export class ResourceBatch {
  constructor(factory, type, capacity, parent) {
    this.type = type; this.capacity = capacity; this.used = 0;
    this.group = new THREE.Group(); parent.add(this.group);
    const template = factory.createResource(type); template.updateMatrixWorld(true);
    this.bounds = new THREE.Box3().setFromObject(template);
    this.parts = [];
    template.traverse(part => {
      if (!part.isMesh) return;
      const mesh = new THREE.InstancedMesh(part.geometry, part.material, capacity);
      mesh.instanceMatrix.setUsage(THREE.DynamicDrawUsage); mesh.count = 0;
      mesh.castShadow = true; mesh.receiveShadow = true; mesh.frustumCulled = false;
      this.group.add(mesh); this.parts.push({ mesh, local: part.matrixWorld.clone() });
    });
    this.matrix = new THREE.Matrix4();
  }
  reset() { this.used = 0; }
  append(matrix) {
    if (this.used >= this.capacity) return false;
    for (const part of this.parts) {
      this.matrix.multiplyMatrices(matrix, part.local);
      part.mesh.setMatrixAt(this.used, this.matrix);
    }
    this.used++; return true;
  }
  flush() {
    for (const { mesh } of this.parts) { mesh.count = this.used; mesh.instanceMatrix.needsUpdate = true; }
    this.group.visible = this.used > 0;
  }
  dispose() {
    this.group.removeFromParent();
    for (const { mesh } of this.parts) mesh.dispose?.();
    this.parts.length = 0;
  }
}
