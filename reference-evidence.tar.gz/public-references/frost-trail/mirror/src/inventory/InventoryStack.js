import * as THREE from 'three';
import { RESOURCE, BALANCE } from '../simulation/Balance.js';
import { damp } from '../utils/math.js';
import { ResourceBatch } from '../render/ResourceBatch.js';

/** Pure inventory in GameState; an actually measured, instanced stack on the back. */
export class InventoryStack {
  constructor({ playerRoot, state, factory }) {
    Object.assign(this, { state, factory });
    this.group = new THREE.Group(); this.group.name = 'backpack-stack';
    this.group.position.set(0, .91, -.41); playerRoot.add(this.group);
    this.visuals = new Map(); this.order = []; this.batches = new Map(); this.elapsed = 0;
    this.height = 0; this.zero = new THREE.Vector3();
    this.unsubscribe = state.events.on('inventory', event => this.sync(event));
    this.sync();
  }
  get count() { return this.state.inventory.length; }
  add(type, options) { return this.state.add(type, options); }
  remove(type) { return this.state.remove(type); }
  batchFor(type) {
    if (!this.batches.has(type)) this.batches.set(type,
      new ResourceBatch(this.factory, type, BALANCE.upgradedCapacity, this.group));
    return this.batches.get(type);
  }
  sync(event) {
    const keep = new Set(this.state.inventory.map(item => item.id));
    for (const id of this.visuals.keys()) if (!keep.has(id)) this.visuals.delete(id);
    let base = 0; this.order.length = 0;
    for (const item of this.state.inventory) {
      const batch = this.batchFor(item.type);
      const height = Math.max(RESOURCE[item.type].height, batch.bounds.max.y - batch.bounds.min.y);
      const origin = -batch.bounds.min.y + (height - (batch.bounds.max.y - batch.bounds.min.y)) / 2;
      let entry = this.visuals.get(item.id);
      if (!entry) {
        entry = { type: item.type, mesh: new THREE.Object3D(), height,
          pop: event?.kind === 'add' ? 0 : 1, y: base + origin };
        entry.mesh.position.y = entry.y; this.visuals.set(item.id, entry);
      }
      entry.y = base + origin; this.order.push(item.id); base += height + .013;
    }
    this.height = base;
    // Rebuild immediately: logical ground removal and appearance on the back are atomic.
    this.update(0, this.zero);
  }
  update(dt, velocity = this.zero) {
    if (!Number.isFinite(dt) || dt < 0) return;
    this.elapsed += dt; const response = dt ? damp(20, dt) : 1;
    const speed = Math.min(1, velocity.length() / BALANCE.speed);
    for (const batch of this.batches.values()) batch.reset();
    for (let index = 0; index < this.order.length; index++) {
      const entry = this.visuals.get(this.order[index]); entry.pop = Math.min(1, entry.pop + dt * 8);
      const sway = Math.min(index + 1, 55) * .007 * speed;
      entry.mesh.position.x = Math.sin(this.elapsed * 7 - index * .18) * sway;
      entry.mesh.position.y = THREE.MathUtils.lerp(entry.mesh.position.y, entry.y, response);
      entry.mesh.rotation.z = Math.sin(this.elapsed * 7 - index * .18) * sway * .22;
      entry.mesh.scale.setScalar(1 + Math.sin(entry.pop * Math.PI) * .15); entry.mesh.updateMatrix();
      this.batches.get(entry.type).append(entry.mesh.matrix);
    }
    for (const batch of this.batches.values()) batch.flush();
    this.group.rotation.x = THREE.MathUtils.lerp(this.group.rotation.x, -speed * .045, response);
  }
  getTopWorldPosition(out = new THREE.Vector3()) {
    this.group.updateWorldMatrix(true, false); return this.group.localToWorld(out.set(0, this.height, 0));
  }
  dispose() {
    this.unsubscribe(); this.group.removeFromParent();
    for (const batch of this.batches.values()) batch.dispose();
    this.batches.clear(); this.visuals.clear(); this.order.length = 0;
  }
}
