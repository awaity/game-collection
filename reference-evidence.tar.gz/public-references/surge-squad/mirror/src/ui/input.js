import { CONFIG } from '../simulation/config.js';
export class Input {
  constructor(stage,actions,getGame){
    this.stage=stage;this.actions=actions;this.getGame=getGame;this.keys=new Set();this.drag=null;
    this.down=ev=>{
      const game=getGame();if(game.phase!=='playing'||ev.target.closest('button,input,section'))return;
      this.drag={id:ev.pointerId,x:ev.clientX,origin:game.player.x};stage.setPointerCapture?.(ev.pointerId);actions.takeover();ev.preventDefault();
    };
    this.move=ev=>{if(!this.drag||ev.pointerId!==this.drag.id)return;const w=stage.getBoundingClientRect().width;actions.aim(this.drag.origin+(ev.clientX-this.drag.x)/w*CONFIG.roadWidth*1.27);ev.preventDefault();};
    this.up=ev=>{if(this.drag&&ev.pointerId===this.drag.id){this.drag=null;if(stage.hasPointerCapture?.(ev.pointerId))stage.releasePointerCapture(ev.pointerId);}};
    stage.addEventListener('pointerdown',this.down);stage.addEventListener('pointermove',this.move);stage.addEventListener('pointerup',this.up);stage.addEventListener('pointercancel',this.up);stage.addEventListener('lostpointercapture',()=>{this.drag=null;});
    window.addEventListener('keydown',ev=>{
      if(ev.target instanceof HTMLInputElement)return;
      if(['ArrowLeft','ArrowRight','KeyA','KeyD'].includes(ev.code)) {ev.preventDefault();this.keys.add(ev.code);if(getGame().phase==='playing')actions.takeover();}
      if(ev.repeat)return;
      if(['Escape','KeyP'].includes(ev.code)){ev.preventDefault();getGame().phase==='paused'?actions.resume():actions.pause();}
      if(ev.code==='KeyR'&&getGame().phase!=='ready'){ev.preventDefault();actions.restart();}
      if(ev.code==='KeyM'){ev.preventDefault();actions.sound();}
      if(ev.code==='KeyH'&&getGame().phase!=='ready'){ev.preventDefault();actions.clean();}
      if(ev.code==='Backquote'){ev.preventDefault();actions.debug();}
    });
    window.addEventListener('keyup',ev=>this.keys.delete(ev.code));
    window.addEventListener('blur',()=>this.clear());
  }
  step(dt){
    const g=this.getGame();if(g.phase!=='playing')return;
    const left=this.keys.has('KeyA')||this.keys.has('ArrowLeft');const right=this.keys.has('KeyD')||this.keys.has('ArrowRight');
    if(left!==right)this.actions.aim(g.player.targetX+(right?1:-1)*7.4*dt);
  }
  clear(){this.keys.clear();const id=this.drag?.id;this.drag=null;
    if(id!==undefined&&this.stage.hasPointerCapture?.(id))this.stage.releasePointerCapture(id);
  }
}
