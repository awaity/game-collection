import { bossScale } from '../render/track.js';
import { CHAPTERS, CONFIG } from '../simulation/config.js';
const $=id=>document.getElementById(id);
export class UI {
  constructor(actions,save){
    this.actions=actions;this.save=save;this.clean=false;this.selected=0;this.lastPhase='';this.toastUntil=-1;this.resultShown=false;
    this.bind('start-button',()=>actions.start(this.selected,false));this.bind('demo-button',()=>actions.start(this.selected,true));
    this.bind('pause-button',()=>actions.pause());this.bind('resume-button',()=>actions.resume());
    this.bind('restart-button',()=>actions.restart());this.bind('retry-button',()=>actions.restart());
    this.bind('home-button',()=>actions.home());this.bind('result-home',()=>actions.home());
    this.bind('sound-toggle',()=>actions.sound());this.bind('clean-button',()=>{actions.clean();actions.resume();});this.bind('restore-hud',()=>actions.clean());
    this.bind('next-button',()=>actions.next());
    document.querySelectorAll('[data-lane]').forEach(el=>{
      const steer=()=>actions.aim(Number(el.dataset.lane));
      // Respond on contact, not the compatibility click delayed by touch browsers.
      el.addEventListener('pointerdown',ev=>{if(ev.isPrimary&&ev.button===0)steer();});
      el.addEventListener('click',steer); // keyboard/assistive activation remains supported.
    });
    document.querySelectorAll('[data-quality]').forEach(el=>el.addEventListener('click',()=>actions.quality(el.dataset.quality)));
    $('music-setting').addEventListener('change',ev=>actions.music(ev.target.checked));
    $('motion-setting').addEventListener('change',ev=>actions.motion(ev.target.checked));
    this.refreshSave(save);this.renderChapters();
  }
  bind(id,fn){$(id).addEventListener('click',fn);}
  progress(n){$('load-progress').style.width=`${Math.round(n*100)}%`;}
  ready(){this.progress(1);$('loading').classList.add('hidden');$('title-screen').classList.remove('hidden');$('start-button').disabled=false;$('start-button').innerHTML='开始行动 <span>→</span>';}
  refreshSave(save){
    this.save=save;
    $('music-setting').checked=save.settings.music;$('motion-setting').checked=save.settings.reducedMotion;
    $('sound-toggle').textContent=save.settings.sound?'♪':'∅';$('sound-toggle').setAttribute('aria-label',save.settings.sound?'关闭声音':'开启声音');
    document.querySelectorAll('[data-quality]').forEach(el=>el.classList.toggle('selected',el.dataset.quality===save.settings.quality));
  }
  renderChapters(){
    const parent=$('chapter-select');parent.replaceChildren();
    CHAPTERS.forEach((chapter,i)=>{const button=document.createElement('button');button.textContent=`0${i+1} ${i>=this.save.unlocked?'· 锁定':chapter.name}`;button.disabled=i>=this.save.unlocked;button.classList.toggle('selected',this.selected===i);button.setAttribute('aria-label',`第${i+1}关 ${chapter.name}`);button.addEventListener('click',()=>{this.selected=i;this.renderChapters();this.actions.select(i);});parent.append(button);});
  }
  phase(game){
    const phase=game.phase;this.lastPhase=phase;
    $('title-screen').classList.toggle('hidden',phase!=='ready');$('pause-screen').classList.toggle('hidden',phase!=='paused');
    const result=phase==='victory'||phase==='defeat';$('result-screen').classList.toggle('hidden',!result);
    $('hud').classList.toggle('hidden',phase==='ready'||this.clean);$('restore-hud').classList.toggle('hidden',!this.clean||phase==='ready');
    $('demo-badge').classList.toggle('hidden',!game.demo);
    $('chapter-kicker').textContent=`行动 0${game.level.index+1}`;$('chapter-name').textContent=game.level.chapter.name;
    if(result)this.showResult(game);
    if(phase==='paused')$('resume-button').focus({preventScroll:true});
    if(phase==='ready'){this.renderChapters();$('start-button').focus({preventScroll:true});}
  }
  showResult(game){
    const win=game.phase==='victory';document.querySelector('.result-card').classList.toggle('defeat',!win);
    $('result-title').textContent=win?'防线已突破':'电涌暂时熄灭';$('result-kicker').textContent=win?'MISSION COMPLETE':'REGROUP & RETURN';
    $('result-subtitle').textContent=win?(game.level.index===2?'三段防线已全部打通。':'小队已抵达下一座电站。'):'先在中央蓄能，再横移清场与扩编。';
    const stars=win?(game.stats.kills>1800&&game.stats.bosses===2?3:game.stats.kills>800?2:1):0;
    $('result-stars').textContent=win?Array.from({length:3},(_,i)=>i<stars?'✦':'✧').join(' '):'ϟ';
    $('result-score').textContent=game.stats.score.toLocaleString('zh-CN');$('result-kills').textContent=game.stats.kills.toLocaleString('zh-CN');$('result-troops').textContent=game.player.troops;$('result-time').textContent=`${game.time.toFixed(1)}s`;
    $('next-button').classList.toggle('hidden',!win);$('next-button').innerHTML=game.level.index===2?'重返海堤 <span>↻</span>':'下一段防线 <span>→</span>';
    (win?$('next-button'):$('retry-button')).focus({preventScroll:true});
  }
  toggleClean(game){this.clean=!this.clean;this.phase(game);}
  event(ev,game){
    const messages={start:'中央蓝带蓄能，横移自动放电',recruit:`+${ev.value} 队员加入`,overcharge:'金色电能 +99 · 超载强化',arena:'巨兽封锁前路 · 躲开致命重击',warning:ev.bossType==='titan'?'终局重击 · 立刻离开红色区域':null,combo:`${ev.value} 连破`,victory:'防线突破',defeat:'重新集结，再来一次', 'missed-gate':`错过 +${ev.value} 补给`};
    if(messages[ev.type])this.toast(messages[ev.type],game.time,ev.type==='start'?4:1.6);
    if(ev.type==='recruit'&&!this.save.settings.reducedMotion){$('troop-count').animate?.([{transform:'scale(1.5)',color:'#fff19b'},{transform:'scale(1)',color:'#fff'}],{duration:320});}
  }
  toast(text,time,duration=1.8){$('toast').textContent=text;$('toast').classList.add('show');this.toastUntil=time+duration;}
  update(game,view){
    if(game.phase!==this.lastPhase)this.phase(game);
    $('troop-count').textContent=game.player.troops;$('kill-count').textContent=game.stats.kills.toLocaleString('zh-CN');
    const ratio=game.player.energy/CONFIG.energyMax;
    $('energy-fill').style.width=`${ratio*100}%`;$('energy-number').textContent=`${Math.round(ratio*100)}%`;
    $('energy-label').textContent=game.player.laser?(game.player.boost>0?'超载放电':'激光放电'):game.player.charging?'正在充能':ratio>.95?'蓄能就绪':'电能储备';
    $('energy-panel').classList.toggle('full',ratio>.95);$('energy-panel').classList.toggle('firing',game.player.laser);
    $('route-fill').style.width=`${game.progress*100}%`;
    document.querySelectorAll('[data-lane]').forEach(el=>el.classList.toggle('active',Math.abs(Number(el.dataset.lane)-game.player.x)<1.2));
    $('toast').classList.toggle('show',game.time<this.toastUntil);
    $('control-hint').style.opacity=game.time<9?'1':'.45';$('control-hint').textContent=game.level.gates[1].state==='taken'&&game.level.bosses[0].hp>0&&game.player.x>1.8?'先击破左侧守关者 · 解锁金色电站':game.time<9?'左右拖动 · 自动射击':game.player.charging?'充能中 · 横移释放激光':'回到中央补充电能';
    $('combo').classList.toggle('show',game.combo>=60&&game.comboTimer>0);$('combo').querySelector('strong').textContent=game.combo;
    $('damage-vignette').style.opacity=this.save.settings.reducedMotion?'0':String(view.effects.flash*.6);
    $('demo-badge').classList.toggle('hidden',!game.demo);
    game.level.bosses.forEach((boss,i)=>{
      const label=$(`boss-${i}`);const projection=view.project(boss.x,2.04*bossScale(boss,boss.d-game.distance)+.24,boss.d);
      const visible=boss.hp>0&&projection.visible&&boss.d-game.distance<CONFIG.viewDistance;
      label.style.display=visible?'block':'none';if(!visible)return;
      label.style.left=`${projection.x}px`;label.style.top=`${projection.y}px`;
      const distance=boss.d-game.distance;label.style.transform=`translate(-50%,-100%) scale(${Math.max(.60,Math.min(1.15,1.2-distance*.0065))})`;
      label.querySelector('strong').textContent=Math.ceil(boss.hp).toLocaleString('en-US');label.querySelector('i').style.width=`${boss.hp/boss.maxHp*100}%`;
    });
  }
  error(error){$('loading').classList.add('hidden');$('fatal-error').classList.remove('hidden');$('fatal-detail').textContent=error?.message||String(error);}
}
