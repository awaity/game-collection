/** Original Web Audio synthesis. No recordings, remote URLs or copyrighted music. */
export class Sound {
  constructor(settings){this.settings=settings;this.context=null;this.voices=0;this.lastShot=-9;this.musicStep=0;this.nextBeat=0;this.active=false;this.wantRunning=false;this.switching=null;}
  resetRun(){ this.lastShot=-9;this.musicStep=0;this.nextBeat=0; }
  async unlock(){
    this.wantRunning=true;
    try{
      if(!this.context){
        const Audio=globalThis.AudioContext||globalThis.webkitAudioContext;if(!Audio)return;
        const c=this.context=new Audio();this.master=c.createGain();this.master.gain.value=.6;this.master.connect(c.destination);
        this.sfx=c.createGain();this.sfx.gain.value=.52;this.sfx.connect(this.master);this.music=c.createGain();this.music.gain.value=.16;this.music.connect(this.master);
        this.analyser=c.createAnalyser();this.analyser.fftSize=256;this.master.connect(this.analyser);
        const size=c.sampleRate;this.noiseBuffer=c.createBuffer(1,size,c.sampleRate);const data=this.noiseBuffer.getChannelData(0);let n=117;
        for(let i=0;i<size;i++){n=(1664525*n+1013904223)>>>0;data[i]=n/2147483648-1;}
        const laserOsc=c.createOscillator();laserOsc.type='sawtooth';laserOsc.frequency.value=67;
        const low=c.createBiquadFilter();low.type='lowpass';low.frequency.value=450;low.Q.value=1.4;
        this.laserGain=c.createGain();this.laserGain.gain.value=0;laserOsc.connect(low);low.connect(this.laserGain);this.laserGain.connect(this.sfx);laserOsc.start();this.laserOsc=laserOsc;
      }
      await this.reconcile();this.sync();
    }catch{/* A denied audio device never blocks the game. */}
  }
  sync(){if(!this.context)return;const t=this.context.currentTime;this.master.gain.setTargetAtTime(this.settings.sound?.60:0,t,.035);this.music.gain.setTargetAtTime(this.settings.music?.16:0,t,.05);}
  reconcile(){
    if(!this.context)return Promise.resolve();
    if(this.switching)return this.switching;
    this.switching=(async()=>{
      try{
        while(this.context.state!=='closed'){
          const desired=this.wantRunning?'running':'suspended';
          if(this.context.state===desired)break;
          if(this.wantRunning)await this.context.resume();else await this.context.suspend();
        }
      }catch{/* Denied audio remains silent, and never blocks controls. */}
      this.active=this.wantRunning&&this.context.state==='running';
    })().finally(()=>{this.switching=null;});
    return this.switching;
  }
  pause(){this.wantRunning=false;this.active=false;if(this.laserGain)this.laserGain.gain.value=0;return this.reconcile();}
  tone(freq,duration=.12,type='sine',volume=.2,dest=this.sfx,slide=0){
    const c=this.context;if(!c||c.state!=='running'||this.voices>=32)return;this.voices++;
    const osc=c.createOscillator(),gain=c.createGain();osc.type=type;const t=c.currentTime;osc.frequency.setValueAtTime(Math.max(20,freq),t);if(slide)osc.frequency.exponentialRampToValueAtTime(Math.max(20,slide),t+duration);
    gain.gain.setValueAtTime(0,t);gain.gain.linearRampToValueAtTime(volume,t+.004);gain.gain.exponentialRampToValueAtTime(.001,t+duration);osc.connect(gain);gain.connect(dest);osc.start(t);osc.stop(t+duration+.02);
    osc.onended=()=>{osc.disconnect();gain.disconnect();this.voices--;};
  }
  noise(duration=.08,volume=.18,frequency=1200){
    const c=this.context;if(!c||c.state!=='running'||this.voices>=32)return;this.voices++;
    const src=c.createBufferSource();src.buffer=this.noiseBuffer;const filter=c.createBiquadFilter();filter.type='lowpass';filter.frequency.value=frequency;const gain=c.createGain();const t=c.currentTime;gain.gain.setValueAtTime(volume,t);gain.gain.exponentialRampToValueAtTime(.001,t+duration);src.connect(filter);filter.connect(gain);gain.connect(this.sfx);src.start(t);src.stop(t+duration);
    src.onended=()=>{src.disconnect();filter.disconnect();gain.disconnect();this.voices--;};
  }
  event(ev,game){
    if(!this.context||!this.settings.sound)return;
    switch(ev.type){
      case 'shot': if(game.time-this.lastShot>.10){this.tone(195,.065,'triangle',.11,this.sfx,65);this.noise(.035,.07,2100);this.lastShot=game.time;} break;
      case 'cell': this.tone(ev.gold?1046:600+game.player.energy*22,.075,'sine',.11);break;
      case 'overcharge':case 'recruit':this.tone(523,.25,'triangle',.17);this.tone(659,.28,'sine',.12);this.tone(784,.33,'sine',.12);break;
      case 'gate-break':this.noise(.29,.46,1300);this.tone(110,.17,'sine',.2,this.sfx,43);break;
      case 'laser-on':this.tone(150,.26,'sawtooth',.10,this.sfx,440);this.noise(.14,.16,2600);break;
      case 'boss-down':this.noise(.62,.60,700);this.tone(78,.52,'sine',.27,this.sfx,28);break;
      case 'hurt':this.noise(.18,.29,900);this.tone(220,.16,'square',.05,this.sfx,80);break;
      case 'warning':this.tone(740,.17,'sine',.15);break;
      case 'slam':this.noise(.29,.45,750);break;
      case 'victory':for(const f of [523,659,784,1046])this.tone(f,.8,'triangle',.085);break;
      case 'defeat':this.tone(180,.55,'sawtooth',.1,this.sfx,44);break;
    }
  }
  update(game){
    const c=this.context;if(!c||c.state!=='running')return;
    this.laserGain.gain.setTargetAtTime(game.player.laser&&game.phase==='playing'?.12:0,c.currentTime,.04);
    this.laserOsc.frequency.setTargetAtTime(68+game.player.energy*1.9,c.currentTime,.05);
    if(game.phase!=='playing'||!this.settings.music)return;
    if(c.currentTime>=this.nextBeat){
      this.nextBeat=c.currentTime+.22727;const step=this.musicStep++%64;
      const roots=[73.416,65.406,87.307,65.406];const root=roots[Math.floor(step/16)];
      if(step%4===0){this.tone(110,.17,'sine',.32,this.music,39);this.tone(root,.25,'triangle',.22,this.music);}
      if(step%8===4)this.tone(184,.09,'triangle',.18,this.music,72);
      const degrees=[0,7,12,7,3,7,10,7];const note=root*4*Math.pow(2,degrees[step%8]/12);
      if(step%2===0)this.tone(note,.13,'sine',.07,this.music);
      if(step%16===0){this.tone(root*2,.9,'sine',.035,this.music);this.tone(root*2*Math.pow(2,7/12),.9,'sine',.024,this.music);}
    }
  }
  diagnostics(){let peak=0;if(this.analyser){const a=new Float32Array(this.analyser.fftSize);this.analyser.getFloatTimeDomainData(a);for(const n of a)peak=Math.max(peak,Math.abs(n));}return {state:this.context?.state||'locked',voices:this.voices,peak,enabled:this.settings.sound,music:this.settings.music};}
}
