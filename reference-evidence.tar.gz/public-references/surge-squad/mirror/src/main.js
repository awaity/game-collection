import { Game } from './simulation/game.js';
import { StepClock } from './simulation/clock.js';
import { CONFIG } from './simulation/config.js';
import { readSave, writeSave, recordVictory } from './simulation/save.js';
import { View } from './render/view.js';
import { Sound } from './audio/sound.js';
import { UI } from './ui/ui.js';
import { Input } from './ui/input.js';

const params=new URLSearchParams(globalThis.__SURGE_PARAMS__ || location.search);const qa=params.has('qa');
let storage;try{storage=localStorage;}catch{storage=null;}
let save=readSave(storage);let game=new Game();let view;let input;let ui;
let manual=qa,accumulator=0,last=0,idle=0,renderTime=0,showDebug=params.has('debug'),frames=0,frameSum=0;
const frameTimes=[];const manualClock=new StepClock(CONFIG.step);
const sound=new Sound(save.settings);const stage=document.getElementById('stage');
const motionPreference=matchMedia('(prefers-reduced-motion: reduce)').matches;
const persist=()=>{writeSave(storage,save);ui?.refreshSave(save);};
function replaceGame(index,phase='ready',demo=false){
  game=new Game(index);manualClock.reset();sound.resetRun();game.demo=demo;accumulator=0;idle=0;input?.clear();
  view?.setGame(game);ui.toastUntil=-1;
  if(phase==='playing')game.start();ui.phase(game);
  if(phase==='playing')sound.unlock();else sound.pause();
}
const actions={
  start(index=0,demo=false){if(!view?.ready)return;manual=qa;replaceGame(index,'playing',demo);},
  pause(){if(game.phase==='playing'){game.pause();input?.clear();sound.pause();ui.phase(game);}},
  resume(){if(game.phase==='paused'&&!view.contextLost){game.resume();accumulator=0;sound.unlock();ui.phase(game);}},
  restart(){if(!view?.ready)return;replaceGame(game.level.index,'playing',game.demo);},
  home(){ui.selected=game.level.index;manual=false;replaceGame(game.level.index);},
  next(){const next=(game.level.index+1)%3;ui.selected=next;replaceGame(next,'playing',false);},
  select(index){replaceGame(index);},
  aim(x){if(game.phase!=='playing')return;game.demo=false;game.aim(x);},
  takeover(){game.demo=false;},
  sound(){save.settings.sound=!save.settings.sound;sound.settings=save.settings;persist();if(game.phase==='playing')sound.unlock();else sound.sync();},
  music(value){save.settings.music=value;sound.settings=save.settings;persist();sound.sync();},
  motion(value){save.settings.reducedMotion=value;view.options.reducedMotion=value||motionPreference;persist();},
  quality(value){save.settings.quality=value;view.setQuality(value);persist();},
  clean(){ui.toggleClean(game);},
  debug(){showDebug=!showDebug;document.getElementById('debug-panel').classList.toggle('hidden',!showDebug);},
};
ui=new UI(actions,save);
function consumeEvents(){
  for(const event of game.drainEvents()){
    view.effects.event(event,game);ui.event(event,game);sound.event(event,game);
    if(event.type==='victory'&&!game.demo&&!qa){save=recordVictory(save,game.level.index,game.stats.score);persist();}
  }
}
function tick(dt){input.step(dt);game.step(dt);consumeEvents();}
function render(dt){
  renderTime=game.phase==='playing'||game.phase==='paused'?game.time:game.time+idle;
  const fxDt=game.phase==='paused'?0:dt;
  view.draw(fxDt,game,renderTime);
  // World health bars follow the camera every frame; game state is small enough for this HUD budget.
  ui.update(game,view);
  if(showDebug){const diag={...view.stats,fps:frames>0?Math.round(1000/(frameSum/frames)):0,phase:game.phase,seconds:game.time.toFixed(1)};document.getElementById('debug-panel').textContent=JSON.stringify(diag,null,1);document.getElementById('debug-panel').classList.remove('hidden');}
}
function loop(ms){
  requestAnimationFrame(loop);if(!view?.ready||view.contextLost)return;
  const wallDt=last?Math.max(0,(ms-last)/1000):0;const dt=Math.min(.08,wallDt);last=ms;
  if(document.hidden)return;
  if(!manual&&wallDt>0){frameTimes.push(wallDt*1000);if(frameTimes.length>120)frameTimes.shift();frames=frameTimes.length;frameSum=frameTimes.reduce((a,b)=>a+b,0);}
  if(!manual){
    if(game.phase==='playing'){
      accumulator+=dt;let steps=0;
      while(accumulator>=CONFIG.step&&steps<5){tick(CONFIG.step);accumulator-=CONFIG.step;steps++;}
      if(steps===5)accumulator=0;
      idle=0;
    }else if(game.phase!=='paused'){idle+=dt;}
    render(dt);
  }
  sound.update(game);
}
async function boot(){
  try{
    if(!globalThis.THREE)throw new Error('本地 3D 引擎未载入，请确认 vendor 文件夹完整。');
    view=new View(stage,{quality:params.get('quality')||save.settings.quality,reducedMotion:motionPreference||save.settings.reducedMotion,
      onContextLost(){game.pause();input?.clear();sound.pause();document.getElementById('context-notice').classList.remove('hidden');ui.phase(game);},
      onContextRestored(){document.getElementById('context-notice').classList.add('hidden');view.resize();ui.phase(game);},
    });
    await view.load(p=>ui.progress(p));view.setGame(game);input=new Input(stage,actions,()=>game);
    ui.ready();ui.phase(game);render(0);
    globalThis.render_game_to_text=()=>JSON.stringify({...game.snapshot(),render:view.stats,audio:sound.diagnostics()});
    // A deterministic time hook used by the bundled browser tests. It does not grant resources.
    globalThis.advanceTime=async milliseconds=>{
      if(!Number.isFinite(milliseconds)||milliseconds<0||milliseconds>180000)throw new RangeError('advanceTime accepts 0–180000 ms');
      manual=true;const steps=game.phase==='paused'?0:manualClock.consume(milliseconds);
      for(let i=0;i<steps;i++){if(game.phase==='playing')tick(CONFIG.step);else if(game.phase!=='paused')idle+=CONFIG.step;view.effects.update(game.phase==='paused'?0:CONFIG.step,game,game.time+idle);}
      render(0);return game.snapshot();
    };
    if(qa)globalThis.__SURGE__={
      ready:true,state:()=>game.snapshot(),stats:()=>view.stats,start:(index=0,demo=false)=>{actions.start(index,demo);manual=true;},
      aim:x=>{game.demo=false;game.aim(x);},pause:actions.pause,resume:actions.resume,restart:()=>{actions.restart();manual=true;},
      frame:()=>render(0),advance:globalThis.advanceTime,setManual:value=>{manual=value;manualClock.reset();last=performance.now();accumulator=0;},
      audio:()=>sound.diagnostics(),quality:actions.quality,clean:()=>{if(!ui.clean)actions.clean();},
      context:lose=>{if(lose)view.renderer.forceContextLoss();else view.renderer.forceContextRestore();},
      debugState:()=>({game,view}),
    };
    if(params.get('autoplay')==='1'){actions.start(Math.max(0,Math.min(2,Number(params.get('chapter')||0))),true);}
    if(params.get('clean')==='1'){ui.clean=true;ui.phase(game);}
    requestAnimationFrame(loop);
  }catch(error){console.error(error);ui.error(error);}
}
document.addEventListener('visibilitychange',()=>{if(document.hidden)actions.pause();last=0;});
window.addEventListener('pagehide',()=>sound.pause());
boot();
