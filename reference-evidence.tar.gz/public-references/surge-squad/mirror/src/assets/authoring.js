/* Original parametric model kit. Units: metres, +Y up, character forward = -Z.
 * Exported GLBs retain a custom _PART attribute for lightweight gait animation. */
const T = globalThis.THREE;
export function roundedBox(w, h, d, radius = 0.05, segments = 4) {
  const g = new T.BoxGeometry(w, h, d, segments, segments, segments);
  const p = g.attributes.position, r = Math.min(radius, w / 2, h / 2, d / 2);
  const v = new T.Vector3(), inner = new T.Vector3(), n = new T.Vector3();
  for (let i = 0; i < p.count; i++) {
    v.fromBufferAttribute(p, i);
    inner.set(Math.max(-w / 2 + r, Math.min(w / 2 - r, v.x)), Math.max(-h / 2 + r, Math.min(h / 2 - r, v.y)), Math.max(-d / 2 + r, Math.min(d / 2 - r, v.z)));
    n.subVectors(v, inner).normalize(); v.copy(inner).addScaledVector(n, r); p.setXYZ(i, v.x, v.y, v.z);
    g.attributes.normal.setXYZ(i,n.x,n.y,n.z);
  }
  g.attributes.normal.needsUpdate=true; return g;
}
function mergeParts(parts) {
  const result = new T.BufferGeometry(); const arrays = { position: [], normal: [], uv: [], part: [] };
  for (const p of parts) {
    let g = p.geometry.index ? p.geometry.toNonIndexed() : p.geometry.clone();
    const m = new T.Matrix4(); const q = new T.Quaternion().setFromEuler(new T.Euler(...(p.rotation || [0, 0, 0])));
    m.compose(new T.Vector3(...(p.position || [0, 0, 0])), q, new T.Vector3(...(p.scale || [1, 1, 1]))); g.applyMatrix4(m);
    arrays.position.push(...g.attributes.position.array); arrays.normal.push(...g.attributes.normal.array);
    arrays.uv.push(...(g.attributes.uv?.array || new Float32Array(g.attributes.position.count * 2)));
    arrays.part.push(...new Float32Array(g.attributes.position.count).fill(p.part || 0));
    g.dispose();
  }
  for (const [name, values] of Object.entries(arrays)) result.setAttribute(name, new T.Float32BufferAttribute(values, name === 'uv' ? 2 : name === 'part' ? 1 : 3));
  result.computeBoundingBox(); result.computeBoundingSphere(); return result;
}
class Kit {
  constructor() { this.parts = new Map(); this.materials = new Map(); }
  material(key, options) { this.materials.set(key, { roughness: 0.42, metalness: 0.15, ...options }); return key; }
  add(material, geometry, position, scale, rotation, part = 0) {
    if (!this.parts.has(material)) this.parts.set(material, []);
    this.parts.get(material).push({ geometry, position, scale, rotation, part }); return this;
  }
  sphere(mat, pos, scale, part = 0, segs = 14) { return this.add(mat, new T.SphereGeometry(1, segs, 10), pos, scale, null, part); }
  box(mat, pos, size, radius = .04, part = 0, rot = [0,0,0]) { return this.add(mat, roundedBox(...size, radius, 4), pos, null, rot, part); }
  cylinder(mat, pos, top, bottom, height, rotation = [0,0,0], part = 0) { return this.add(mat, new T.CylinderGeometry(top, bottom, height, 12), pos, null, rotation, part); }
  finish() { return [...this.parts].map(([name, parts]) => ({ name, geometry: mergeParts(parts), material: this.materials.get(name) })); }
}
export function authorVanguard() {
  const k = new Kit();
  k.material('azure-armor', { color: 0x0e6bb3, roughness: .38, metalness: .10 });
  k.material('ceramic', { color: 0xe3eeff, roughness: .35, metalness: .12 });
  k.material('gunmetal', { color: 0x102c48, roughness: .36, metalness: .45 });
  k.material('visor', { color: 0x092944, roughness: .12, metalness: .78 });
  k.material('coil', { color: 0x37cfff, emissive: 0x00baff, emissiveIntensity: 1.1, roughness: .18, metalness: .3 });
  const a='azure-armor', c='ceramic', d='gunmetal', v='visor', e='coil';
  // Chunky ceramic rear powerpack is the dominant silhouette in the reference angle.
  k.box(c,[0,.32,.22],[.64,.38,.29],.11);
  k.material('pack-blue',{color:0x5b78b9,roughness:.43,metalness:.06});
  k.box('pack-blue',[0,.32,.374],[.53,.28,.028],.04);
  k.box(e,[0,.32,.398],[.36,.021,.012],.006);
  k.box(d,[0,.34,.052],[.35,.30,.23],.06);
  k.sphere(a,[0,.55,0],[.22,.22,.18]);
  k.box(c,[0,.57,-.143],[.17,.14,.06],.016);
  k.sphere(a,[0,.835,-.015],[.244,.225,.222]);
  k.sphere(v,[0,.825,-.180],[.20,.108,.084]);
  k.box(e,[0,.84,-.260],[.176,.019,.014],.006);
  k.box(c,[0,.992,-.018],[.058,.020,.22],.009);
  for (const s of [-1, 1]) {
    const legPart = s < 0 ? 1 : 2;
    k.cylinder(d,[s*.12,.18,.018],.064,.07,.22,[0,0,0],legPart);
    k.box(d,[s*.12,.065,-.036],[.15,.13,.24],.046,legPart);
    k.box(c,[s*.12,.24,-.062],[.132,.11,.083],.026,legPart);
    k.sphere(a,[s*.239,.57,-.035],[.12,.13,.13],s < 0 ? 3 : 4);
    k.cylinder(d,[s*.251,.454,-.10],.064,.06,.18,[.8,0,s*.1],s < 0 ? 3 : 4);
    k.sphere(c,[s*.25,.395,-.16],[.064,.065,.065],s < 0 ? 3 : 4);
    k.cylinder(a,[s*.152,.62,.198],.070,.070,.20);
    k.sphere(e,[s*.152,.743,.198],[.07,.07,.07]);
    k.box(c,[s*.30,.59,-.05],[.029,.065,.091],.008);
  }
  k.box(c,[.255,.475,-.269],[.19,.15,.29],.025);
  k.cylinder(d,[.255,.489,-.477],.055,.063,.23,[Math.PI/2,0,0]);
  k.cylinder(c,[.255,.489,-.589],.072,.072,.047,[Math.PI/2,0,0]);
  k.cylinder(e,[.255,.489,-.616],.038,.038,.012,[Math.PI/2,0,0]);
  return k.finish();
}
export function authorRaider() {
  const k=new Kit();
  k.material('crimson',{color:0xc90727,roughness:.61,metalness:.01});
  k.material('skin',{color:0xb74554,roughness:.60,metalness:0});
  k.material('charcoal',{color:0x311d2c,roughness:.7,metalness:0});
  const ball=(mat,pos,scale,w=8,h=5)=>k.add(mat,new T.SphereGeometry(1,w,h),pos,scale);
  const box=(mat,pos,size,part=0)=>k.add(mat,new T.BoxGeometry(...size),pos,null,null,part);
  ball('crimson',[0,.30,0],[.146,.173,.112]);
  box('charcoal',[0,.191,0],[.166,.074,.13]);
  ball('skin',[0,.494,.013],[.123,.13,.113],8,5);
  ball('crimson',[0,.557,-.017],[.129,.075,.121],8,4);
  box('charcoal',[0,.479,.112],[.143,.039,.023]);
  for(const side of [-1,1]){
    box('charcoal',[side*.057,.106,0],[.077,.197,.114],side<0?1:2);
    box('crimson',[side*.143,.324,.014],[.086,.19,.097],side<0?3:4);
    box('skin',[side*.166,.217,.04],[.073,.086,.084],side<0?3:4);
  }
  return k.finish();
}
export function authorBrute() {
  const k = new Kit();
  k.material('rose-skin', { color: 0xd79992, roughness: .54, metalness: .01 });
  k.material('scarlet-jacket', { color: 0xb41b2d, roughness: .57, metalness: .015 });
  k.material('charcoal-gloves', { color: 0x2f2930, roughness: .43, metalness: .07 });
  k.material('brass-hardware', { color: 0xe6c281, roughness: .38, metalness: .15 });
  k.material('face-details', { color: 0x542d35, roughness: .8, metalness: 0 });
  const s='rose-skin',r='scarlet-jacket',m='charcoal-gloves',b='brass-hardware',f='face-details';
  k.sphere(r,[0,.99,.02],[.55,.53,.35]);
  k.sphere(s,[0,1.34,.18],[.30,.17,.19]);
  k.sphere(s,[0,1.65,.055],[.268,.30,.25],0,18);
  k.sphere(s,[0,1.51,.225],[.235,.17,.13]);
  k.sphere(s,[0,1.64,.295],[.073,.074,.065]);
  k.box(f,[0,1.49,.342],[.165,.029,.015],.012);
  k.box(m,[0,.57,.315],[.72,.13,.077],.035);
  k.box(b,[0,.57,.362],[.145,.14,.028],.022);
  k.box(m,[0,.96,.346],[.057,.55,.026],.013);
  for(let j=0;j<3;j++)k.sphere(b,[0,.82+j*.145,.37],[.037,.038,.023],0,8);
  for(const side of [-1,1]) {
    const arm=side<0?3:4,leg=side<0?1:2;
    k.sphere(r,[side*.50,1.20,.005],[.275,.28,.27],arm);
    k.sphere(s,[side*.65,.94,.11],[.207,.30,.21],arm);
    k.sphere(m,[side*.74,.64,.26],[.245,.255,.255],arm);
    k.cylinder(b,[side*.71,.81,.20],.214,.214,.105,[0,0,-side*.1],arm);
    k.sphere(r,[side*.235,.37,.015],[.213,.28,.219],leg);
    k.box(m,[side*.24,.13,.105],[.37,.26,.46],.09,leg);
    k.sphere(s,[side*.274,1.63,.059],[.070,.099,.055],0,10);
    k.box(f,[side*.106,1.724,.278],[.125,.044,.035],.015,0,[0,0,-side*.18]);
    k.sphere(f,[side*.096,1.676,.297],[.025,.028,.015],0,8);
  }
  return k.finish();
}
export function authorTitan() {
  const k = new Kit();
  k.material('rose-skin', { color: 0xe7afb3, roughness: .55, metalness: .015 });
  k.material('scarlet-cloth', { color: 0xc9223c, roughness: .66, metalness: 0 });
  k.material('leather', { color: 0x44323c, roughness: .53, metalness: .03 });
  k.material('face-details', { color: 0x804e59, roughness: .75, metalness: 0 });
  k.material('ivory-eyes', { color: 0xf7e9df, roughness: .44, metalness: 0 });
  const s='rose-skin',r='scarlet-cloth',m='leather',f='face-details',w='ivory-eyes';
  // Broad chest and rounded abdomen, with a bald head: a different silhouette,
  // not the first boss enlarged and recolored.
  k.sphere(s,[0,1.08,.00],[.64,.54,.38],0,20);
  k.sphere(s,[0,.82,.14],[.535,.44,.389],0,20);
  k.sphere(s,[0,1.50,.01],[.26,.19,.22],0,16);
  k.sphere(s,[0,1.79,.04],[.27,.33,.26],0,20);
  k.sphere(s,[0,1.62,.235],[.225,.15,.14]);
  k.sphere(s,[0,1.77,.30],[.090,.084,.072]);
  k.box(f,[0,1.633,.362],[.14,.022,.012],.01);
  k.sphere(f,[0,.83,.520],[.025,.021,.014],0,8);
  k.sphere(r,[0,.54,0],[.42,.25,.31],0,16);
  k.box(m,[0,.635,.275],[.80,.08,.12],.025);
  k.box(w,[.15,.59,.341],[.03,.20,.015],.012,0,[0,0,-.2]);
  for(const side of [-1,1]) {
    const arm=side<0?3:4,leg=side<0?1:2;
    k.sphere(s,[side*.60,1.28,-.025],[.315,.32,.32],arm,18);
    k.sphere(s,[side*.76,.99,.07],[.235,.32,.25],arm,16);
    k.sphere(s,[side*.83,.64,.19],[.253,.27,.27],arm,16);
    k.box(m,[side*.81,.797,.13],[.43,.12,.40],.045,arm);
    k.sphere(r,[side*.235,.365,.005],[.235,.285,.236],leg,16);
    k.box(r,[side*.236,.19,.06],[.33,.27,.35],.07,leg);
    k.box(m,[side*.235,.078,.14],[.36,.145,.46],.055,leg);
    k.sphere(s,[side*.282,1.78,.055],[.071,.098,.055],0,10);
    k.box(f,[side*.103,1.851,.271],[.120,.035,.032],.012,0,[0,0,-side*.14]);
    k.sphere(w,[side*.096,1.797,.291],[.036,.025,.012],0,8);
    k.sphere(f,[side*.092,1.796,.303],[.016,.020,.009],0,8);
    for(let j=0;j<3;j++)k.sphere(s,[side*(.73+j*.08),.64,.416],[.050,.063,.037],arm,8);
  }
  return k.finish();
}
export function authorRaiderLow() {
  const k=new Kit();
  k.material('crimson',{color:0xc90727,roughness:.67,metalness:.02});
  k.material('skin',{color:0xb74554,roughness:.7,metalness:.01});
  k.material('charcoal',{color:0x271e30,roughness:.75,metalness:0});
  const ico=(mat,pos,scale)=>k.add(mat,new T.IcosahedronGeometry(1,0),pos,scale);
  const cube=(mat,pos,size,part=0)=>k.add(mat,new T.BoxGeometry(...size),pos,null,null,part);
  ico('crimson',[0,.31,0],[.15,.17,.105]);ico('skin',[0,.51,0],[.12,.135,.115]);ico('crimson',[0,.568,0],[.127,.074,.122]);
  for(const s of [-1,1]){
    cube('charcoal',[s*.057,.106,0],[.079,.2,.108],s<0?1:2);
    cube('crimson',[s*.142,.32,.007],[.084,.19,.09],s<0?3:4);
    cube('skin',[s*.158,.22,.027],[.07,.09,.085],s<0?3:4);
  }
  return k.finish();
}
