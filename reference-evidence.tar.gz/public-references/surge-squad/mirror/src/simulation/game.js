import { updatePlasma, traceRay } from './combat.js';
import { weaponSocket, rayX } from './pose.js';
import { updateRails } from './rails.js';
import { CONFIG, clamp, formation, visibleTroops, squadLimit } from './config.js';
import { makeLevel } from './level.js';

/** Pure simulation: no DOM, no Three.js, no wall-clock timers. */
export class Game {
  constructor(index = 0, seed = 17429) {
    this.level = makeLevel(index, seed); this.phase = 'ready'; this.time = 0; this.distance = 0;
    this.player = { x: 0, targetX: 0, troops: 1, energy: 0, boost: 0, invincible: 0,
      laser: false, charging: false, shotClock: 0, damageBudget: 0 };
    this.stats = { kills: 0, cells: 0, recruits: 0, bosses: 0, score: 0, lost: 0, shots: 0, laserSeconds: 0 };
    this.bullets = []; this.events = []; this.warnings = []; this.beam = { distance: 34, hit: false, kind: 'empty' };
    this.beams = []; this.lastArcAt = -1;
    this.enemyStart = 0; this.cellStart = 0; this.nextBulletId = 1; this.combo = 0; this.comboTimer = 0;
    this.finalArena = false; this.arenaClock = 0; this.demo = false; this.nextAutoAction = 'charge';
  }
  start() { if (this.phase === 'ready') { this.phase = 'playing'; this.emit('start'); } }
  pause() { if (this.phase === 'playing') { this.phase = 'paused'; this.emit('pause'); } }
  resume() { if (this.phase === 'paused') { this.phase = 'playing'; this.emit('resume'); } }
  aim(x) { if (Number.isFinite(x)) this.player.targetX = clamp(x, -squadLimit(this.player.troops), squadLimit(this.player.troops)); }
  emit(type, data = {}) { if (this.events.length < 280) this.events.push({ ...data, type, time: this.time }); }
  drainEvents() { return this.events.splice(0); }
  get width() { return 0.58 + Math.min(visibleTroops(this.player.troops), 14) * 0.055; }
  get activeBoss() { return this.level.bosses.find(b => b.hp > 0 && b.d - this.distance < 54); }
  get progress() { return clamp(this.distance / this.level.chapter.length, 0, 1); }
  damagePlayer(amount, x = this.player.x) {
    if (this.phase !== 'playing' || this.player.invincible > 0 || !Number.isFinite(amount) || amount <= 0) return;
    amount=Math.ceil(amount);
    const lost = Math.min(this.player.troops, amount);
    this.player.troops -= lost; this.stats.lost += lost; this.player.invincible = 1.4;
    this.player.energy = Math.max(0, this.player.energy - 3); this.combo = 0;
    this.emit('hurt', { x, lost });
    if (this.player.troops <= 0) { this.phase = 'defeat'; this.player.laser = false; this.emit('defeat'); }
  }
  killEnemy(enemy) {
    if (enemy.hp <= 0) return;
    enemy.hp = 0; enemy.deadAt = this.time;
    this.stats.kills++; this.combo++; this.comboTimer = 2;
    this.stats.score += 10 + Math.min(20, Math.floor(this.combo / 20));
    // Bound particle/audio traffic without hiding any gameplay kills.
    if (this.stats.kills % 3 === 0) this.emit('enemy-down', { x: enemy.x, d: enemy.d, size: enemy.size });
    if (this.combo > 0 && this.combo % 100 === 0) this.emit('combo', { value: this.combo });
  }
  hitGate(gate, damage) {
    if (gate.state !== 'sealed' || !Number.isFinite(damage) || damage <= 0) return;
    if(gate.value===99&&this.level.bosses[0].hp>0)return;
    gate.hp = Math.max(0, gate.hp - damage); gate.flash = 0.09;
    if (gate.hp === 0) {
      gate.state = 'open'; gate.openedAt = this.time;
      this.emit('gate-break', { x: gate.x, d: gate.d, value: gate.value });
    }
  }
  hitBoss(boss, damage) {
    if (boss.hp <= 0 || !Number.isFinite(damage) || damage <= 0) return;
    boss.hp = Math.max(0, boss.hp - damage); boss.hitFlash = 0.055;
    if (boss.hp === 0) {
      boss.deadAt = this.time; boss.phase = 'dead'; boss.warning = null;
      this.stats.bosses++; this.stats.score += boss.type === 'titan' ? 6000 : 2500;
      this.emit('boss-down', { x: boss.x, d: boss.d, bossType: boss.type });
      for (let i = this.enemyStart; i < this.level.enemies.length; i++) {
        const e = this.level.enemies[i];
        if (e.d > boss.d + 5) break;
        if (e.hp > 0 && Math.abs(e.d - boss.d) < 5) this.killEnemy(e);
      }
    }
  }
  /** Query only the visible, sorted segment of the horde. */
  targets(x, spread, range) {
    const result = []; const base = this.distance;
    for (const g of this.level.gates) if (g.state === 'sealed' && g.d > base - 0.5 && g.d < base + range && Math.abs(g.x - x) < g.width / 2 + spread) result.push({ kind: 'gate', item: g, d: g.d });
    for (const b of this.level.bosses) if (b.hp > 0 && b.d > base - 1 && b.d < base + range && Math.abs(b.x - x) < b.size * 0.67 + spread) result.push({ kind: 'boss', item: b, d: b.d });
    for (let i = this.enemyStart; i < this.level.enemies.length; i++) {
      const e = this.level.enemies[i]; if (e.d > base + range) break;
      if (e.hp > 0 && e.d > base - 0.2 && Math.abs(e.x - x) < spread + 0.13) result.push({ kind: 'enemy', item: e, d: e.d });
    }
    result.sort((a, b) => a.d - b.d); return result;
  }
  updateLaser(dt) { updatePlasma(this, dt); }
  fireBullets(dt) {
    const p = this.player; p.shotClock -= dt;
    if (p.shotClock > 0) return;
    p.shotClock += 0.165;
    const slots = formation(Math.min(p.troops, 14));
    for (let index = 0; index < slots.length; index++) {
      if (this.bullets.length >= CONFIG.maxBullets) break;
      const socket = weaponSocket(p, slots[index], index, this.time, this.distance);
      const target = traceRay(this, socket, .05);
      const ySlope = target ? (target.y - socket.y) / Math.max(1, target.d - socket.d) : 0;
      this.bullets.push({ id: this.nextBulletId++, x: socket.x, d: socket.d, y: socket.y,
        originD: socket.d, originY: socket.y, originX: socket.x, slope: socket.slope, ySlope,
        born: this.time, damage: p.boost > 0 ? 8 : 5.2, speed: 83 });
      this.stats.shots++;
    }
    this.emit('shot', { count: slots.length });
  }
  updateBullets(dt) {
    const base = this.distance;
    this.bullets = this.bullets.filter(bullet => {
      const old = bullet.d; bullet.d += bullet.speed * dt;
      bullet.x += (bullet.slope || 0) * bullet.speed * dt;
      bullet.y = (bullet.originY ?? .5) + (bullet.ySlope || 0) * (bullet.d - (bullet.originD ?? old));
      if (bullet.d > base + 58 || this.time - bullet.born > 1.2) return false;
      let hit = null;
      const consider = (kind, item, halfWidth) => {
        if (item.d >= old - 0.1 && item.d <= bullet.d + 0.1 && Math.abs(item.x - (bullet.x - (bullet.slope || 0) * (bullet.d - item.d))) < halfWidth && (!hit || item.d < hit.item.d)) hit = { kind, item };
      };
      for (const g of this.level.gates) if (g.state === 'sealed') consider('gate', g, g.width / 2);
      for (const b of this.level.bosses) if (b.hp > 0) consider('boss', b, b.size * 0.70);
      for (let i = this.enemyStart; i < this.level.enemies.length; i++) {
        const e = this.level.enemies[i]; if (e.d > bullet.d + 0.1) break;
        if (e.hp > 0) consider('enemy', e, 0.19);
      }
      if (!hit) return true;
      if (hit.kind === 'gate') this.hitGate(hit.item, bullet.damage);
      else if (hit.kind === 'boss') this.hitBoss(hit.item, bullet.damage);
      else { hit.item.hp -= bullet.damage; if (hit.item.hp <= 0) { hit.item.hp = 0.001; this.killEnemy(hit.item); } }
      this.emit('impact', { x: bullet.x, d: hit.item.d, kind: hit.kind }); return false;
    });
  }
  updatePickups(dt) {
    const p = this.player; p.charging = false;
    const cells = this.level.cells;
    while (this.cellStart < cells.length && cells[this.cellStart].d < this.distance - 1.5) this.cellStart++;
    for (let i = this.cellStart; i < cells.length; i++) {
      const cell = cells[i]; if (cell.d > this.distance + 0.65) break;
      if (cell.taken || Math.abs(cell.x - p.x) > (cell.kind === 'blue' ? 0.78 : 1.1)) continue;
      if (cell.kind === 'gold' && this.level.gates[2].state === 'sealed') continue;
      cell.taken = true; this.stats.cells++; this.stats.score += cell.kind === 'blue' ? 3 : 50;
      p.energy = Math.min(CONFIG.energyMax, p.energy + (cell.kind === 'gold' ? 99 : 1));
      if (cell.kind === 'gold') p.boost = 8;
      p.charging = true;
      this.emit('cell', { x: cell.x, d: cell.d, gold: cell.kind === 'gold', full: p.energy === CONFIG.energyMax });
    }
    if (Math.abs(p.x) < 0.8 && this.distance >= 14 && this.distance < this.level.chapter.length + 28) p.charging = true;
    for (const gate of this.level.gates) {
      gate.flash = Math.max(0, gate.flash - dt);
      if (gate.state === 'taken' || gate.state === 'missed' || gate.d > this.distance + 0.70) continue;
      if (Math.abs(gate.x - p.x) < gate.width / 2 + 0.14 && Math.abs(gate.d - this.distance) < 0.8) {
        if (gate.state === 'open') {
          gate.state = 'taken';
          if(gate.reward==='energy'){
            p.energy=CONFIG.energyMax;p.boost=8;this.stats.score+=990;
            this.emit('overcharge',{x:gate.x,value:99});continue;
          }
          const gain = Math.min(CONFIG.maxTroops - p.troops, gate.value);
          p.troops += gain; p.x=clamp(p.x,-squadLimit(p.troops),squadLimit(p.troops));p.targetX=clamp(p.targetX,-squadLimit(p.troops),squadLimit(p.troops));this.stats.recruits += gain; this.stats.score += gain * 20;
          this.emit('recruit', { x: gate.x, value: gain });
        } else if (gate.state === 'sealed') {
          gate.state = 'missed'; this.damagePlayer(gate.value === 1 ? 1 : Math.max(1, Math.ceil(p.troops * 0.25)), gate.x);
        }
      }
      if (gate.d < this.distance - 1.2 && !['taken', 'missed'].includes(gate.state)) { gate.state = 'missed'; this.emit('missed-gate', { value: gate.value }); }
    }
  }
  updateBosses(dt) {
    const p = this.player;
    for (const boss of this.level.bosses) {
      boss.hitFlash = Math.max(0, boss.hitFlash - dt);
      if (boss.hp <= 0) continue;
      if(boss.type==='brute'&&boss.d-this.distance<12)boss.d=this.distance+12;
      const gap = boss.d - this.distance;
      if (gap < 27 && boss.type === 'titan' && !this.finalArena) {
        this.finalArena = true; boss.phase = 'arena'; this.emit('arena', { hp: boss.hp });
      }
      if (boss.phase === 'arena') {
        // The titan steps into a readable fighting distance rather than freezing above the screen.
        boss.d+=clamp(this.distance+16-boss.d,-dt*6,dt*6);
        boss.x += (-3.13-boss.x)*Math.min(1,dt*1.5);
      }
      if (gap < 30) {
        boss.attackTimer -= dt;
        if (boss.attackTimer <= 0 && !boss.warning) {
          boss.warning = { x: clamp(p.x, -3.7, 3.7), remaining: 1.65, total: 1.65, width: boss.type === 'titan' ? 1.7 : 1.4 };
          this.emit('warning', { x: boss.warning.x, bossType: boss.type });
        }
        if (boss.warning) {
          boss.warning.remaining -= dt;
          if (boss.warning.remaining <= 0) {
            boss.slamAt = this.time;
            this.emit('slam', { x: boss.warning.x, d: this.distance });
            if (Math.abs(p.x - boss.warning.x) < boss.warning.width / 2 + this.width * 0.35) this.damagePlayer(boss.type==='titan'?p.troops:Math.max(1,Math.ceil(p.troops*.16)),p.x);
            boss.warning = null; boss.attackTimer = boss.type === 'titan' ? 3.8 : 4.8;
          }
        }
      }
      if (gap < 1.3 && Math.abs(p.x - boss.x) < boss.size * 0.75 + this.width) this.damagePlayer(Math.max(1, Math.ceil(p.troops * 0.35)));
    }
    if (this.finalArena) {
      this.arenaClock += dt;
      // At a locked arena, the centre lane acts as a live charge station.
      if (Math.abs(p.x) < 0.75) { p.energy = Math.min(CONFIG.energyMax, p.energy + dt * 6.8); p.charging = true; }
      if (this.arenaClock > 80) { this.damagePlayer(Math.max(1, p.troops)); }
    }
  }
  autoPilot() {
    const p = this.player; const titan = this.level.bosses[1];
    const closePickup=this.level.gates.find(g=>g.state==='open'&&g.d-this.distance<4.5&&g.d-this.distance>-.65);
    if(closePickup){this.aim(closePickup.x);return;}
    const imminent = this.level.bosses.find(b => b.warning && b.warning.remaining < 1.25);
    if (imminent) { this.aim(Math.abs(imminent.warning.x) > 1.5 ? 0 : 3.18); return; }
    if (this.finalArena && titan.hp > 0) {
      if (p.energy < CONFIG.energyMax * .19) this.nextAutoAction = 'charge';
      if (p.energy > CONFIG.energyMax * .90) this.nextAutoAction = 'attack';
      this.aim(this.nextAutoAction === 'charge' ? 0 : (titan.x < 0 ? -3.12 : 3.12)); return;
    }
    const [a,b,c]=this.level.gates;
    if(this.time<6.1){this.aim(0);return;}
    const gate=(this.time>12.8&&!['taken','missed'].includes(b.state))?b:
      ((this.time>28&&!['taken','missed'].includes(c.state))?c:null);
    if(gate){
      // Refill when depleted rather than holding an empty weapon against a high-HP barrier.
      if(gate.state==='sealed'&&p.energy<.5&&gate.hp>70)this.nextAutoAction='charge';
      if(p.energy>CONFIG.energyMax*.9||gate.state==='open'||gate.hp<70)this.nextAutoAction='attack';
      this.aim(this.nextAutoAction==='charge'?0:gate.x);return;
    }
    if(p.energy<CONFIG.energyMax*.19)this.nextAutoAction='charge';
    if(p.energy>CONFIG.energyMax*.93)this.nextAutoAction='attack';
    this.aim(this.nextAutoAction==='charge'?0:-3.12);
  }

  step(dt = CONFIG.step) {
    if (this.phase !== 'playing') return;
    if (!(dt > 0) || !Number.isFinite(dt)) return;
    dt = Math.min(dt, 0.05); this.time += dt;
    if (this.demo) this.autoPilot();
    const p = this.player; const previousLaser = p.laser;
    p.targetX=clamp(p.targetX,-squadLimit(p.troops),squadLimit(p.troops));
    p.x += clamp(p.targetX - p.x, -10 * dt, 10 * dt);
    p.invincible = Math.max(0, p.invincible - dt); p.boost = Math.max(0, p.boost - dt);
    this.comboTimer -= dt; if (this.comboTimer <= 0) this.combo = 0;
    const aliveTitan = this.level.bosses[1].hp > 0;
    const stop = this.finalArena && aliveTitan;
    const advance=stop?0:this.level.chapter.speed*dt;
    this.distance+=advance;updateRails(this,dt,advance);
    // A slower relative assault conveyor preserves the readable opening gap.
    // All d positions (including corpses) move equally, preserving sorted order.
    if(advance>0)for(const enemy of this.level.enemies)enemy.d+=advance*.64;
    this.updatePickups(dt);
    if(this.phase!=='playing')return;
    this.updateBosses(dt);
    if(this.phase!=='playing')return;
    p.laser = Math.abs(p.x) > 0.95 && p.energy > 0.05;
    if (p.laser) {
      p.energy = Math.max(0, p.energy - CONFIG.laserDrain * dt); this.stats.laserSeconds += dt;
      this.updateLaser(dt);
    } else { p.damageBudget = 0; this.beams = []; this.fireBullets(dt); this.beam.hit = false; }
    if (p.energy < .05) p.energy = 0;
    if (p.laser && !previousLaser) this.emit('laser-on');
    if (!p.laser && previousLaser) this.emit('laser-off');
    this.updateBullets(dt);
    const enemies = this.level.enemies;
    while (this.enemyStart < enemies.length && enemies[this.enemyStart].d < this.distance - 2) this.enemyStart++;
    for (let i = this.enemyStart; i < enemies.length; i++) {
      const e = enemies[i]; if (e.d > this.distance + 0.65) break;
      if (e.hp > 0 && Math.abs(e.x - p.x) < this.width) {
        this.killEnemy(e);
        if(!p.laser){
          if(p.energy>1)p.energy=Math.max(0,p.energy-.055);
          else this.damagePlayer(Math.max(1,Math.ceil(p.troops*.08)),p.x);
        }
        if(this.phase!=='playing')break;
      }
    }
    if (this.phase === 'playing' && this.distance >= this.level.chapter.length && this.level.bosses.every(b=>b.hp<=0)) {
      this.phase = 'victory'; p.laser = false; this.stats.score += p.troops * 60; this.emit('victory');
    }
  }
  snapshot() {
    return { phase: this.phase, chapter: this.level.index, time: +this.time.toFixed(3), distance: +this.distance.toFixed(3),
      player: { ...this.player }, stats: { ...this.stats }, enemies: this.level.enemies.length,
      alive: this.level.enemies.filter(e => e.hp > 0).length, gates: this.level.gates.map(g => ({ state: g.state, hp: +g.hp.toFixed(2), value: g.value })),
      bosses: this.level.bosses.map(b => ({ hp: +b.hp.toFixed(2), maxHp: b.maxHp, phase: b.phase })), finalArena: this.finalArena,
      bullets: this.bullets.length, events: this.events.length, beam: { ...this.beam }, beamCount: this.beams.length };
  }
}
