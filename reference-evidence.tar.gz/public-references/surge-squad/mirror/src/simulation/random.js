/** A serializable xorshift32 RNG. Rendering uses a different stream. */
export class Random {
  constructor(seed = 0x51A7E) { this.state = (seed >>> 0) || 1; }
  next() { let x = this.state; x ^= x << 13; x ^= x >>> 17; x ^= x << 5; this.state = x >>> 0; return this.state / 4294967296; }
  range(a, b) { return a + (b - a) * this.next(); }
}
