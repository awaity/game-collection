import { CONFIG, formation } from './config.js';
import { weaponSocket, rayX, targetHeight } from './pose.js';

/** Nearest forward intersection in the sorted simulation corridor.
 * A sealed crate, a living giant, and a living raider all block the ray.
 * Plasma splash affects only the first contacted row, never eight metres behind it. */
export function traceRay(game, socket, radius = .19, range = CONFIG.attackRange, enemyRadius = radius) {
  const end = game.distance + range;
  let nearest = null;
  const test = (kind, item, width) => {
    if (item.d < socket.d - .1 || item.d > end || (nearest && item.d >= nearest.d)) return;
    const x = rayX(socket, item.d);
    if (Math.abs(item.x - x) <= width + radius) nearest = { kind, item, d: item.d, x, y: targetHeight(kind, item) };
  };
  for (const g of game.level.gates) if (g.state === 'sealed') test('gate', g, g.width / 2);
  for (const b of game.level.bosses) if (b.hp > 0) test('boss', b, b.size * .67);
  for (let i = game.enemyStart; i < game.level.enemies.length; i++) {
    const e = game.level.enemies[i];
    if (e.d > end || (nearest && e.d > nearest.d)) break;
    if (e.hp > 0) test('enemy', e, .14 * (e.size || 1) + enemyRadius - radius);
  }
  return nearest;
}

export function updatePlasma(game, dt) {
  const p = game.player, slots = formation(p.troops), units = Math.min(24, p.troops);
  const boost = p.boost > 0 ? 1.45 : 1;
  p.damageBudget = Math.min(p.damageBudget + (72 + units * 82) * dt * boost, 120);
  game.beams = [];
  for (let index = 0; index < slots.length; index++) {
    const origin = weaponSocket(p, slots[index], index, game.time, game.distance);
    // Plasma has a visible conductive fan around its narrow luminous core.
    // Enemy-only acquisition prevents stray edge islands; solid barriers still
    // use the actual narrow beam and stop propagation before the next row.
    const hit = traceRay(game, origin, .24, CONFIG.attackRange, 1.60);
    const endD = hit ? hit.d : game.distance + 43;
    const beam = { index, origin, d: endD, x: rayX(origin, endD), y: hit ? hit.y : origin.y,
      distance: endD - game.distance, hit: !!hit, kind: hit?.kind || 'empty', targetId: hit?.item.id ?? null };
    game.beams.push(beam);
    if (!hit) continue;
    if (hit.kind === 'gate') {
      game.hitGate(hit.item, (28 + units * 15) * dt * boost * 2.25 / slots.length);
    } else if (hit.kind === 'boss') {
      game.hitBoss(hit.item, (84 + units * 40) * dt * boost / slots.length);
    } else {
      const arcs = [];
      // A visible impact fan connects the contacted row. Damage never tunnels
      // through a living blocker; penetrating into the next row needs a new tick.
      for (let i = game.enemyStart; i < game.level.enemies.length; i++) {
        const e = game.level.enemies[i];
        if (e.d > hit.d + .54) break;
        if (e.hp <= 0 || e.d < hit.d - .54 || Math.abs(e.x - hit.x) > 2.35) continue;
        if (p.damageBudget <= 0) break;
        const damage = Math.min(e.hp, p.damageBudget);
        p.damageBudget -= damage; e.hp -= damage;
        if (e.hp <= 0) { e.hp = .001; game.killEnemy(e); }
        if (arcs.length < 6) arcs.push({ x: e.x, d: e.d, y: .38 * (e.size || 1) });
      }
      if (arcs.length && game.time - (game.lastArcAt || -1) > .075) {
        game.emit('plasma-impact', { x: hit.x, d: hit.d, y: hit.y, arcs });
        game.lastArcAt = game.time;
      }
    }
  }
  const first = game.beams.reduce((a, b) => b.hit && (!a || b.distance < a.distance) ? b : a, null);
  game.beam = { distance: first?.distance ?? 43, hit: !!first, kind: first?.kind || 'empty' };
}
