/** Fraction-preserving fixed-step clock; independent from the browser and renderer. */
export class StepClock {
  constructor(step=1/60){if(!(step>0)||!Number.isFinite(step))throw new RangeError('Invalid step');this.step=step;this.remainder=0;}
  reset(){this.remainder=0;}
  consume(milliseconds){
    if(!Number.isFinite(milliseconds)||milliseconds<0||milliseconds>180000)throw new RangeError('Expected 0–180000 ms');
    const total=this.remainder+milliseconds/1000;
    const count=Math.floor((total+1e-10)/this.step);
    this.remainder=Math.max(0,total-count*this.step);
    return count;
  }
}
