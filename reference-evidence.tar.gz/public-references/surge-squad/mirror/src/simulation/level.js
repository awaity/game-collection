import { CONFIG, CHAPTERS } from './config.js';
import { Random } from './random.js';
export function makeLevel(index = 0, seed = 17429) {
  const chapter = CHAPTERS[index];
  if (!chapter) throw new RangeError('Unknown chapter');
  const rng = new Random(seed + index * 9781); const enemies = [];
  let id = 1;
  for (let d = 18; d < chapter.length + 28; d += 0.48) {
    for (let col = 0; col < chapter.density; col++) {
      const x = -4.70 + col * (3.06 / (chapter.density - 1)) + rng.range(-0.075, 0.075);
      const at = d + rng.range(-0.12, 0.12);
      // Small clearings around the two larger silhouettes keep the bosses legible.
      if (chapter.bossDistance.some(b => Math.abs(at - b) < 1.6 && Math.abs(x + 3.1) < 0.9)) continue;
      enemies.push({ id: id++, x, d: at, hp: chapter.enemyHp, maxHp: chapter.enemyHp,
        phase: rng.next() * Math.PI * 2, size: rng.range(0.93, 1.10), deadAt: -1, variant: Math.floor(rng.next() * 3) });
    }
  }
  enemies.sort((a, b) => a.d - b.d);
  const gates = [
    { id: 'gate-1', x: 0, d: 11, value: 1, width: 1.48 },
    { id: 'gate-5', x: 3.18, d: 11, value: 5, width: 3.18 },
    { id: 'gate-99', x: 3.18, d: 18, value: 99, width: 3.18, reward:'energy' },
  ].map((g, i) => ({ ...g, hp: chapter.gateHp[i], maxHp: chapter.gateHp[i], state: 'sealed', flash: 0, openedAt: -1 }));
  const cells = [];
  for (let d = 11.8; d < chapter.length + 300; d += CONFIG.cellSpacing) cells.push({ d, x: 0, kind: 'blue', taken: false });
  for (let d = 23; d < chapter.length + 300; d += 4.2) cells.push({ d, x: 3.18, kind: 'gold', taken: false });
  cells.sort((a, b) => a.d - b.d);
  const bosses = chapter.bossDistance.map((d, i) => ({ id: `boss-${i}`, x: -3.13, d,
    hp: chapter.bossHp[i], maxHp: chapter.bossHp[i], type: i === 0 ? 'brute' : 'titan',
    deadAt: -1, hitFlash: 0, attackTimer: i===0?4.8:2.4, warning: null, slamAt: -100, phase: 'march',
    size: i === 0 ? 1.32 : 1.80 }));
  return { chapter, enemies, gates, cells, bosses, seed, index };
}
