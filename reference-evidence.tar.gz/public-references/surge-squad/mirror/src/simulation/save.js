const KEY='surge-squad.save.v1';
export function defaultSave(){return {version:1,unlocked:1,best:[0,0,0],settings:{sound:true,music:true,quality:'high',reducedMotion:false}};}
export function readSave(storage){
  const base=defaultSave();try{
    const raw=JSON.parse(storage?.getItem(KEY)||'null');if(!raw||raw.version!==1)return base;
    base.unlocked=Number.isInteger(raw.unlocked)?Math.max(1,Math.min(3,raw.unlocked)):1;
    base.best=base.best.map((_,i)=>Number.isFinite(raw.best?.[i])?Math.max(0,Math.floor(raw.best[i])):0);
    for(const k of ['sound','music','reducedMotion'])if(typeof raw.settings?.[k]==='boolean')base.settings[k]=raw.settings[k];
    if(['low','medium','high'].includes(raw.settings?.quality))base.settings.quality=raw.settings.quality;
  }catch{/* Corrupt saves or storage restrictions must never prevent playing. */}return base;
}
export function writeSave(storage,save){try{if(typeof storage?.setItem!=='function')return false;storage.setItem(KEY,JSON.stringify(save));return true;}catch{return false;}}
export function recordVictory(save,chapter,score){if(!Number.isInteger(chapter)||chapter<0||chapter>2||!Number.isFinite(score))return save;return {...save,unlocked:Math.max(save.unlocked,Math.min(3,chapter+2)),best:save.best.map((n,i)=>i===chapter?Math.max(n,Math.max(0,Math.floor(score))):n)};}
