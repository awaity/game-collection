/** All distances are in world metres. Gameplay never depends on render quality. */
export const CONFIG = Object.freeze({
  step: 1 / 60, speed: 3.35, roadWidth: 10.8, playerLimit: 4.35,
  playerZ: 6, depthScale: 0.55, viewDistance: 160, attackRange: 48,
  energyMax: 12, laserDrain: 3.9, cellSpacing: 0.80,
  maxTroops: 150, maxVisibleTroops: 20, maxBullets: 180,
  maxParticles: 700, maxCrowdVisible: 3600,
  lanes: Object.freeze({ assault: -3.12, charge: 0, recruit: 3.18 }),
});
export const CHAPTERS = Object.freeze([
  { name: '破晓海堤', english: 'BREAKWATER', length: 165, speed: 3.35, density: 13, enemyHp: 1,
    bossHp: [599, 1699], bossDistance: [70, 143], gateHp: [26, 130, 440], tint: 0 },
  { name: '赤潮防线', english: 'RED TIDE', length: 185, speed: 3.55, density: 14, enemyHp: 1.15,
    bossHp: [899, 2499], bossDistance: [76, 164], gateHp: [30, 160, 500], tint: 1 },
  { name: '最后电站', english: 'LAST CURRENT', length: 205, speed: 3.75, density: 15, enemyHp: 1.3,
    bossHp: [1299, 3499], bossDistance: [83, 185], gateHp: [34, 190, 580], tint: 2 },
]);
export function clamp(value, min, max) { return Math.max(min, Math.min(max, value)); }
export function visibleTroops(count) { return Math.min(CONFIG.maxVisibleTroops, Math.max(0, count)); }
export function formation(count) {
  const n = visibleTroops(count);
  if (n === 1) return [{ x: 0, z: 0 }];
  if (n === 2) return [{ x: -0.44, z: 0 }, { x: 0.44, z: 0 }];
  if (n <= 4) return Array.from({ length: n }, (_, i) => ({ x: (i - (n - 1) / 2) * 0.84, z: 0 }));
  const columns = n < 10 ? 4 : n < 16 ? 5 : 6;
  const rows = Math.ceil(n / columns); const result = [];
  let remaining = n;
  for (let row = 0; row < rows; row++) {
    const inRow = row === 0 ? n - (rows - 1) * columns : columns;
    for (let col = 0; col < inRow; col++) result.push({
      x: (col - (inRow - 1) / 2) * (n < 10 ? 0.86 : 0.65), z: row * 0.76 - (rows - 1) * 0.38,
    });
    remaining -= inRow;
  }
  return result;
}

export function squadLimit(count) {
  const f=formation(count);const extent=Math.max(0,...f.map(s=>Math.abs(s.x)));
  return Math.min(CONFIG.playerLimit,CONFIG.roadWidth/2-.62-extent);
}
