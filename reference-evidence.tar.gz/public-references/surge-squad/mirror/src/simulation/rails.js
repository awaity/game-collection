import { clamp } from './config.js';
/** The reference shows the recruit and gold gates together while charging.
 * These right-lane gates wait on a staged conveyor; a broken token advances
 * toward the player. This is a chosen playable rule, not inferred source code. */
export function updateRails(game, dt, advance) {
  const [first,recruit,gold]=game.level.gates;
  for(const gate of [recruit,gold]) {
    if(gate.state==='sealed') {
      gate.d+=advance;
      const target=gate===recruit?11:(recruit.state==='taken'||recruit.state==='missed'?11:18);
      const gap=gate.d-game.distance;
      gate.d+=clamp(target-gap,-dt*5,dt*5);
    } else if(gate.state==='open')gate.d-=dt*3.6;
  }
  // The cell conveyor remains behind its locked access gate. Once opened it scrolls normally.
  if(gold.state==='sealed'){
    const desired=gold.d+5;
    const cells=game.level.cells.filter(c=>c.kind==='gold'&&!c.taken);
    if(cells.length){const delta=desired-cells[0].d;for(const cell of cells)cell.d+=delta;}
  }
  game.level.cells.sort((a,b)=>a.d-b.d);
  // Sorting a moving conveyor invalidates the previous sorted-window cursor.
  game.cellStart=0;
}
