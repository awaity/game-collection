import { CONFIG, clamp } from './config.js';

/** Model-space socket contract. Shared by simulation, actor meshes and every effect.
 * The weapon is authored at (.255, .489, -.622); +Y up, forward -Z.
 * This module deliberately has no Three.js or browser dependency. */
export const PLAYER_SCALE = 1.24;
export const GUN_SOCKET = Object.freeze({ x: .255, y: .489, z: -.622 });
export function playerPose(player, slot, index, time, moving = true) {
  const bob = moving ? Math.sin(time * 12 + index * 2) * .025 : Math.sin(time * 2 + index) * .008;
  const lean = clamp((player.targetX - player.x) * .10, -.10, .10);
  return { x: player.x + slot.x, y: .04 + bob, z: CONFIG.playerZ + slot.z,
    scale: PLAYER_SCALE, yaw: -lean * .6, roll: -lean };
}
export function transformSocket(pose, socket = GUN_SOCKET) {
  const c = Math.cos(pose.roll), s = Math.sin(pose.roll);
  const x = (socket.x * c - socket.y * s) * pose.scale;
  const y = (socket.x * s + socket.y * c) * pose.scale;
  const z = socket.z * pose.scale;
  const cy = Math.cos(pose.yaw), sy = Math.sin(pose.yaw);
  return { x: pose.x + x * cy + z * sy, y: pose.y + y, z: pose.z - x * sy + z * cy };
}
export function weaponSocket(player, slot, index, time, distance) {
  const pose = playerPose(player, slot, index, time);
  const origin = transformSocket(pose);
  return { ...origin, d: distance + (CONFIG.playerZ - origin.z) / CONFIG.depthScale,
    slope: Math.tan(-pose.yaw) * CONFIG.depthScale };
}
export function rayX(socket, distance) { return socket.x + socket.slope * (distance - socket.d); }
export function targetHeight(kind, item) {
  if (kind === 'boss') return .88 * item.size;
  if (kind === 'gate') return item.value === 1 ? .54 : 1.16;
  return .38 * (item.size || 1);
}
