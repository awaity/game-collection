import { CONFIG, formation } from '../simulation/config.js';
import { playerPose, transformSocket } from '../simulation/pose.js';
import { trackZ } from './track.js';
import { glowTexture } from './materials.js';
const T = globalThis.THREE;
function batch(scene, geometry, material, capacity) {
  const mesh = new T.InstancedMesh(geometry, material, capacity);
  mesh.count = 0; mesh.frustumCulled = false; mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
  scene.add(mesh); return mesh;
}
/** Each ribbon follows one simulation ray and terminates at its own blocker.
 * All ribbons, flares, capacitor orbs and arcs use fixed-capacity GPU batches. */
export class LaserSystem {
  constructor(scene, camera) {
    this.camera = camera; this.dummy = new T.Object3D(); this.color = new T.Color();
    this.axis = new T.Vector3(0, 1, 0); this.direction = new T.Vector3();
    this.uniforms = { uTime: { value: 0 } };
    const vertex = `varying vec2 vUv;varying float vSeed;
      void main(){vUv=uv;vSeed=instanceMatrix[3].x*4.7;
        gl_Position=projectionMatrix*modelViewMatrix*instanceMatrix*vec4(position,1.);}`;
    const material = new T.ShaderMaterial({ uniforms: this.uniforms, vertexShader: vertex, fragmentShader: `
      varying vec2 vUv;varying float vSeed;uniform float uTime;
      void main(){float y=vUv.y;
        float wave=sin(y*39.-uTime*21.+vSeed)*.009+sin(y*91.+uTime*14.)*.003;
        float x=abs(vUv.x-.5+wave);
        float halo=exp(-x*x*22.);float body=exp(-x*x*50.);float core=exp(-x*x*800.);
        float helix=pow(max(0.,sin(vUv.x*60.+sin(y*44.-uTime*19.+vSeed)*1.7)),9.)*halo;
        float flow=.87+.13*sin(y*65.-uTime*37.+vSeed);
        float ends=smoothstep(0.,.035,y)*(1.-smoothstep(.975,1.,y));
        vec3 color=vec3(.006,.40,2.80)*halo+vec3(.018,2.30,4.7)*body*flow;
        color+=vec3(.045,3.3,4.7)*core+vec3(.015,.9,3.9)*helix;
        float plume=exp(-y*19.)*exp(-x*x*7.)*(.72+.28*sin(y*180.-uTime*31.+vSeed));
        color+=vec3(.004,1.05,3.10)*plume;
        gl_FragColor=vec4(color,clamp((halo*.21+body*.47+core*.27+helix*.20+plume*.35)*ends,0.,.94));
      }`, transparent: true, depthWrite: false, side: T.DoubleSide, blending: T.NormalBlending });
    this.ribbons = batch(scene, new T.PlaneGeometry(1, 1), material, CONFIG.maxVisibleTroops);
    this.ribbons.renderOrder = 5;
    const glow = glowTexture();
    this.origins = batch(scene, new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ map: glow,
      transparent: true, depthWrite: false, side: T.DoubleSide, blending: T.AdditiveBlending,
      opacity: .72 }), CONFIG.maxVisibleTroops * 3);
    this.origins.renderOrder = 7; this.origins.setColorAt(0, new T.Color(0xffffff));
    this.ground = batch(scene, new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ map: glow,
      transparent: true, depthWrite: false, side: T.DoubleSide, blending: T.AdditiveBlending,
      color: new T.Color(.01, .44, 1.12), opacity: .24 }), CONFIG.maxVisibleTroops);
    this.ground.renderOrder = 2;
    this.impacts = batch(scene, new T.PlaneGeometry(1, 1), new T.MeshBasicMaterial({ map: glow,
      transparent: true, depthWrite: false, side: T.DoubleSide, blending: T.AdditiveBlending,
      color: new T.Color(.035, 2.15, 3.2), opacity: .74 }), CONFIG.maxVisibleTroops);
    this.impacts.renderOrder = 6;
    const orbMaterial = new T.ShaderMaterial({ uniforms: this.uniforms, vertexShader: `
      varying vec3 vN,vE;void main(){vec4 p=modelViewMatrix*instanceMatrix*vec4(position,1.);
        vN=normalMatrix*mat3(instanceMatrix)*normal;vE=-p.xyz;gl_Position=projectionMatrix*p;}`,
      fragmentShader: `varying vec3 vN,vE;uniform float uTime;void main(){
        float rim=pow(1.-abs(dot(normalize(vN),normalize(vE))),2.3);
        vec3 c=mix(vec3(.004,1.28,1.60),vec3(.10,3.2,4.3),rim);
        gl_FragColor=vec4(c,.70+rim*.27);}`, transparent: true, depthWrite: false,
      blending: T.AdditiveBlending });
    this.orbs = batch(scene, new T.SphereGeometry(1, 12, 8), orbMaterial, CONFIG.maxVisibleTroops);
    this.orbs.renderOrder = 6;
    const geo = new T.BufferGeometry();
    this.arcVertices = new Float32Array(CONFIG.maxVisibleTroops * 24 * 6);
    geo.setAttribute('position', new T.BufferAttribute(this.arcVertices, 3).setUsage(T.DynamicDrawUsage));
    geo.setDrawRange(0, 0);
    this.arcs = new T.LineSegments(geo, new T.LineBasicMaterial({ color: new T.Color(.04, 1.70, 3.8),
      transparent: true, opacity: .72, blending: T.AdditiveBlending, depthWrite: false }));
    this.arcs.frustumCulled = false; this.arcs.renderOrder = 8; scene.add(this.arcs);
  }
  matrix(mesh, i, x, y, z, sx, sy, sz, face = false) {
    const d = this.dummy; d.position.set(x, y, z); d.scale.set(sx, sy, sz);
    if (face) d.quaternion.copy(this.camera.quaternion); else d.rotation.set(-Math.PI / 2, 0, 0);
    d.updateMatrix(); mesh.setMatrixAt(i, d.matrix);
  }
  beamMatrix(i, origin, endpoint, width) {
    const d = this.dummy;
    this.direction.set(endpoint.x - origin.x, endpoint.y - origin.y, endpoint.z - origin.z);
    const length = Math.max(.03, this.direction.length());
    d.position.set((origin.x + endpoint.x) / 2, (origin.y + endpoint.y) / 2, (origin.z + endpoint.z) / 2);
    d.quaternion.setFromUnitVectors(this.axis, this.direction.normalize());
    d.scale.set(width, length, 1); d.updateMatrix(); this.ribbons.setMatrixAt(i, d.matrix);
  }
  finish(mesh, n) { mesh.count = n; mesh.instanceMatrix.needsUpdate = true; if (mesh.instanceColor) mesh.instanceColor.needsUpdate = true; }
  update(dt, game, time) {
    this.uniforms.uTime.value = time;
    const p = game.player, slots = formation(p.troops), running = ['playing', 'paused'].includes(game.phase);
    const active = p.laser && running, charge = p.energy / CONFIG.energyMax;
    let rays = 0, glows = 0, grounds = 0, hits = 0, segments = 0, orbs = 0;
    for (let i = 0; i < slots.length; i++) {
      const pose = playerPose(p, slots[i], i, time, running), muzzle = transformSocket(pose);
      const { x, z } = pose;
      if (active) {
        // The aggregate endpoint fallback is for explicitly synthetic debug fixtures only.
        const path = game.beams[i];
        const endpoint = path ? { x: path.x, y: path.y, z: trackZ(path.distance) } :
          { x: muzzle.x, y: muzzle.y, z: trackZ(game.beam.distance) };
        this.beamMatrix(rays++, muzzle, endpoint, 1.15 + .05 * Math.sin(time * 27 + i));
        this.matrix(this.origins, glows, muzzle.x, muzzle.y, muzzle.z, 1.22, 1.52, 1, true);
        this.origins.setColorAt(glows++, this.color.setRGB(.013, 1.3, 2.8));
        if (path?.hit || (!path && game.beam.hit)) this.matrix(this.impacts, hits++, endpoint.x,
          endpoint.y, endpoint.z, 1.34, 1.50, 1, true);
      } else if (running && p.shotClock > .11) {
        const size = .29 + (p.shotClock - .11) * 4;
        this.matrix(this.origins, glows, muzzle.x, muzzle.y, muzzle.z, size, size * 1.3, 1, true);
        this.origins.setColorAt(glows++, this.color.setRGB(3.1, 1.45, .12));
      }
      if (charge > .03 && running) {
        const orbY = pose.y + 1.55, orbZ = z + .08;
        const orbScale = .11 + charge * .17;
        this.matrix(this.orbs, orbs++, x, orbY, orbZ, orbScale, orbScale, orbScale);
        this.matrix(this.origins, glows, x, orbY, orbZ, .38 + charge * .58, .42 + charge * .58, 1, true);
        this.origins.setColorAt(glows++, this.color.setRGB(.003, .72, 1.30));
        this.matrix(this.ground, grounds++, x, .044, z, .75 + charge * .52, .95 + charge * .4, 1);
        if (p.charging || charge > .87) {
          const radius = .38 + charge * .14;
          for (let j = 0; j < 20; j++) {
            const point = angle => {
              const n = Math.sin(angle * 5 + time * 21 + i) * .065;
              return [x + Math.cos(angle) * (radius + n), pose.y + 1.44 + Math.sin(angle) * .36,
                z + .10 + Math.sin(angle * 2 + time * 7 + i) * .16];
            };
            this.arcVertices.set([...point(j / 20 * Math.PI * 2), ...point((j + 1) / 20 * Math.PI * 2)], segments++ * 6);
          }
        }
      }
    }
    this.finish(this.ribbons, rays); this.finish(this.origins, glows); this.finish(this.ground, grounds);
    this.finish(this.impacts, hits); this.finish(this.orbs, orbs);
    this.arcs.geometry.setDrawRange(0, segments * 2); this.arcs.geometry.attributes.position.needsUpdate = true;
    return rays;
  }
  clear() { for (const m of [this.ribbons, this.origins, this.ground, this.impacts, this.orbs]) m.count = 0; this.arcs.geometry.setDrawRange(0, 0); }
}
