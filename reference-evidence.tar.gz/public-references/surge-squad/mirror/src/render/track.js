import { CONFIG } from '../simulation/config.js';
/** One linear metre-to-render transform, shared by collision feedback and every renderer. */
export function trackOffset(gap){return gap*CONFIG.depthScale;}
export function trackZ(gap){return CONFIG.playerZ-trackOffset(gap);}
export function trackScale(gap){return CONFIG.depthScale;}
export function bossScale(boss,gap){return boss.size;}
