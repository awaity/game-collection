const T = globalThis.THREE;
const vertex = 'varying vec2 vUv;void main(){vUv=uv;gl_Position=vec4(position.xy,0.,1.);}';
/** HDR -> half/quarter resolution bloom -> tone mapping + final FXAA.
 * Low really skips all three bloom passes. No screenshot readback during normal play. */
export class Post {
  constructor(renderer,width,height) {
    this.renderer=renderer;this.scene=new T.Scene();this.camera=new T.Camera();
    this.quad=new T.Mesh(new T.PlaneGeometry(2,2),null);this.quad.frustumCulled=false;this.scene.add(this.quad);
    this.hdr=renderer.capabilities.isWebGL2&&renderer.extensions.has('EXT_color_buffer_float');
    this.target=new T.WebGLRenderTarget(width,height,{type:this.hdr?T.HalfFloatType:T.UnsignedByteType,depthBuffer:true});
    this.a=new T.WebGLRenderTarget(Math.max(1,width>>2),Math.max(1,height>>2),{depthBuffer:false});this.b=this.a.clone();
    this.threshold=new T.ShaderMaterial({vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform sampler2D source;
      void main(){vec3 c=texture2D(source,vUv).rgb;float l=max(c.r,max(c.g,c.b));float k=clamp((l-.78)/.7,0.,1.);gl_FragColor=vec4(c*k*.44,1.);}`,
      uniforms:{source:{value:this.target.texture}},depthTest:false,depthWrite:false});
    this.blur=new T.ShaderMaterial({vertexShader:vertex,fragmentShader:`varying vec2 vUv;uniform sampler2D source;uniform vec2 dir;
      void main(){vec3 c=texture2D(source,vUv).rgb*.227027;
      c+=texture2D(source,vUv+dir*1.384615).rgb*.316216;c+=texture2D(source,vUv-dir*1.384615).rgb*.316216;
      c+=texture2D(source,vUv+dir*3.230769).rgb*.070270;c+=texture2D(source,vUv-dir*3.230769).rgb*.070270;gl_FragColor=vec4(c,1.);}`,
      uniforms:{source:{value:null},dir:{value:new T.Vector2()}},depthTest:false,depthWrite:false});
    this.output=new T.ShaderMaterial({vertexShader:vertex,fragmentShader:`
      varying vec2 vUv;uniform sampler2D source,bloom;uniform vec2 texel;uniform float strength,exposure;
      float luma(vec3 c){return dot(c/(vec3(1.)+max(c,vec3(0.))),vec3(.299,.587,.114));}
      void main(){
        // Detect edges in compressed HDR luminance, blend HDR taps, and run tone mapping ONCE.
        // The old combined pass repeated pow/tone mapping up to nine times per output pixel.
        vec3 c=texture2D(source,vUv).rgb;
        float l=luma(c),a=luma(texture2D(source,vUv+vec2(-1.,-1.)*texel).rgb),b=luma(texture2D(source,vUv+vec2(1.,-1.)*texel).rgb),
          d=luma(texture2D(source,vUv+vec2(-1.,1.)*texel).rgb),e=luma(texture2D(source,vUv+vec2(1.,1.)*texel).rgb);
        float lo=min(l,min(min(a,b),min(d,e))),hi=max(l,max(max(a,b),max(d,e)));
        if(hi-lo>max(.018,hi*.10)){
          vec2 dir=vec2(-((a+b)-(d+e)),(a+d)-(b+e));
          float reduce=max((a+b+d+e)*.03125,.0078125);
          dir=clamp(dir/(min(abs(dir.x),abs(dir.y))+reduce),vec2(-6.),vec2(6.))*texel;
          vec3 aa=.5*(texture2D(source,vUv+dir*(-1./6.)).rgb+texture2D(source,vUv+dir*(1./6.)).rgb);
          vec3 bb=aa*.5+.25*(texture2D(source,vUv+dir*-.5).rgb+texture2D(source,vUv+dir*.5).rgb);
          float lb=luma(bb);c=(lb<lo||lb>hi)?aa:bb;
        }
        if(strength>0.)c+=texture2D(bloom,vUv).rgb*strength;
        c*=exposure;c=clamp((c*(2.51*c+.03))/(c*(2.43*c+.59)+.14),0.,1.);
        gl_FragColor=vec4(pow(c,vec3(1./2.2)),1.);
      }`,uniforms:{source:{value:this.target.texture},bloom:{value:this.a.texture},texel:{value:new T.Vector2(1/width,1/height)},
      strength:{value:.72},exposure:{value:.84}},depthTest:false,depthWrite:false});
  }
  setQuality(quality){
    const samples=quality==='high'&&this.renderer.capabilities.isWebGL2?Math.min(4,this.renderer.capabilities.maxSamples):0;
    if(this.target.samples!==samples){this.target.dispose();this.target.samples=samples;}
    this.samples=samples;
  }
  resize(w,h,scale=1){const rw=Math.max(1,Math.round(w*scale)),rh=Math.max(1,Math.round(h*scale));this.target.setSize(rw,rh);this.a.setSize(Math.max(1,rw>>2),Math.max(1,rh>>2));this.b.setSize(Math.max(1,rw>>2),Math.max(1,rh>>2));this.output.uniforms.texel.value.set(1/rw,1/rh);}
  pass(material,target){this.quad.material=material;this.renderer.setRenderTarget(target);this.renderer.render(this.scene,this.camera);}
  render(scene,camera,quality){
    this.renderer.setRenderTarget(this.target);this.renderer.render(scene,camera);
    if(quality!=='low'){
      this.pass(this.threshold,this.a);this.blur.uniforms.source.value=this.a.texture;this.blur.uniforms.dir.value.set(1.10/this.a.width,0);this.pass(this.blur,this.b);
      this.blur.uniforms.source.value=this.b.texture;this.blur.uniforms.dir.value.set(0,1.10/this.a.height);this.pass(this.blur,this.a);
    }
    this.output.uniforms.strength.value=quality==='low'?0:quality==='medium'?.48:.65;
    this.passes=quality==='low'?2:5;this.pass(this.output,null);
  }
  dispose(){for(const p of [this.target,this.a,this.b,this.threshold,this.blur,this.output])p.dispose();this.quad.geometry.dispose();}
}
