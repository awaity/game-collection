import { trackZ, trackOffset, trackScale } from './track.js';
import { CONFIG } from '../simulation/config.js';
import { roundedBox } from '../assets/authoring.js';
import { lightningTexture, roadTexture, numberTexture, canvasTexture } from './materials.js';
const T=globalThis.THREE;
function instance(scene,geometry,material,capacity){const m=new T.InstancedMesh(geometry,material,capacity);m.instanceMatrix.setUsage(T.DynamicDrawUsage);m.frustumCulled=false;m.count=0;scene.add(m);return m;}
export class World {
  constructor(scene){
    this.scene=scene;this.dummy=new T.Object3D();this.gates=[];
    const roadMat=new T.MeshStandardMaterial({map:roadTexture(),color:0x85818c,roughness:.96,metalness:.03});
    this.road=new T.Mesh(new T.BoxGeometry(CONFIG.roadWidth,.75,280),roadMat);this.road.position.set(0,-.39,-90);this.road.receiveShadow=true;scene.add(this.road);
    const railMat=new T.MeshStandardMaterial({color:0x9da3b4,roughness:.55,metalness:.28});
    const darkMat=new T.MeshStandardMaterial({color:0x112664,roughness:.65,metalness:.06});
    for(const s of [-1,1]){
      const wall=new T.Mesh(roundedBox(.20,.36,280,.025,2),railMat);wall.position.set(s*5.38,.13,-90);wall.castShadow=true;wall.receiveShadow=true;scene.add(wall);
      const border=new T.Mesh(new T.BoxGeometry(.10,.03,280),new T.MeshStandardMaterial({color:0xd2d8e7,roughness:.4,metalness:.3}));border.position.set(s*5.22,.025,-90);scene.add(border);
    }
    const oceanMaterial=new T.ShaderMaterial({uniforms:{uTime:{value:0}},vertexShader:`varying vec3 vPos;void main(){vPos=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}`,fragmentShader:`varying vec3 vPos;uniform float uTime;void main(){float x=vPos.x,z=vPos.y;float w=sin(x*1.8+sin(z*.7+uTime*.18)*.7+uTime*.4)*sin(z*5.1-x*.2-uTime*.5);float q=pow(max(0.,w),9.);float n=sin(z*17.+x*.8)*sin(x*5.7+z*11.);vec3 c=mix(vec3(.006,.014,.030),vec3(.015,.036,.062),.5+.5*sin(z*.2+x*.07));c+=vec3(.003,.005,.009)*q;c+=n*.0015;gl_FragColor=vec4(c,1.);}`,side:T.DoubleSide});
    const ocean=new T.Mesh(new T.PlaneGeometry(1200,1200),oceanMaterial);ocean.rotation.x=-Math.PI/2;ocean.position.y=-1.8;scene.add(ocean);this.ocean=oceanMaterial;
    const blueMat=new T.MeshStandardMaterial({color:0x075cec,roughness:.35,metalness:.16});
    this.blueBody=instance(scene,roundedBox(1.50,.52,.74*CONFIG.depthScale,.09,4),blueMat,260);this.blueBody.castShadow=true;this.blueBody.receiveShadow=true;
    this.blueTop=instance(scene,new T.PlaneGeometry(1.40,.68*CONFIG.depthScale),new T.MeshStandardMaterial({map:lightningTexture(false),roughness:.34,metalness:.20,emissive:0x287ac5,emissiveIntensity:.13}),260);
    this.blueBase=instance(scene,roundedBox(1.54,.14,.81*CONFIG.depthScale,.025,2),darkMat,260);
    this.goldDeck=new T.Mesh(new T.BoxGeometry(3.25,.36,1),new T.MeshStandardMaterial({color:0x696974,roughness:.86}));
    this.goldDeck.castShadow=true;this.goldDeck.receiveShadow=true;scene.add(this.goldDeck);
    // Painted studio reflection: stylized cylindrical specular bands, no external HDRI.
    const goldRamp=canvasTexture((ctx,w,h)=>{
      const g=ctx.createLinearGradient(0,0,w,0);
      for(const [at,color] of [[0,'#d39708'],[.16,'#e7ac08'],[.29,'#ffe04d'],[.37,'#fff4b0'],[.43,'#ffdc29'],[.65,'#c89103'],[.78,'#e6ad07'],[.89,'#ffe354'],[1,'#d39708']])g.addColorStop(at,color);
      ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
    },256,8);
    const gold=new T.MeshStandardMaterial({map:goldRamp,color:0xffffff,roughness:.25,metalness:.02});
    this.goldBodies=instance(scene,new T.CylinderGeometry(.60,.60,2.75,24),gold,48);this.goldBodies.castShadow=true;this.goldBodies.receiveShadow=true;
    this.goldBand=instance(scene,new T.CylinderGeometry(.610,.610,1.58,24),new T.MeshStandardMaterial({map:goldRamp,color:0xf4d16c,roughness:.30,metalness:.03}),48);
    this.goldTop=instance(scene,new T.PlaneGeometry(1.50,.98),new T.MeshBasicMaterial({map:lightningTexture(true),transparent:true,depthWrite:false}),48);
    this.goldCaps=instance(scene,new T.CylinderGeometry(.64,.64,.22,24),new T.MeshStandardMaterial({color:0xf8c429,roughness:.29,metalness:.07}),96);
    this.cracks=canvasTexture((ctx,w,h)=>{
      ctx.clearRect(0,0,w,h);ctx.strokeStyle='rgba(16,27,39,.7)';ctx.lineWidth=7;ctx.lineCap='round';
      for(const pts of [[[.44,0],[.40,.22],[.54,.38],[.39,.57],[.49,.74],[.43,1]],[[.52,.38],[.70,.32],[.85,.45],[1,.43]],[[.4,.57],[.2,.51],[0,.62]]]){ctx.beginPath();pts.forEach(([x,y],i)=>i?ctx.lineTo(x*w,y*h):ctx.moveTo(x*w,y*h));ctx.stroke();}
    },256,256);
  }
  makeGates(game){
    for(const object of this.gates){object.group.removeFromParent();object.group.traverse(o=>{if(o.isMesh){if(o.material.map && o.material.map!==this.cracks)o.material.map.dispose();o.geometry.dispose();if(Array.isArray(o.material))o.material.forEach(m=>m.dispose());else o.material.dispose();}});}
    this.gates=[];
    for(const gate of game.level.gates){
      const group=new T.Group();const h=gate.value===1?1.00:2.18;const width=gate.width;
      const mat=new T.MeshStandardMaterial({color:0xededee,roughness:.80,metalness:.04});
      const box=new T.Mesh(roundedBox(width,h,1.24,.065,3),mat);box.position.y=h/2;box.castShadow=true;box.receiveShadow=true;group.add(box);
      const label=new T.Mesh(new T.PlaneGeometry(width*.94,h*.87),new T.MeshBasicMaterial({map:numberTexture(gate.value),polygonOffset:true,polygonOffsetFactor:-2}));label.position.set(0,h*.5,.626);group.add(label);
      const cracks=new T.Mesh(new T.PlaneGeometry(width*.95,h*.9),new T.MeshBasicMaterial({map:this.cracks,transparent:true,opacity:0,depthWrite:false}));cracks.position.set(0,h*.5,.64);group.add(cracks);
      const band=new T.Mesh(roundedBox(width*.96,.10,1.21,.02,2),new T.MeshStandardMaterial({color:gate.value===99?0xfbd829:0xd4dee8,roughness:.4,metalness:.3}));band.position.y=h+.01;group.add(band);
      const tokenMaterial=new T.MeshStandardMaterial({map:numberTexture(gate.value,gate.value===99?'gold':'open'),roughness:.5,metalness:.10,side:T.DoubleSide});
      const token=new T.Mesh(new T.BoxGeometry(gate.value===1?1.1:1.75,gate.value===1?.65:1.10,.13),tokenMaterial);token.position.set(0,.70,.06);token.castShadow=true;token.visible=false;group.add(token);
      this.scene.add(group);this.gates.push({group,box,label,band,cracks,token,mat,gate});
    }
  }
  set(mesh,i,x,y,z,sx=1,sy=1,sz=1,rx=0,ry=0,rz=0){const d=this.dummy;d.position.set(x,y,z);d.rotation.set(rx,ry,rz);d.scale.set(sx,sy,sz);d.updateMatrix();mesh.setMatrixAt(i,d.matrix);}
  finish(mesh,n){mesh.count=n;mesh.instanceMatrix.needsUpdate=true;}
  update(game,time,visibleDistance=CONFIG.viewDistance){
    this.ocean.uniforms.uTime.value=time;
    this.road.material.map.offset.y=-game.distance*CONFIG.depthScale/14;
    let blue=0,gold=0;let lastBlueZ=Infinity,lastGoldZ=Infinity;
    // Pickup cursor excludes passed cells. Rendering must NOT share that cursor:
    // uncollected batteries remain visible behind a side-lane squad.
    for(let i=0;i<game.level.cells.length;i++){
      const cell=game.level.cells[i],gap=cell.d-game.distance;if(gap>visibleDistance+12)break;
      if(gap<-28||cell.taken)continue;const z=trackZ(gap);
      if(cell.kind==='blue'&&blue<260){
        if(lastBlueZ-z<.435)continue;lastBlueZ=z;
        this.set(this.blueBase,blue,0,.065,z);
        this.set(this.blueBody,blue,0,.27,z);
        this.set(this.blueTop,blue,0,.541,z,1,1,1,-Math.PI/2);blue++;
      }else if(cell.kind==='gold'&&gold<48){
        if(lastGoldZ-z<1.30)continue;lastGoldZ=z;
        this.set(this.goldBodies,gold,3.18,.97,z,1,1,1,0,0,Math.PI/2);
        this.set(this.goldBand,gold,3.18,.97,z,1,1,1,0,0,Math.PI/2);
        this.set(this.goldTop,gold,3.18,1.573,z,.82,.73,1,-Math.PI/2);
        this.set(this.goldCaps,gold*2,3.18-1.4,.97,z,1,1,1,0,0,Math.PI/2);
        this.set(this.goldCaps,gold*2+1,3.18+1.4,.97,z,1,1,1,0,0,Math.PI/2);gold++;
      }
    }
    for(const mesh of [this.blueBody,this.blueTop,this.blueBase])this.finish(mesh,blue);
    for(const mesh of [this.goldBodies,this.goldBand,this.goldTop])this.finish(mesh,gold);this.finish(this.goldCaps,gold*2);
    const goldStart=game.level.cells.find(c=>c.kind==='gold');
    const deckFront=trackZ(Math.max(-12,goldStart.d-game.distance))+.85;
    const deckBack=trackZ(CONFIG.viewDistance+60);
    this.goldDeck.scale.z=Math.max(1,deckFront-deckBack);this.goldDeck.position.set(3.18,.18,(deckFront+deckBack)/2);
    for(const item of this.gates){
      const g=item.gate;item.group.position.set(g.x,0,trackZ(g.d-game.distance));
      item.group.visible=g.d-game.distance>-10&&!['taken','missed'].includes(g.state);
      const sealed=g.state==='sealed';item.box.visible=item.label.visible=item.band.visible=item.cracks.visible=sealed;item.token.visible=!sealed;
      item.mat.emissive.setHex(g.flash>0?0x384352:0x000000);item.cracks.material.opacity=Math.max(0,(1-g.hp/g.maxHp)*.9-.1);
      item.token.position.y=.76+Math.sin(time*4.2)*.08;
      if(g.state==='open')item.token.rotation.y=Math.sin(time*2)*.08;
    }
  }
}
