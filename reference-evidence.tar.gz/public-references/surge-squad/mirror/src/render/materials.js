const T = globalThis.THREE;
export function canvasTexture(draw, width = 256, height = 256) {
  const canvas = document.createElement('canvas'); canvas.width = width; canvas.height = height;
  const ctx = canvas.getContext('2d'); draw(ctx, width, height);
  const texture = new T.CanvasTexture(canvas); texture.encoding = T.sRGBEncoding;
  texture.anisotropy = 4; return texture;
}
export function glowTexture() {
  return canvasTexture((ctx,w,h)=>{
    const g=ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,w/2);
    g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.16,'rgba(255,255,255,.85)');g.addColorStop(.4,'rgba(255,255,255,.27)');g.addColorStop(1,'rgba(255,255,255,0)');
    ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  },128,128);
}
export function shadowTexture() {
  return canvasTexture((ctx,w,h)=>{
    const g=ctx.createRadialGradient(w/2,h/2,0,w/2,h/2,w/2);
    g.addColorStop(0,'rgba(4,10,23,.65)');g.addColorStop(.3,'rgba(4,10,23,.40)');g.addColorStop(.7,'rgba(4,10,23,.17)');g.addColorStop(1,'rgba(4,10,23,0)');ctx.fillStyle=g;ctx.fillRect(0,0,w,h);
  },96,96);
}
export function lightningTexture(gold = false) {
  return canvasTexture((ctx,w,h)=>{
    const g=ctx.createLinearGradient(0,0,w,h);g.addColorStop(0,gold?'#ffe57c':'#399aff');g.addColorStop(.45,gold?'#edb915':'#096ef0');g.addColorStop(1,gold?'#9b6710':'#0844c8');
    if(!gold){ctx.fillStyle=g;ctx.fillRect(0,0,w,h);}
    ctx.strokeStyle=gold?'rgba(255,240,161,.45)':'rgba(120,197,255,.5)';ctx.lineWidth=3;if(!gold)ctx.strokeRect(3,3,w-6,h-6);
    if(!gold){ctx.fillStyle='rgba(255,255,255,.13)';ctx.fillRect(15,15,w-30,h*.25);}
    ctx.shadowColor=gold?'#fffed5':'#b8ffff';ctx.shadowBlur=18;ctx.fillStyle='#fff';ctx.beginPath();
    ctx.moveTo(w*.53,h*.10);ctx.lineTo(w*.24,h*.54);ctx.lineTo(w*.45,h*.54);ctx.lineTo(w*.38,h*.9);ctx.lineTo(w*.79,h*.39);ctx.lineTo(w*.56,h*.39);ctx.closePath();ctx.fill();
  },128,128);
}
export function roadTexture() {
  let seed=9753; const rnd=()=>{seed=(1664525*seed+1013904223)>>>0;return seed/4294967296;};
  const tex=canvasTexture((ctx,w,h)=>{
    ctx.fillStyle='#9193a0';ctx.fillRect(0,0,w,h);
    const data=ctx.getImageData(0,0,w,h);
    for(let i=0;i<data.data.length;i+=4){const n=(rnd()-.5)*9;data.data[i]+=n;data.data[i+1]+=n;data.data[i+2]+=n;}
    ctx.putImageData(data,0,0);
    for(let i=0;i<70;i++){ctx.strokeStyle=`rgba(255,255,255,${rnd()*.015})`;ctx.beginPath();const y=rnd()*h;ctx.moveTo(0,y);ctx.lineTo(w,y);ctx.stroke();}
  },512,512);tex.wrapS=tex.wrapT=T.RepeatWrapping;tex.repeat.set(2,20);return tex;
}
export function numberTexture(value, style='sealed') {
  return canvasTexture((ctx,w,h)=>{
    ctx.clearRect(0,0,w,h);
    const fill=style==='sealed'?'#f4f3ef':style==='gold'?'#f0c629':'#188cdd';
    const grad=ctx.createLinearGradient(0,0,0,h);grad.addColorStop(0,style==='sealed'?'#fff':style==='gold'?'#ffe66e':'#4ac8ff');grad.addColorStop(1,fill);
    ctx.fillStyle=grad;ctx.fillRect(0,0,w,h);
    if(style!=='sealed'){ctx.strokeStyle=style==='gold'?'#fff0ac':'#d4fbff';ctx.lineWidth=12;ctx.strokeRect(7,7,w-14,h-14);}
    // Fit actual glyph bounds, not nominal font metrics. Browser font fallbacks
    // previously made +1 tiny while +99 filled the same face.
    ctx.font='900 260px Arial, sans-serif';ctx.textBaseline='alphabetic';
    const text='+'+value,measure=ctx.measureText(text);
    const left=measure.actualBoundingBoxLeft||0,right=measure.actualBoundingBoxRight||measure.width;
    const ascent=measure.actualBoundingBoxAscent||190,descent=measure.actualBoundingBoxDescent||4;
    const targetW=w*.84,targetH=h*.67;
    ctx.save();ctx.translate((w-targetW)/2,(h-targetH)/2);
    ctx.scale(targetW/(left+right),targetH/(ascent+descent));ctx.translate(left,ascent);
    ctx.lineJoin='round';ctx.lineWidth=style==='sealed'?13:17;
    ctx.strokeStyle=style==='sealed'?'#202022':'#173c58';ctx.strokeText(text,0,0);
    ctx.fillStyle=style==='sealed'?'#202022':'#fff';ctx.fillText(text,0,0);ctx.restore();
  },512,360);
}
export function textTexture(text, fill='#fff', size=96) {
  return canvasTexture((ctx,w,h)=>{ctx.textAlign='center';ctx.textBaseline='middle';ctx.font=`900 ${size}px Arial, sans-serif`;ctx.lineJoin='round';ctx.lineWidth=9;ctx.strokeStyle='rgba(12,25,40,.86)';ctx.strokeText(text,w/2,h/2);ctx.fillStyle=fill;ctx.fillText(text,w/2,h/2);},512,144);
}
/** Gait is a render-only vertex deformation. Custom depth receives the same deformation. */
export function animateMaterial(material, timeUniform, scale = 1, actionUniform = null) {
  const inject = shader => {
    shader.uniforms.uGaitTime=timeUniform;shader.uniforms.uBossAction=actionUniform||{value:0};
    shader.vertexShader='attribute float part;\nuniform float uGaitTime;\nuniform float uBossAction;\n'+shader.vertexShader;
    shader.vertexShader=shader.vertexShader.replace('#include <begin_vertex>', `
      vec3 transformed = vec3(position);
      float gaitPhase = uGaitTime * 11.0 + instanceMatrix[3].z * 2.1 + instanceMatrix[3].x * 3.4;
      float limb = sin(gaitPhase + (part == 2.0 || part == 3.0 ? 3.14159 : 0.0));
      if (part == 1.0 || part == 2.0) {
        float influence = clamp(1.0 - position.y / ${(.40*scale).toFixed(3)}, 0.0, 1.0);
        transformed.z += limb * ${(.09*scale).toFixed(3)} * influence;
        transformed.y += max(0.0, limb) * ${(.025*scale).toFixed(3)} * influence;
      }
      if (part == 3.0 || part == 4.0) {
        transformed.z += limb * ${(.025*scale).toFixed(3)};
        float side = part == 3.0 ? -1.0 : 1.0;
        float angle = side * uBossAction * 1.78;
        vec2 pivot=vec2(side*.53,1.20);vec2 arm=transformed.xy-pivot;
        transformed.xy=pivot+mat2(cos(angle),sin(angle),-sin(angle),cos(angle))*arm;
      }
    `);
    shader.vertexShader=shader.vertexShader.replace('#include <beginnormal_vertex>', `
      vec3 objectNormal = vec3(normal);
      #ifdef USE_TANGENT
      vec3 objectTangent = vec3(tangent.xyz);
      #endif
      if(part == 3.0 || part == 4.0){float side=part==3.0?-1.0:1.0;float a=side*uBossAction*1.78;objectNormal.xy=mat2(cos(a),sin(a),-sin(a),cos(a))*objectNormal.xy;}
    `);
  };
  material.onBeforeCompile=inject;
  material.customProgramCacheKey=()=>`surge-gait-${scale}`;
  const depth=new T.MeshDepthMaterial({depthPacking:T.RGBADepthPacking});depth.onBeforeCompile=inject;
  depth.customProgramCacheKey=()=>`surge-depth-${scale}`;return depth;
}
