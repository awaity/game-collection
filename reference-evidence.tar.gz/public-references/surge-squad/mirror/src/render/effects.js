import { ChargeFeedback } from './charge.js';
import { LaserSystem } from './laser.js';
import { trackZ, trackOffset, trackScale } from './track.js';
import { CONFIG, formation } from '../simulation/config.js';
import { Random } from '../simulation/random.js';
import { glowTexture, textTexture, canvasTexture } from './materials.js';
const T=globalThis.THREE;
export class Effects {
  constructor(scene,camera){
    this.scene=scene;this.camera=camera;this.rng=new Random(47192);this.parts=[];this.popups=[];this.rings=[];this.shake=0;this.flash=0;
    this.glow=glowTexture();this.dummy=new T.Object3D();this.particleColor=new T.Color();
    this.sparkMat=new T.MeshBasicMaterial({map:this.glow,transparent:true,depthWrite:false,blending:T.AdditiveBlending,color:0xffffff,side:T.DoubleSide});
    this.sparks=new T.InstancedMesh(new T.PlaneGeometry(1,1),this.sparkMat,CONFIG.maxParticles);this.sparks.count=0;this.sparks.instanceMatrix.setUsage(T.DynamicDrawUsage);this.sparks.frustumCulled=false;scene.add(this.sparks);
    this.debris=new T.InstancedMesh(new T.BoxGeometry(1,1,1),new T.MeshStandardMaterial({color:0xffffff,roughness:.70,metalness:.05}),220);this.debris.count=0;this.debris.instanceMatrix.setUsage(T.DynamicDrawUsage);this.debris.frustumCulled=false;this.debris.castShadow=true;scene.add(this.debris);
    // Allocate instance colors before shader compilation, including the zero-particle first frame.
    for(const m of [this.sparks,this.debris])m.setColorAt(0,new T.Color(0xffffff));
    this.laser=new LaserSystem(scene,camera);this.chargeFeedback=new ChargeFeedback(scene);
    this.bulletMesh=new T.InstancedMesh(new T.CylinderGeometry(.027,.055,1,5),new T.MeshBasicMaterial({color:new T.Color(3.5,1.7,.16)}),CONFIG.maxBullets);this.bulletMesh.count=0;this.bulletMesh.frustumCulled=false;scene.add(this.bulletMesh);
    this.bulletHeads=new T.InstancedMesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({map:this.glow,color:new T.Color(4,2.1,.25),transparent:true,depthWrite:false,blending:T.AdditiveBlending,side:T.DoubleSide}),CONFIG.maxBullets);this.bulletHeads.count=0;this.bulletHeads.frustumCulled=false;scene.add(this.bulletHeads);
    this.warningMeshes=[];this.warningMat=new T.MeshBasicMaterial({color:0xff3454,transparent:true,opacity:.23,depthWrite:false});
    for(let i=0;i<2;i++){
      const m=new T.Mesh(new T.PlaneGeometry(1,1),this.warningMat);m.rotation.x=-Math.PI/2;m.visible=false;scene.add(m);this.warningMeshes.push(m);
    }
    this.textCache=new Map();this.lastCellPop=-5;this.lastCharge=-5;this.lastImpact=-5;
  }
  particle(x,y,d,color,count=8,kind='spark',size=.20,force=1){
    for(let i=0;i<count;i++){
      if(this.parts.length>CONFIG.maxParticles-1)break;
      const r=this.rng;this.parts.push({x,y,d,vx:r.range(-2.7,2.7)*force,vy:r.range(1,5)*force,vd:r.range(-2.5,2.5)*force,
        life:r.range(.25,.80),maxLife:.8,size:r.range(.6,1.4)*size,color,kind,spin:r.range(-5,5)});
    }
  }
  popup(text,x,d,color='#fff',scale=1){
    if(this.popups.length>=24)return;
    const key=text+color;let texture=this.textCache.get(key);
    if(!texture){texture=textTexture(text,color,96);this.textCache.set(key,texture);}
    // Bound the cache: counters cannot create an unbounded number of GPU textures.
    if(this.textCache.size>90){for(const [old,tex] of this.textCache){if(old!==key&&!this.popups.some(p=>p.texture===tex)){tex.dispose();this.textCache.delete(old);}if(this.textCache.size<=90)break;}}
    const sprite=new T.Sprite(new T.SpriteMaterial({map:texture,transparent:true,depthWrite:false}));sprite.scale.set(2.5*scale,.7*scale,1);sprite.renderOrder=10;this.scene.add(sprite);this.popups.push({sprite,texture,x,d,y:1.5,life:1,maxLife:1});
  }
  ring(x,d,color=0x36dfff,max=3){
    if(this.rings.length>=20)return;
    const mesh=new T.Mesh(new T.RingGeometry(.86,1,48),new T.MeshBasicMaterial({color,transparent:true,opacity:.8,depthWrite:false,blending:T.AdditiveBlending,side:T.DoubleSide}));mesh.rotation.x=-Math.PI/2;this.scene.add(mesh);this.rings.push({mesh,x,d,life:.55,max});
  }
  event(ev,game){
    this.chargeFeedback.event(ev);
    const d=ev.d??game.distance;
    if(ev.type==='cell'){
      this.particle(ev.x,.60,d,ev.gold?0xffe253:0x4adaff,ev.gold?18:3,'spark',ev.gold?.30:.17,.55);
      if(game.time-this.lastCellPop>.28){this.popup(ev.gold?'+99':'+1',ev.x,d,ev.gold?'#ffe566':'#f7ee4e',ev.gold?.8:.5);this.lastCellPop=game.time;}
    }
    if(ev.type==='gate-break'){
      this.particle(ev.x,1,d,0xf1f2f4,40,'debris',.19,1.6);this.particle(ev.x,.9,d,0xe2f5ff,20,'spark',.25,1);this.shake=Math.max(this.shake,.12);this.ring(ev.x,d,0xe8f8ff,1.3);
    }
    if(ev.type==='recruit'||ev.type==='overcharge'){
      this.popup(`+${ev.value}`,ev.x,game.distance,'#fff17b',1.15);this.ring(ev.x,game.distance,0xffc63c,1.5);this.particle(ev.x,.5,game.distance,0xffe35d,30,'spark',.25,1.6);
    }
    if(ev.type==='enemy-down')this.particle(ev.x,.36,d,0xdf344e,2,'debris',.12,1.1);
    if(ev.type==='impact'&&game.time-this.lastImpact>.045){this.particle(ev.x,.75,d,0xffd95a,4,'spark',.14,1);this.lastImpact=game.time;}
    if(ev.type==='laser-on'){this.shake=Math.max(this.shake,.065);}
    if(ev.type==='boss-down'){
      this.particle(ev.x,1.2,d,0xf3889b,45,'debris',.20,2.4);this.particle(ev.x,1.5,d,0x60dcff,65,'spark',.35,2.2);this.ring(ev.x,d,0x87eeff,5);this.shake=.30;
      this.popup('击破',ev.x,d,'#fff1a6',1.2);
    }
    if(ev.type==='hurt'){this.shake=.34;this.flash=.4;this.popup(`−${ev.lost}`,ev.x,game.distance,'#ff7a83',.85);}
    if(ev.type==='slam'){this.ring(ev.x,d,0xff345c,3.3);this.particle(ev.x,.05,d,0xeb5365,30,'debris',.14,1.7);this.shake=.16;}
    if(ev.type==='victory'){this.particle(0,3,game.distance,0x45d7ff,90,'spark',.34,3.1);this.particle(0,3,game.distance,0xffd85d,90,'spark',.28,3.1);}
  }
  update(dt,game,time){
    this.shake=Math.max(0,this.shake-dt*.75);this.flash=Math.max(0,this.flash-dt);
    const beamCount=this.laser.update(dt,game,time);this.chargeFeedback.update(dt,game);
    let n=0;
    const dummy=this.dummy;
    for(const bullet of game.bullets){
      if(n>=CONFIG.maxBullets)break;
      const z=trackZ(bullet.d-game.distance),trail=Math.min(2.65,Math.max(.12,bullet.d-(bullet.originD??bullet.d-2.65)));
      const dx=(bullet.slope||0)*trail,dy=(bullet.ySlope||0)*trail,dz=-trail*CONFIG.depthScale;
      dummy.position.set(bullet.x-dx*.5,(bullet.y??.5)-dy*.5,z-dz*.5);
      this.trailDirection??=new T.Vector3();this.trailAxis??=new T.Vector3(0,1,0);
      this.trailDirection.set(dx,dy,dz);const length=this.trailDirection.length();
      dummy.quaternion.setFromUnitVectors(this.trailAxis,this.trailDirection.normalize());
      dummy.scale.set(1,length,1);dummy.updateMatrix();this.bulletMesh.setMatrixAt(n,dummy.matrix);
      dummy.position.set(bullet.x,bullet.y??.50,z);dummy.quaternion.copy(this.camera.quaternion);dummy.scale.setScalar(.35);dummy.updateMatrix();this.bulletHeads.setMatrixAt(n,dummy.matrix);n++;
    }
    this.bulletMesh.count=this.bulletHeads.count=n;this.bulletMesh.instanceMatrix.needsUpdate=this.bulletHeads.instanceMatrix.needsUpdate=true;
    let sparks=0,debris=0;const live=[];
    for(const part of this.parts){
      part.life-=dt;if(part.life<=0)continue;part.x+=part.vx*dt;part.y+=part.vy*dt;part.d+=part.vd*dt;part.vy-=dt*10;
      if(part.y<.045){part.y=.045;part.vy=Math.abs(part.vy)*.27;part.vx*=.9;part.vd*=.9;}
      const z=trackZ(part.d-game.distance);const s=part.size*Math.min(1,part.life*4);
      dummy.position.set(part.x,part.y,z);
      if(part.kind==='debris'&&debris<220){dummy.rotation.set(time*part.spin,time*part.spin*.7,part.spin);dummy.scale.setScalar(s);dummy.updateMatrix();this.debris.setMatrixAt(debris,dummy.matrix);this.debris.setColorAt(debris,this.particleColor.setHex(part.color));debris++;}
      else if(sparks<CONFIG.maxParticles){dummy.quaternion.copy(this.camera.quaternion);dummy.scale.setScalar(s*2);dummy.updateMatrix();this.sparks.setMatrixAt(sparks,dummy.matrix);this.sparks.setColorAt(sparks,this.particleColor.setHex(part.color).multiplyScalar(1.7));sparks++;}
      live.push(part);
    }
    this.parts=live;this.sparks.count=sparks;this.debris.count=debris;
    this.sparks.instanceMatrix.needsUpdate=this.debris.instanceMatrix.needsUpdate=true;
    if(this.sparks.instanceColor)this.sparks.instanceColor.needsUpdate=true;if(this.debris.instanceColor)this.debris.instanceColor.needsUpdate=true;
    this.popups=this.popups.filter(pop=>{pop.life-=dt;if(pop.life<=0){pop.sprite.removeFromParent();pop.sprite.material.dispose();return false;}pop.y+=dt*.95;pop.sprite.position.set(pop.x,pop.y,trackZ(pop.d-game.distance));pop.sprite.material.opacity=Math.min(1,pop.life*3);return true;});
    this.rings=this.rings.filter(r=>{r.life-=dt;if(r.life<=0){r.mesh.removeFromParent();r.mesh.geometry.dispose();r.mesh.material.dispose();return false;}r.mesh.position.set(r.x,.07,trackZ(r.d-game.distance));r.mesh.scale.setScalar((1-r.life/.55)*r.max+.1);r.mesh.material.opacity=r.life/.55*.70;return true;});
    game.level.bosses.forEach((boss,i)=>{const warning=boss.warning,m=this.warningMeshes[i];m.visible=!!warning&&boss.hp>0;if(warning){m.position.set(warning.x,.028,CONFIG.playerZ-4);m.scale.set(warning.width,25,1);m.material.opacity=.18+Math.sin(time*16)*.08;}});
    return {particles:this.parts.length,beams:beamCount,pickupFlights:this.chargeFeedback.flights.length,plasmaFans:this.chargeFeedback.fans.length};
  }
  dispose(){this.clear();for(const texture of this.textCache.values())texture.dispose();this.textCache.clear();}
  clear(){this.laser.clear();this.chargeFeedback.clear();this.parts=[];for(const p of this.popups){p.sprite.removeFromParent();p.sprite.material.dispose();}this.popups=[];for(const r of this.rings){r.mesh.removeFromParent();r.mesh.geometry.dispose();r.mesh.material.dispose();}this.rings=[];this.lastCellPop=this.lastCharge=this.lastImpact=-5;this.shake=this.flash=0;}
}
