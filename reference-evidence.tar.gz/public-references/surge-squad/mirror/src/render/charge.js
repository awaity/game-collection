import { CONFIG } from '../simulation/config.js';
import { trackZ } from './track.js';
import { roundedBox } from '../assets/authoring.js';
const T = globalThis.THREE;
/** Short-lived pickup flights and first-contact plasma fans. Rewards are owned by Game. */
export class ChargeFeedback {
  constructor(scene) {
    this.flights = []; this.fans = []; this.dummy = new T.Object3D(); this.color = new T.Color();
    this.cells = new T.InstancedMesh(roundedBox(1.05, .38, .33, .07, 3),
      new T.MeshStandardMaterial({ color: 0xffffff, roughness: .3, metalness: .13, emissive: 0x1553a4, emissiveIntensity: .8 }), 32);
    this.cells.count = 0; this.cells.setColorAt(0, new T.Color(0xffffff)); this.cells.frustumCulled = false;
    this.cells.instanceMatrix.setUsage(T.DynamicDrawUsage); scene.add(this.cells);
    this.positions = new Float32Array(4096 * 3); this.colors = new Float32Array(4096 * 3);
    const geometry = new T.BufferGeometry();
    geometry.setAttribute('position', new T.BufferAttribute(this.positions, 3).setUsage(T.DynamicDrawUsage));
    geometry.setAttribute('color', new T.BufferAttribute(this.colors, 3).setUsage(T.DynamicDrawUsage));
    geometry.setDrawRange(0, 0);
    this.arcs = new T.LineSegments(geometry, new T.LineBasicMaterial({ vertexColors: true, transparent: true,
      depthWrite: false, blending: T.AdditiveBlending, opacity: .88 }));
    this.arcs.frustumCulled = false; this.arcs.renderOrder = 9; scene.add(this.arcs);
  }
  event(event) {
    if (event.type === 'cell' && this.flights.length < 32)
      this.flights.push({ x: event.x, d: event.d, age: 0, gold: event.gold, duration: .30 });
    if (event.type === 'plasma-impact' && this.fans.length < 36)
      this.fans.push({ ...event, age: 0, duration: .14 });
  }
  update(dt, game) {
    this.flights = this.flights.filter(f => (f.age += dt) < f.duration);
    let count = 0;
    for (const f of this.flights) {
      const t = Math.min(1, f.age / f.duration), ease = t * t * (3 - 2 * t);
      const d = this.dummy;
      d.position.set(f.x + (game.player.x - f.x) * ease,
        .55 + ease * 1.00 + Math.sin(t * Math.PI) * .52,
        trackZ(f.d - game.distance) * (1 - ease) + (CONFIG.playerZ + .18) * ease);
      const scale = .70 * (1 - t) + .10;
      d.scale.setScalar(scale); d.rotation.set(t * .9, t * 1.9, Math.sin(t * Math.PI) * .25);
      d.updateMatrix(); this.cells.setMatrixAt(count, d.matrix);
      this.cells.setColorAt(count++, this.color.setHex(f.gold ? 0xffd525 : 0x2199ff));
    }
    this.cells.count = count; this.cells.instanceMatrix.needsUpdate = true; this.cells.instanceColor.needsUpdate = true;
    this.fans = this.fans.filter(f => (f.age += dt) < f.duration);
    let vertices = 0;
    for (const fan of this.fans) for (const target of fan.arcs) {
      const z0 = trackZ(fan.d - game.distance), z1 = trackZ(target.d - game.distance);
      const fade = 1 - fan.age / fan.duration;
      for (let segment = 0; segment < 3 && vertices + 2 < 4096; segment++) {
        for (let end = 0; end < 2; end++) {
          const t = (segment + end) / 3;
          const jitter = t > 0 && t < 1 ? Math.sin(t * 29 + fan.time * 21) * .19 : 0;
          this.positions.set([fan.x + (target.x - fan.x) * t, fan.y + (target.y - fan.y) * t + jitter,
            z0 + (z1 - z0) * t + jitter * .7], vertices * 3);
          this.colors.set([.12 * fade, 2.3 * fade, 4.0 * fade], vertices++ * 3);
        }
      }
    }
    this.arcs.geometry.setDrawRange(0, vertices);
    this.arcs.geometry.attributes.position.needsUpdate = this.arcs.geometry.attributes.color.needsUpdate = true;
  }
  clear() { this.flights = []; this.fans = []; this.cells.count = 0; this.arcs.geometry.setDrawRange(0, 0); }
}
