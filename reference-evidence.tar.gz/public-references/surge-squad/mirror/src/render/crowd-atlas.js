const T = globalThis.THREE;
export async function loadCrowdAtlas(path = 'models/raider-atlas.png') {
  const embedded = globalThis.__SURGE_ASSETS__?.[path];
  const url = embedded ? `data:image/png;base64,${embedded}` : `./${path}`;
  const texture = await new Promise((resolve, reject) => new T.TextureLoader().load(url, resolve, undefined, reject));
  // The baker records scene-linear radiance. Do NOT decode sRGB and tone-map twice.
  texture.encoding = T.LinearEncoding; texture.minFilter = T.LinearMipmapLinearFilter;
  texture.magFilter = T.LinearFilter; texture.generateMipmaps = true;
  return texture;
}
/** Far LOD: eight baked poses of our own raider; one independent depth-writing
 * instance per enemy. Simulation HP, collision, IDs and population are untouched. */
export class CrowdAtlas {
  constructor(scene, texture, capacity, camera, timeUniform) {
    this.camera = camera; this.dummy = new T.Object3D(); this.capacity = capacity;
    const material = new T.MeshBasicMaterial({ map: texture, alphaTest: .22, depthWrite: true,
      transparent: false, side: T.DoubleSide, toneMapped: false });
    material.onBeforeCompile = shader => {
      shader.uniforms.uCrowdTime = timeUniform;
      shader.vertexShader = 'uniform float uCrowdTime;\n' + shader.vertexShader;
      shader.vertexShader = shader.vertexShader.replace('#include <uv_vertex>', `
        #include <uv_vertex>
        float phase=uCrowdTime*11.+instanceMatrix[3].z*2.1+instanceMatrix[3].x*3.4;
        float frame=mod(floor(phase*1.27323954),8.);
        vUv.x=(vUv.x+frame)/8.;
      `);
    };
    material.customProgramCacheKey = () => 'surge-crowd-atlas-120';
    this.mesh = new T.InstancedMesh(new T.PlaneGeometry(.80, .88), material, capacity);
    this.mesh.frustumCulled = false; this.mesh.count = 0;
    this.mesh.instanceMatrix.setUsage(T.DynamicDrawUsage); scene.add(this.mesh); this.meshes = [this.mesh];
  }
  set(index, x, y, z, scale = 1) {
    const o = this.dummy;
    o.position.set(x, y + .30 * scale, z); o.quaternion.copy(this.camera.quaternion);
    o.scale.setScalar(scale); o.updateMatrix(); this.mesh.setMatrixAt(index, o.matrix);
  }
  finish(count) { this.mesh.count = Math.min(count, this.capacity); this.mesh.instanceMatrix.needsUpdate = true; }
}
