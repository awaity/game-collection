import { CrowdAtlas, loadCrowdAtlas } from './crowd-atlas.js';
import { playerPose } from '../simulation/pose.js';
import { trackZ, trackOffset, trackScale, bossScale } from './track.js';
import { CONFIG, formation } from '../simulation/config.js';
import { ActorBatch, loadModel } from './actors.js';
import { World } from './world.js';
import { Effects } from './effects.js';
import { Post } from './post.js';
import { shadowTexture } from './materials.js';
import { roundedBox } from '../assets/authoring.js';
const T=globalThis.THREE;
export class View {
  constructor(container,options={}){
    this.container=container;this.options=options;this.quality=options.quality||'high';this.disposed=false;this.contextLost=false;
    this.renderer=new T.WebGLRenderer({antialias:false,alpha:false,powerPreference:'high-performance',preserveDrawingBuffer:false});
    this.renderer.setClearColor(0x081320);this.renderer.outputEncoding=T.LinearEncoding;this.renderer.toneMapping=T.NoToneMapping;
    this.renderer.shadowMap.enabled=true;this.renderer.shadowMap.type=T.PCFSoftShadowMap;this.renderer.info.autoReset=false;
    this.renderer.domElement.id='game-canvas';this.renderer.domElement.setAttribute('aria-label','电涌小队三维游戏画面');container.prepend(this.renderer.domElement);
    this.scene=new T.Scene();this.scene.background=new T.Color(0x07101e);
    this.camera=new T.PerspectiveCamera(32,9/16,.10,360);this.baseCamera=new T.Vector3(1.5,21.5,26.8);this.camera.position.copy(this.baseCamera);this.camera.lookAt(0,0,3.1);
    const hemi=new T.HemisphereLight(0xc4ddff,0x3c3448,.56);this.scene.add(hemi);
    const sun=new T.DirectionalLight(0xfff3de,1.12);sun.position.set(-21,34,14);sun.target.position.set(0,0,-10);sun.castShadow=true;
    sun.shadow.mapSize.set(1024,1024);sun.shadow.camera.left=-12;sun.shadow.camera.right=12;sun.shadow.camera.top=27;sun.shadow.camera.bottom=-14;sun.shadow.camera.near=.5;sun.shadow.camera.far=100;sun.shadow.bias=-.0003;sun.shadow.normalBias=.025;sun.shadow.radius=2.5;
    this.scene.add(sun,sun.target);this.sun=sun;this.renderer.shadowMap.enabled=this.quality!=='low';sun.shadow.mapSize.set(1024,1024);
    const fill=new T.DirectionalLight(0x729fdf,.18);fill.position.set(15,10,-22);this.scene.add(fill);
    this.timeUniform={value:0};this.world=new World(this.scene);this.effects=new Effects(this.scene,this.camera);
    this.post=new Post(this.renderer,480,800);
    this.dummy=new T.Object3D();
    this.shadows=new T.InstancedMesh(new T.PlaneGeometry(1,1),new T.MeshBasicMaterial({map:shadowTexture(),transparent:true,depthWrite:false,opacity:.55}),3900);this.shadows.count=0;this.shadows.frustumCulled=false;this.scene.add(this.shadows);
    const shieldMat=new T.ShaderMaterial({uniforms:{charge:{value:0}},vertexShader:`
      varying vec3 vNormal,vEye;void main(){vec4 p=modelViewMatrix*instanceMatrix*vec4(position,1.);vNormal=normalize(normalMatrix*mat3(instanceMatrix)*normal);vEye=-p.xyz;gl_Position=projectionMatrix*p;}`,
      fragmentShader:`varying vec3 vNormal,vEye;uniform float charge;void main(){float rim=pow(1.-abs(dot(normalize(vNormal),normalize(vEye))),1.9);
      vec3 c=mix(vec3(.035,.31,.66),vec3(2.5,3.0,3.4),rim);gl_FragColor=vec4(c,(.54+rim*.40)*(.65+charge*.35));}`,
      transparent:true,depthWrite:false,side:T.FrontSide});
    this.shields=new T.InstancedMesh(roundedBox(.77,.46,.32,.14,8),shieldMat,CONFIG.maxVisibleTroops);this.shields.count=0;this.shields.frustumCulled=false;this.shields.renderOrder=3;this.scene.add(this.shields);
    this.onResize=()=>this.resize();this.observer=new ResizeObserver(this.onResize);this.observer.observe(container);
    this.renderer.domElement.addEventListener('webglcontextlost',ev=>{ev.preventDefault();this.contextLost=true;options.onContextLost?.();});
    this.renderer.domElement.addEventListener('webglcontextrestored',()=>{this.contextLost=false;options.onContextRestored?.();});
    this.resize();
  }
  async load(onProgress=()=>{}){
    const keys=['vanguard','raider','raider-low','titan','brute'];const models={};let loaded=0;
    await Promise.all(keys.map(async key=>{models[key]=await loadModel(`models/${key}.glb`);loaded++;onProgress(loaded/keys.length);}));
    this.modelParts=models;
    this.players=new ActorBatch(this.scene,models.vanguard,CONFIG.maxVisibleTroops,this.timeUniform,{gaitScale:1});
    this.nearCrowd=new ActorBatch(this.scene,models.raider,480,this.timeUniform,{gaitScale:.7});
    this.crowdAtlasTexture=await loadCrowdAtlas();
    this.farCrowd=new CrowdAtlas(this.scene,this.crowdAtlasTexture,CONFIG.maxCrowdVisible,this.camera,this.timeUniform);
    this.geometryCrowd=new ActorBatch(this.scene,models['raider-low'],CONFIG.maxCrowdVisible,this.timeUniform,{shadow:false,gaitScale:.7});
    this.bossActionUniforms=[{value:0},{value:0}];
    this.bosses=[0,1].map(i=>new ActorBatch(this.scene,i===0?models.brute:models.titan,1,this.timeUniform,{gaitScale:1.9,actionUniform:this.bossActionUniforms[i]}));
    this.ready=true;
  }
  setGame(game){this.game=game;this.world.makeGates(game);this.effects.clear();}
  setQuality(q){this.quality=['low','medium','high'].includes(q)?q:'high';this.renderer.shadowMap.enabled=this.quality!=='low';const size=1024;if(this.sun.shadow.mapSize.x!==size){this.sun.shadow.map?.dispose();this.sun.shadow.map=null;this.sun.shadow.mapSize.set(size,size);}this.resize();}
  resize(){
    const bounds=this.container.getBoundingClientRect();const w=Math.max(1,bounds.width),h=Math.max(1,bounds.height);
    const maxRatio=this.quality==='low'?1:this.quality==='medium'?1.35:2;
    const dpr=Math.min(globalThis.devicePixelRatio||1,maxRatio);
    this.renderer.setPixelRatio(dpr);this.renderer.setSize(w,h,false);
    this.camera.aspect=w/h;
    // Keep the reference framing on tall phones; on landscape, widen horizontal view instead of stretching.
    const nominal=32;this.camera.fov=this.camera.aspect<.50?2*Math.atan(Math.tan(nominal*Math.PI/360)*(.50/this.camera.aspect))*180/Math.PI:nominal;
    this.camera.updateProjectionMatrix();this.post.setQuality(this.quality);this.post.resize(Math.round(w*dpr),Math.round(h*dpr),this.quality==='low'?.75:1);this.width=w;this.height=h;
  }
  project(x,y,d){const p=new T.Vector3(x,y,trackZ(d-this.game.distance)).project(this.camera);return{x:(p.x*.5+.5)*this.width,y:(-p.y*.5+.5)*this.height,visible:p.z<1&&p.z>-1&&Math.abs(p.x)<1.4&&Math.abs(p.y)<1.3};}
  matrix(x,y,z,sx,sy,sz,rx=0,ry=0,rz=0){const o=this.dummy;o.position.set(x,y,z);o.scale.set(sx,sy,sz);o.rotation.set(rx,ry,rz);o.updateMatrix();return o.matrix;}
  draw(dt,game,time){
    if(!this.ready||this.contextLost||this.disposed)return;
    this.timeUniform.value=time;
    const p=game.player;const slots=formation(p.troops);
    const cameraPan=p.x*.70;this.camera.position.copy(this.baseCamera);this.camera.position.x+=cameraPan;
    const shake=this.options.reducedMotion?0:this.effects.shake;
    this.camera.position.x+=Math.sin(time*74)*shake*.23;this.camera.position.y+=Math.sin(time*87)*shake*.20;this.camera.lookAt(cameraPan*1.03,0,3.1);
    // Conservative camera-dependent cutoff. This changes submitted geometry only, never the simulation.
    const renderDistance=this.options.renderDistance??(this.camera.fov<=36?72:this.camera.fov<50?120:CONFIG.viewDistance);
    this.world.update(game,time,renderDistance);
    let shadowCount=0;
    for(let i=0;i<slots.length;i++){
      const s=slots[i],pose=playerPose(p,s,i,time,['playing','paused'].includes(game.phase));
      const x=pose.x,z=pose.z,bob=pose.y-.04;
      this.players.set(i,x,pose.y,z,pose.scale,pose.yaw,pose.roll);
      const sh=this.matrix(x,.023,z+.15,1.15,1.02,1,-Math.PI/2);this.shadows.setMatrixAt(shadowCount++,sh);
      const shield=this.matrix(x,.44+bob,z+.42,1.25,1.25,1.25);this.shields.setMatrixAt(i,shield);

    }
    this.players.finish(slots.length);
    for(const mesh of [this.shields]){mesh.count=p.energy>.1?slots.length:0;mesh.instanceMatrix.needsUpdate=true;}
    this.shields.material.uniforms.charge.value=p.energy/CONFIG.energyMax;
    for(const m of this.players.meshes){
      if(m.name.includes('coil'))m.material.emissiveIntensity=.25+(p.energy/CONFIG.energyMax)*2.4+(p.laser?.5:0);
      const blink=p.invincible>0&&Math.floor(time*14)%2===0;m.visible=!blink;
    }
    let near=0,far=0;const nearLimit=this.quality==='low'?48:this.quality==='medium'?120:200;
    for(let i=game.enemyStart;i<game.level.enemies.length;i++){
      const enemy=game.level.enemies[i],gap=enemy.d-game.distance;if(gap>renderDistance)break;
      if(gap<-5)continue;
      if(gap>90&&enemy.id%2!==0)continue;
      let size=enemy.size;
      if(enemy.hp<=0){const age=time-enemy.deadAt;if(age>.28)continue;size*=Math.max(.001,1-age/.28);}
      const z=trackZ(gap);
      const bob=Math.sin(time*11+enemy.phase)*.021;const yaw=Math.sin(time*2+enemy.phase)*.10;
      if(gap<26&&near<nearLimit){this.nearCrowd.set(near++,enemy.x,bob+.012,z,size,yaw);}
      else if(far<CONFIG.maxCrowdVisible){(this.options.crowdMode==='geometry'?this.geometryCrowd:this.farCrowd).set(far++,enemy.x,bob+.012,z,size,yaw);}
      if(gap<64&&shadowCount<3900){this.shadows.setMatrixAt(shadowCount++,this.matrix(enemy.x,.016,z,.31*size,.35*size,1,-Math.PI/2));}
    }
    this.nearCrowd.finish(near);this.farCrowd.finish(this.options.crowdMode==='geometry'?0:far);this.geometryCrowd.finish(this.options.crowdMode==='geometry'?far:0);
    game.level.bosses.forEach((boss,i)=>{
      const slamAge=time-(boss.slamAt??-100);
      this.bossActionUniforms[i].value=boss.warning?Math.sin(Math.min(1,(1-boss.warning.remaining/boss.warning.total)*1.2)*Math.PI/2):slamAge<.20?Math.cos(Math.max(0,slamAge)/.20*Math.PI/2):0;
      const gap=boss.d-game.distance;let scale=bossScale(boss,gap);
      if(boss.hp<=0)scale*=Math.max(0,1-(time-boss.deadAt)/.65);
      const batch=this.bosses[i];if(gap>CONFIG.viewDistance||gap<-10||scale<=0){batch.finish(0);return;}
      const bob=Math.sin(time*4+i)*.05;
      batch.set(0,boss.x,.02+bob,trackZ(gap),scale,Math.sin(time*.8)*.04,boss.warning?Math.sin(time*12)*.03:0);batch.finish(1);
      for(const m of batch.meshes){
        if(m.name.includes('rose-skin')){m.material.color.setHex(i===0?0xd79992:0xe7afb3).convertSRGBToLinear();m.material.emissive.setHex(boss.hitFlash>0?0x101620:0x000000);}
      }
      this.shadows.setMatrixAt(shadowCount++,this.matrix(boss.x,.022,trackZ(gap),2*scale,1.8*scale,1,-Math.PI/2));
    });
    this.shadows.count=shadowCount;this.shadows.instanceMatrix.needsUpdate=true;
    const fx=this.effects.update(dt,game,time);
    this.renderer.info.reset();this.post.render(this.scene,this.camera,this.quality);
    this.stats={drawCalls:this.renderer.info.render.calls,triangles:this.renderer.info.render.triangles,near,far,visibleEnemies:near+far,crowdLOD:this.options.crowdMode==='geometry'?'geometry':'8-pose atlas',postPasses:this.post.passes,antialias:this.post.samples?`${this.post.samples}x MSAA + FXAA`:'FXAA',samples:this.post.samples,
      textures:this.renderer.info.memory.textures,geometries:this.renderer.info.memory.geometries,...fx,quality:this.quality,internalResolution:[this.post.target.width,this.post.target.height],renderDistance,resolution:[this.renderer.domElement.width,this.renderer.domElement.height]};
  }
  dispose(){
    this.disposed=true;this.observer.disconnect();this.effects.dispose();this.scene.traverse(o=>{if(o.geometry)o.geometry.dispose();if(o.customDepthMaterial)o.customDepthMaterial.dispose();if(o.material){const mats=Array.isArray(o.material)?o.material:[o.material];for(const m of mats){for(const v of Object.values(m))if(v?.isTexture)v.dispose();m.dispose();}}});this.post.dispose();this.renderer.dispose();this.renderer.domElement.remove();
  }
}
