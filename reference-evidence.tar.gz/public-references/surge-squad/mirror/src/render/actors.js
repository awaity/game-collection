import { animateMaterial } from './materials.js';
const T=globalThis.THREE;
export async function loadModel(path){
  const loader=new T.GLTFLoader();let buffer;
  if(globalThis.__SURGE_ASSETS__?.[path]){
    const raw=atob(globalThis.__SURGE_ASSETS__[path]);const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);buffer=bytes.buffer;
  }else{
    const response=await fetch(`./${path}`);if(!response.ok)throw new Error(`Model missing: ${path} (${response.status})`);buffer=await response.arrayBuffer();
  }
  return new Promise((resolve,reject)=>loader.parse(buffer,'',gltf=>{
    const parts=[];gltf.scene.traverse(obj=>{if(obj.isMesh){const attr=obj.geometry.getAttribute('_part');if(attr)obj.geometry.setAttribute('part',attr);else obj.geometry.setAttribute('part',new T.Float32BufferAttribute(new Float32Array(obj.geometry.attributes.position.count),1));
      obj.geometry.computeBoundingSphere();parts.push({name:obj.name,geometry:obj.geometry,material:obj.material});}});resolve(parts);
  },reject));
}
export class ActorBatch {
  constructor(scene,parts,capacity,timeUniform,{shadow=true,gaitScale=1,actionUniform=null}={}){
    this.meshes=[];this.matrix=new T.Matrix4();this.position=new T.Vector3();this.quat=new T.Quaternion();this.scale=new T.Vector3();this.euler=new T.Euler();this.capacity=capacity;
    for(const part of parts){
      const material=part.material.clone();if(part.name.includes('coil'))material.emissiveIntensity=1.2;
      const depth=animateMaterial(material,timeUniform,gaitScale,actionUniform);
      const mesh=new T.InstancedMesh(part.geometry,material,capacity);mesh.name=part.name;mesh.count=0;mesh.instanceMatrix.setUsage(T.DynamicDrawUsage);
      mesh.frustumCulled=false;mesh.castShadow=shadow&&!part.name.includes('coil');mesh.receiveShadow=shadow;mesh.customDepthMaterial=depth;scene.add(mesh);this.meshes.push(mesh);
    }
  }
  set(index,x,y,z,s=1,yaw=0,roll=0){
    this.position.set(x,y,z);this.scale.set(s,s,s);this.quat.setFromEuler(this.euler.set(0,yaw,roll));this.matrix.compose(this.position,this.quat,this.scale);
    for(const m of this.meshes)m.setMatrixAt(index,this.matrix);
  }
  finish(count){for(const m of this.meshes){m.count=Math.min(count,this.capacity);m.instanceMatrix.needsUpdate=true;}}
  dispose(){for(const m of this.meshes){m.removeFromParent();m.material.dispose();m.customDepthMaterial?.dispose();}this.meshes=[];}
}
