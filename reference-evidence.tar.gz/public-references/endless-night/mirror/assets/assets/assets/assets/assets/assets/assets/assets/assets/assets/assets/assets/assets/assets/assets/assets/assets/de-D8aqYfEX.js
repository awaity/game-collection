<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no" />
    <meta name="theme-color" content="#1e1838" />
    <meta name="description" content="无尽长夜 — 《最后一盏灯》的重制版：带着被盗的太阳的最后一缕火焰，穿越五个死亡之夜。" />
    <title>Endless Night . 无尽长夜</title>
    <link rel="icon" href="data:image/svg+xml,%3Csvg xmlns=%22http://www.w3.org/2000/svg%22 viewBox=%220 0 64 64%22%3E%3Crect width=%2264%22 height=%2264%22 rx=%2216%22 fill=%22%231e1838%22/%3E%3Crect x=%2219%22 y=%2219%22 width=%2226%22 height=%2230%22 rx=%2210%22 fill=%22%23ffd9a0%22 stroke=%22%23ffb37a%22 stroke-width=%224%22/%3E%3Cpath d=%22M32 27c5 6 4 12 0 15c-4-3-5-9 0-15z%22 fill=%22%23ff8a5c%22/%3E%3Cpath d=%22M25 19l7-8l7 8%22 fill=%22none%22 stroke=%22%23ffb37a%22 stroke-width=%224%22 stroke-linecap=%22round%22 stroke-linejoin=%22round%22/%3E%3C/svg%3E" />
    <style>html,body{background:#1e1838;height:100%;margin:0}#boot{z-index:100;color:#fff6e8;letter-spacing:.04em;-webkit-user-select:none;user-select:none;background:radial-gradient(60% 50% at 50% 42%,#b9a8ff38,#b9a8ff00 70%),radial-gradient(40% 30% at 50% 46%,#ffb37a24,#ffb37a00 70%),linear-gradient(#2a2350,#1e1838 70%);flex-direction:column;justify-content:center;align-items:center;gap:22px;font:600 16px/1.4 ui-rounded,SF Pro Rounded,Nunito Variable,Nunito,PingFang SC,HarmonyOS Sans SC,Microsoft YaHei,system-ui,sans-serif;transition:opacity .6s;display:flex;position:fixed;inset:0}#boot.done{opacity:0;pointer-events:none}#boot .lantern{transform-origin:50% 8%;will-change:transform;width:92px;height:120px;animation:2.6s ease-in-out infinite boot-swing}#boot .halo{will-change:transform, opacity;background:radial-gradient(circle,#ffd9a06b,#ffb37a1f 45%,#ffb37a00 70%);border-radius:50%;width:260px;height:260px;margin-top:-56px;animation:2.6s ease-in-out infinite boot-glow;position:absolute}#boot .flame{transform-origin:46px 80px;animation:.9s ease-in-out infinite alternate boot-flicker}#boot .hint{opacity:.86;position:relative}#boot .track{background:#e4dcff29;border-radius:99px;width:168px;height:8px;position:relative;overflow:hidden;box-shadow:inset 0 1px 2px #140a2880}#boot .fill{transform-origin:0;transform:scaleX(var(--p,.12));background:linear-gradient(90deg,#ffd97a,#ffb347);border-radius:99px;transition:transform .5s cubic-bezier(.34,1.56,.64,1);position:absolute;inset:0}#boot .fill:after{content:"";background:linear-gradient(90deg,#fff0,#ffffff8c,#fff0);animation:1.3s linear infinite boot-shine;position:absolute;inset:0}@keyframes boot-swing{0%,to{transform:translateY(0)rotate(-5deg)}50%{transform:translateY(-8px)rotate(5deg)}}@keyframes boot-glow{0%,to{opacity:.8;transform:scale(.94)}50%{opacity:1;transform:scale(1.06)}}@keyframes boot-flicker{0%{transform:scale(1)}to{transform:scale(.9,1.08)}}@keyframes boot-shine{0%{transform:translate(-100%)}to{transform:translate(100%)}}@media (prefers-reduced-motion:reduce){#boot .lantern,#boot .halo,#boot .flame,#boot .fill:after{animation:none}}</style>
    <script type="module" crossorigin src="./assets/index-CEtcJP9k.js"></script>
    <link rel="modulepreload" crossorigin href="./assets/rolldown-runtime-hePW80VL.js">
    <link rel="modulepreload" crossorigin href="./assets/react-QlJfyTvX.js">
    <link rel="modulepreload" crossorigin href="./assets/three-a3YxujcJ.js">
    <link rel="stylesheet" crossorigin href="./assets/index-BMKMF8bw.css" data-app-css media="print" onload="this.media='all'">
    <link rel="preload" as="fetch" crossorigin="" href="./assets/rapier_wasm2d_bg-DREntbB-.wasm.gz.bin">
    <link rel="modulepreload" crossorigin="" href="./assets/rapier-B1iUrAI_.js">
    <link rel="modulepreload" crossorigin="" href="./assets/rapier-BWSCtl6w.js">
    <link rel="preload" as="font" type="font/woff2" crossorigin="" href="./assets/fredoka-latin-wght-normal-DM6njrJ3.woff2">
    <link rel="preload" as="font" type="font/woff2" crossorigin="" href="./assets/nunito-latin-wght-normal-BzFMHfZw.woff2">
    <script>window.__LOCALE_CHUNKS={"de":"./assets/de-D8aqYfEX.js","es":"./assets/es-BCdWdGft.js","fr":"./assets/fr-C_E1G47C.js","hu":"./assets/hu-BpL_gvJz.js","zh":"./assets/zh-Bw_IDYVX.js"}</script>
  </head>
  <body>
    <div id="app">
      <div id="view"></div>
      <canvas id="hud"></canvas>
      <div id="ui"></div>
    </div>
    <div id="boot" role="status" aria-live="polite">
      <div class="halo"></div>
      <svg class="lantern" viewBox="0 0 92 120" aria-hidden="true">
        <path d="M34 22 Q46 4 58 22" fill="none" stroke="#ffb37a" stroke-width="5" stroke-linecap="round" />
        <rect x="24" y="20" width="44" height="12" rx="6" fill="#4e4590" stroke="#3b2d5c" stroke-width="3" />
        <rect x="18" y="30" width="56" height="66" rx="22" fill="#ffd9a0" stroke="#3b2d5c" stroke-width="3.5" />
        <rect x="26" y="38" width="40" height="50" rx="16" fill="#fff6e8" opacity="0.55" />
        <path class="flame" d="M46 52 C56 62 54 74 46 80 C38 74 36 62 46 52 Z" fill="#ff8a5c" />
        <path d="M46 62 C50 67 49 73 46 76 C43 73 42 67 46 62 Z" fill="#ffd97a" />
        <circle cx="35" cy="70" r="2.6" fill="#3b2d5c" />
        <circle cx="57" cy="70" r="2.6" fill="#3b2d5c" />
        <ellipse cx="30" cy="77" rx="4" ry="2.4" fill="#ff8fb8" opacity="0.7" />
        <ellipse cx="62" cy="77" rx="4" ry="2.4" fill="#ff8fb8" opacity="0.7" />
        <rect x="24" y="94" width="44" height="12" rx="6" fill="#4e4590" stroke="#3b2d5c" stroke-width="3" />
      </svg>
      <div class="hint" id="boot-hint">Lighting the lantern…</div>
      <div class="track"><div class="fill" id="boot-fill"></div></div>
    </div>
    <script>
      // Same rule as detectLang(): saved choice, else the first supported browser
      // language. Localises the splash and (in builds) preloads that locale's chunk.
      (function () {
        var ok = { en: 1, de: 1, es: 1, hu: 1, zh: 1, fr: 1 };
        var lang = '';
        try {
          lang = (JSON.parse(localStorage.getItem('endless-night.settings.v1') || '{}') || {}).lang || '';
        } catch (e) {}
        if (!ok[lang]) {
          lang = 'en';
          var nav = navigator.languages && navigator.languages.length ? navigator.languages : [navigator.language];
          for (var i = 0; i < nav.length; i++) {
            var c = String(nav[i] || '').slice(0, 2).toLowerCase();
            if (ok[c]) { lang = c; break; }
          }
        }
        var text = { zh: '正在点亮提灯…', de: 'Die Laterne wird entzündet…', es: 'Encendiendo el farol…', fr: 'On allume la lanterne…', hu: 'Meggyújtjuk a lámpást…' }[lang];
        if (text) document.getElementById('boot-hint').textContent = text;
        var chunk = (window.__LOCALE_CHUNKS || {})[lang];
        if (chunk) {
          var l = document.createElement('link');
          l.rel = 'modulepreload';
          l.crossOrigin = '';
          l.href = chunk;
          document.head.appendChild(l);
        }
      })();
    </script>
  </body>
</html>
